# models.py - Full CRM Models according to specification
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, ForeignKey, Boolean, JSON, Enum, Numeric, Date, Time, func
from sqlalchemy.orm import relationship
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
import enum

engine = create_async_engine("sqlite+aiosqlite:///database.db", echo=False)
async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


# ==================== USERS & ROLES ====================

class UserRole(enum.Enum):
    ADMIN = "admin"
    MANAGER = "manager"
    EMPLOYEE = "employee"
    READONLY = "readonly"


class User(Base):
    """System users / employees"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(150), nullable=False)
    phone = Column(String(30))
    avatar = Column(String(255))
    role = Column(String(20), default="employee")
    is_active = Column(Boolean, default=True)
    team_id = Column(Integer, ForeignKey('teams.id'))
    created_at = Column(DateTime, server_default=func.now())
    last_login = Column(DateTime)

    # Relationships
    team = relationship("Team", back_populates="members", foreign_keys=[team_id])
    tasks_assigned = relationship("Task", back_populates="assignee", foreign_keys="Task.assignee_id")
    tasks_created = relationship("Task", back_populates="creator", foreign_keys="Task.creator_id")
    deals = relationship("Deal", back_populates="responsible")
    activities = relationship("Activity", back_populates="user")


class Team(Base):
    """Teams / departments"""
    __tablename__ = "teams"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    manager_id = Column(Integer, ForeignKey('users.id'))
    parent_team_id = Column(Integer, ForeignKey('teams.id'))
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    members = relationship("User", back_populates="team", foreign_keys="User.team_id")
    manager = relationship("User", foreign_keys=[manager_id])


class Role(Base):
    """Custom roles with permissions"""
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False)
    permissions = Column(JSON)  # {"clients": ["read", "write"], "deals": ["read"]}
    created_at = Column(DateTime, server_default=func.now())


# ==================== CLIENTS MODULE ====================

class ClientType(enum.Enum):
    LEAD = "lead"
    CONTACT = "contact"
    COMPANY = "company"


class ClientStatus(enum.Enum):
    NEW = "new"
    ACTIVE = "active"
    LOST = "lost"
    ARCHIVE = "archive"


class Client(Base):
    """Unified client entity (Lead, Contact, Company)"""
    __tablename__ = "clients"

    id = Column(Integer, primary_key=True)
    client_type = Column(String(20), default="lead")  # lead, contact, company
    full_name = Column(String(150), nullable=False)  # For contacts
    company_name = Column(String(150))  # For companies
    legal_name = Column(String(200))  # Legal entity name
    inn = Column(String(20))  # Tax ID
    ogrn = Column(String(20))  # Business registration number
    
    # Contact info
    phone = Column(String(30))
    phone_additional = Column(String(30))
    email = Column(String(120))
    email_additional = Column(String(120))
    website = Column(String(255))
    
    # Address
    address = Column(String(255))
    city = Column(String(100))
    country = Column(String(100))
    
    # Status & segmentation
    status = Column(String(20), default="new")
    source = Column(String(100))  # Website, Referral, Ads, etc.
    source_detail = Column(String(255))  # UTM, campaign details
    
    # Assignment
    responsible_id = Column(Integer, ForeignKey('users.id'))
    
    # Company relation (for contacts)
    company_id = Column(Integer, ForeignKey('clients.id'))
    
    # Additional info
    comment = Column(Text)
    tags = Column(String(500))  # Comma-separated tags
    custom_fields = Column(JSON)  # {"field_name": "value"}
    
    # Scoring
    lead_score = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())
    last_contact_at = Column(DateTime)
    
    # Relationships
    responsible = relationship("User", foreign_keys=[responsible_id])
    contacts = relationship("Client", backref="company", remote_side=[id])
    deals = relationship("Deal", back_populates="client")
    tasks = relationship("Task", back_populates="client")
    communications = relationship("Communication", back_populates="client")
    documents = relationship("Document", back_populates="client")
    files = relationship("File", back_populates="client")
    events = relationship("CalendarEvent", back_populates="client")


# ==================== DEALS MODULE ====================

class Pipeline(Base):
    """Sales pipelines (B2B, B2C, etc.)"""
    __tablename__ = "pipelines"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    is_default = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    stages = relationship("PipelineStage", back_populates="pipeline", order_by="PipelineStage.sort_order")
    deals = relationship("Deal", back_populates="pipeline")


class PipelineStage(Base):
    """Pipeline stages"""
    __tablename__ = "pipeline_stages"

    id = Column(Integer, primary_key=True)
    pipeline_id = Column(Integer, ForeignKey('pipelines.id'), nullable=False)
    name = Column(String(100), nullable=False)
    color = Column(String(7), default="#6366f1")  # Hex color
    probability = Column(Integer, default=0)  # Close probability %
    sort_order = Column(Integer, default=0)
    sla_hours = Column(Integer)  # SLA in hours
    is_won = Column(Boolean, default=False)  # Won stage
    is_lost = Column(Boolean, default=False)  # Lost stage
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    pipeline = relationship("Pipeline", back_populates="stages")
    deals = relationship("Deal", back_populates="stage")


class Deal(Base):
    """Deals / Opportunities"""
    __tablename__ = "deals"

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    
    # Pipeline
    pipeline_id = Column(Integer, ForeignKey('pipelines.id'))
    stage_id = Column(Integer, ForeignKey('pipeline_stages.id'))
    
    # Client
    client_id = Column(Integer, ForeignKey('clients.id'))
    
    # Financial
    amount = Column(Numeric(15, 2), default=0)
    currency = Column(String(3), default="RUB")
    margin = Column(Numeric(15, 2))  # Profit margin
    margin_percent = Column(Numeric(5, 2))  # Margin %
    
    # Source
    source = Column(String(100))
    source_detail = Column(String(255))
    
    # Assignment
    responsible_id = Column(Integer, ForeignKey('users.id'))
    team_id = Column(Integer, ForeignKey('teams.id'))
    
    # Dates
    expected_close_date = Column(Date)
    actual_close_date = Column(Date)
    
    # Status
    status = Column(String(20), default="open")  # open, won, lost
    
    # Additional
    description = Column(Text)
    loss_reason = Column(String(255))
    custom_fields = Column(JSON)
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    pipeline = relationship("Pipeline", back_populates="deals")
    stage = relationship("PipelineStage", back_populates="deals")
    client = relationship("Client", back_populates="deals")
    responsible = relationship("User", back_populates="deals")
    tasks = relationship("Task", back_populates="deal")
    documents = relationship("Document", back_populates="deal")
    files = relationship("File", back_populates="deal")
    history = relationship("DealHistory", back_populates="deal")


class DealHistory(Base):
    """Deal change history"""
    __tablename__ = "deal_history"

    id = Column(Integer, primary_key=True)
    deal_id = Column(Integer, ForeignKey('deals.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'))
    action = Column(String(50))  # created, stage_changed, amount_changed, etc.
    old_value = Column(Text)
    new_value = Column(Text)
    comment = Column(Text)
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    deal = relationship("Deal", back_populates="history")


class DealContact(Base):
    """Many-to-many relationship between deals and contacts"""
    __tablename__ = "deal_contacts"

    id = Column(Integer, primary_key=True)
    deal_id = Column(Integer, ForeignKey('deals.id'), nullable=False)
    client_id = Column(Integer, ForeignKey('clients.id'), nullable=False)
    role = Column(String(50))  # decision_maker, influencer, etc.
    created_at = Column(DateTime, server_default=func.now())


# ==================== AUTOMATION ====================

class Automation(Base):
    """Automation rules / robots"""
    __tablename__ = "automations"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    is_active = Column(Boolean, default=True)
    
    # Trigger
    trigger_type = Column(String(50))  # deal_created, stage_changed, task_overdue, etc.
    trigger_config = Column(JSON)  # {"pipeline_id": 1, "stage_id": 2}
    
    # Actions
    actions = Column(JSON)  # [{"type": "create_task", "config": {...}}, ...]
    
    # Conditions
    conditions = Column(JSON)  # [{"field": "amount", "operator": ">", "value": 10000}]
    
    # Timing
    delay_minutes = Column(Integer, default=0)
    
    created_at = Column(DateTime, server_default=func.now())


class AutomationLog(Base):
    """Automation execution log"""
    __tablename__ = "automation_logs"

    id = Column(Integer, primary_key=True)
    automation_id = Column(Integer, ForeignKey('automations.id'))
    entity_type = Column(String(50))  # deal, task, client
    entity_id = Column(Integer)
    action_taken = Column(String(100))
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    created_at = Column(DateTime, server_default=func.now())


# ==================== COMMUNICATIONS ====================

class CommunicationChannel(enum.Enum):
    EMAIL = "email"
    PHONE = "phone"
    WHATSAPP = "whatsapp"
    TELEGRAM = "telegram"
    MESSENGER = "messenger"
    CHAT = "chat"
    SOCIAL = "social"


class Communication(Base):
    """Unified communications (omnichannel)"""
    __tablename__ = "communications"

    id = Column(Integer, primary_key=True)
    
    # Channel
    channel = Column(String(20), nullable=False)  # email, phone, whatsapp, telegram, etc.
    
    # Direction
    direction = Column(String(10))  # inbound, outbound
    
    # Participants
    client_id = Column(Integer, ForeignKey('clients.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    from_contact = Column(String(255))  # Email/phone of sender
    to_contact = Column(String(255))  # Email/phone of recipient
    
    # Content
    subject = Column(String(255))
    body = Column(Text)
    attachments = Column(JSON)  # [{"name": "file.pdf", "path": "..."}]
    
    # Status
    status = Column(String(20), default="sent")  # sent, delivered, read, failed
    
    # Relations
    deal_id = Column(Integer, ForeignKey('deals.id'))
    task_id = Column(Integer, ForeignKey('tasks.id'))
    
    # Extra data
    external_id = Column(String(255))  # ID from external system
    extra_data = Column(JSON)  # Additional metadata
    
    # Timestamps
    sent_at = Column(DateTime)
    delivered_at = Column(DateTime)
    read_at = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="communications")


class MessageTemplate(Base):
    """Message templates for quick responses"""
    __tablename__ = "message_templates"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    channel = Column(String(20))  # email, whatsapp, etc.
    subject = Column(String(255))
    body = Column(Text, nullable=False)
    variables = Column(JSON)  # ["client_name", "deal_amount"]
    is_global = Column(Boolean, default=False)
    user_id = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, server_default=func.now())


class SLARule(Base):
    """SLA rules for response times"""
    __tablename__ = "sla_rules"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    channel = Column(String(20))  # email, phone, chat, etc.
    priority = Column(String(20))  # low, medium, high, urgent
    response_time_minutes = Column(Integer, default=60)  # Target response time
    working_hours_only = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())


class SLATracking(Base):
    """SLA tracking for communications"""
    __tablename__ = "sla_tracking"

    id = Column(Integer, primary_key=True)
    communication_id = Column(Integer, ForeignKey('communications.id'))
    sla_rule_id = Column(Integer, ForeignKey('sla_rules.id'))
    client_id = Column(Integer, ForeignKey('clients.id'))
    
    # Timing
    first_response_at = Column(DateTime)  # When first response was sent
    response_time_minutes = Column(Integer)  # Actual response time
    target_time_minutes = Column(Integer)  # Target response time
    
    # Status
    is_within_sla = Column(Boolean, default=True)
    is_breached = Column(Boolean, default=False)
    breached_at = Column(DateTime)
    
    created_at = Column(DateTime, server_default=func.now())


class EmailCampaign(Base):
    """Email marketing campaigns"""
    __tablename__ = "email_campaigns"

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)
    
    # Sender
    from_email = Column(String(120))
    from_name = Column(String(100))
    reply_to = Column(String(120))
    
    # Targeting
    target_type = Column(String(20))  # all, segment, filtered
    target_filter = Column(JSON)  # Filter criteria for recipients
    segment_id = Column(Integer)
    
    # Scheduling
    scheduled_at = Column(DateTime)
    sent_at = Column(DateTime)
    
    # Status
    status = Column(String(20), default="draft")  # draft, scheduled, sending, sent, cancelled
    
    # Stats
    total_recipients = Column(Integer, default=0)
    sent_count = Column(Integer, default=0)
    delivered_count = Column(Integer, default=0)
    opened_count = Column(Integer, default=0)
    clicked_count = Column(Integer, default=0)
    bounced_count = Column(Integer, default=0)
    unsubscribed_count = Column(Integer, default=0)
    
    # Tracking
    track_opens = Column(Boolean, default=True)
    track_clicks = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())


class EmailCampaignRecipient(Base):
    """Individual recipients of email campaigns"""
    __tablename__ = "email_campaign_recipients"

    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey('email_campaigns.id'), nullable=False)
    client_id = Column(Integer, ForeignKey('clients.id'))
    
    # Recipient info
    email = Column(String(120), nullable=False)
    name = Column(String(150))
    
    # Status
    status = Column(String(20), default="pending")  # pending, sent, delivered, opened, clicked, bounced, unsubscribed
    
    # Tracking
    sent_at = Column(DateTime)
    delivered_at = Column(DateTime)
    opened_at = Column(DateTime)
    open_count = Column(Integer, default=0)
    clicked_at = Column(DateTime)
    click_count = Column(Integer, default=0)
    bounced_at = Column(DateTime)
    bounce_reason = Column(Text)
    
    # Tracking pixel ID
    tracking_id = Column(String(64), unique=True)
    
    created_at = Column(DateTime, server_default=func.now())


class EmailTrackingEvent(Base):
    """Email tracking events (opens, clicks)"""
    __tablename__ = "email_tracking_events"

    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey('email_campaigns.id'))
    recipient_id = Column(Integer, ForeignKey('email_campaign_recipients.id'))
    client_id = Column(Integer, ForeignKey('clients.id'))
    
    # Event
    event_type = Column(String(20))  # sent, delivered, opened, clicked, bounced, unsubscribed
    
    # Details
    ip_address = Column(String(45))
    user_agent = Column(String(255))
    link_url = Column(String(500))  # For click events
    
    # Timestamp
    created_at = Column(DateTime, server_default=func.now())
    
    # Status
    is_within_sla = Column(Boolean, default=True)
    is_breached = Column(Boolean, default=False)
    breached_at = Column(DateTime)
    
    created_at = Column(DateTime, server_default=func.now())


class EmailAccount(Base):
    """Email account configuration"""
    __tablename__ = "email_accounts"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    email = Column(String(120), nullable=False)
    imap_server = Column(String(255))
    imap_port = Column(Integer, default=993)
    smtp_server = Column(String(255))
    smtp_port = Column(Integer, default=587)
    password_encrypted = Column(String(255))
    is_active = Column(Boolean, default=True)
    last_sync = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())


# ==================== TASKS ====================

class TaskType(enum.Enum):
    CALL = "call"
    MEETING = "meeting"
    PROPOSAL = "proposal"
    PAYMENT = "payment"
    FOLLOWUP = "followup"
    OTHER = "other"


class TaskPriority(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class Task(Base):
    """Tasks"""
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    
    # Type
    task_type = Column(String(20), default="other")  # call, meeting, proposal, payment, followup
    
    # Assignment
    assignee_id = Column(Integer, ForeignKey('users.id'))
    creator_id = Column(Integer, ForeignKey('users.id'))
    
    # Relations
    client_id = Column(Integer, ForeignKey('clients.id'))
    deal_id = Column(Integer, ForeignKey('deals.id'))
    
    # Scheduling
    due_date = Column(DateTime)
    due_time = Column(Time)
    duration_minutes = Column(Integer)
    reminder_minutes = Column(Integer)  # Reminder before due
    
    # Priority & Status
    priority = Column(String(10), default="medium")
    status = Column(String(20), default="new")  # new, in_progress, completed, cancelled
    
    # Completion
    completed_at = Column(DateTime)
    completed_by = Column(Integer, ForeignKey('users.id'))
    result = Column(Text)  # Task result/notes
    
    # Recurring
    is_recurring = Column(Boolean, default=False)
    recurring_pattern = Column(String(50))  # daily, weekly, monthly
    recurring_end_date = Column(Date)
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    assignee = relationship("User", back_populates="tasks_assigned", foreign_keys=[assignee_id])
    creator = relationship("User", back_populates="tasks_created", foreign_keys=[creator_id])
    client = relationship("Client", back_populates="tasks")
    deal = relationship("Deal", back_populates="tasks")


class TaskKPI(Base):
    """Task KPI metrics per user"""
    __tablename__ = "task_kpis"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    period = Column(String(20))  # daily, weekly, monthly
    period_start = Column(Date)
    period_end = Column(Date)
    
    # Task counts
    total_tasks = Column(Integer, default=0)
    completed_tasks = Column(Integer, default=0)
    overdue_tasks = Column(Integer, default=0)
    cancelled_tasks = Column(Integer, default=0)
    
    # By type
    call_tasks = Column(Integer, default=0)
    meeting_tasks = Column(Integer, default=0)
    proposal_tasks = Column(Integer, default=0)
    payment_tasks = Column(Integer, default=0)
    followup_tasks = Column(Integer, default=0)
    
    # Metrics
    completion_rate = Column(Float, default=0)  # Percentage
    avg_completion_time_hours = Column(Float)
    on_time_rate = Column(Float, default=0)  # Percentage completed on time
    
    created_at = Column(DateTime, server_default=func.now())


# ==================== DOCUMENTS ====================

class DocumentType(enum.Enum):
    CONTRACT = "contract"
    INVOICE = "invoice"
    PROPOSAL = "proposal"
    ACT = "act"
    OTHER = "other"


class Document(Base):
    """Documents"""
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    document_type = Column(String(20), default="other")
    
    # Template
    template_id = Column(Integer, ForeignKey('document_templates.id'))
    
    # Relations
    client_id = Column(Integer, ForeignKey('clients.id'))
    deal_id = Column(Integer, ForeignKey('deals.id'))
    
    # File
    file_path = Column(String(500))
    file_size = Column(Integer)
    
    # Status
    status = Column(String(20), default="draft")  # draft, sent, signed, archived
    
    # Signing
    sent_at = Column(DateTime)
    signed_at = Column(DateTime)
    signed_by = Column(String(150))
    
    # EDO integration
    external_id = Column(String(255))
    edo_status = Column(String(50))
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="documents")
    deal = relationship("Deal", back_populates="documents")
    template = relationship("DocumentTemplate", back_populates="documents")


class DocumentTemplate(Base):
    """Document templates"""
    __tablename__ = "document_templates"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    document_type = Column(String(20))
    content = Column(Text, nullable=False)  # HTML/Markdown template
    variables = Column(JSON)  # ["client_name", "deal_amount", "date"]
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())

    # Relationships
    documents = relationship("Document", back_populates="template")


# ==================== FILES ====================

class File(Base):
    """File attachments"""
    __tablename__ = "files"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    original_name = Column(String(255))
    file_path = Column(String(500), nullable=False)
    file_size = Column(Integer)
    mime_type = Column(String(100))
    
    # Version
    version = Column(Integer, default=1)
    parent_file_id = Column(Integer, ForeignKey('files.id'))
    
    # Relations
    client_id = Column(Integer, ForeignKey('clients.id'))
    deal_id = Column(Integer, ForeignKey('deals.id'))
    task_id = Column(Integer, ForeignKey('tasks.id'))
    uploaded_by = Column(Integer, ForeignKey('users.id'))
    
    # Access
    is_private = Column(Boolean, default=False)
    allowed_roles = Column(JSON)  # ["admin", "manager"]
    
    # Cloud storage
    external_id = Column(String(255))  # ID from cloud provider
    cloud_provider = Column(String(50))  # google_drive, yandex_disk, dropbox
    cloud_url = Column(String(500))  # Public URL in cloud
    synced_at = Column(DateTime)  # Last sync time
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="files")
    deal = relationship("Deal", back_populates="files")


# ==================== CALENDAR ====================

class CalendarEvent(Base):
    """Calendar events"""
    __tablename__ = "calendar_events"

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    
    # Timing
    start_at = Column(DateTime, nullable=False)
    end_at = Column(DateTime)
    is_all_day = Column(Boolean, default=False)
    
    # Recurring
    is_recurring = Column(Boolean, default=False)
    recurring_pattern = Column(String(50))
    recurring_end_date = Column(Date)
    
    # Relations
    client_id = Column(Integer, ForeignKey('clients.id'))
    deal_id = Column(Integer, ForeignKey('deals.id'))
    task_id = Column(Integer, ForeignKey('tasks.id'))
    created_by = Column(Integer, ForeignKey('users.id'))
    
    # Participants
    participants = Column(JSON)  # [{"user_id": 1, "status": "accepted"}]
    
    # Location
    location = Column(String(255))
    is_online = Column(Boolean, default=False)
    meeting_url = Column(String(500))
    
    # External sync
    external_id = Column(String(255))  # Google/Outlook event ID
    external_provider = Column(String(20))  # google, outlook
    
    # Reminders
    reminders = Column(JSON)  # [{"minutes": 15, "type": "notification"}]
    
    # Timestamps
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="events")
    deal = relationship("Deal")
    task = relationship("Task")
    creator = relationship("User")


# ==================== ANALYTICS ====================

class Dashboard(Base):
    """User dashboards"""
    __tablename__ = "dashboards"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'))
    is_default = Column(Boolean, default=False)
    widgets = Column(JSON)  # Widget configurations
    created_at = Column(DateTime, server_default=func.now())


class Report(Base):
    """Saved reports"""
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    report_type = Column(String(50))  # sales, funnel, conversion, etc.
    config = Column(JSON)  # Filters, grouping, etc.
    schedule = Column(String(50))  # daily, weekly, monthly
    recipients = Column(JSON)  # ["email1@example.com"]
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, server_default=func.now())


class KPI(Base):
    """KPI targets"""
    __tablename__ = "kpis"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'))
    team_id = Column(Integer, ForeignKey('teams.id'))
    period = Column(String(20))  # daily, weekly, monthly, quarterly
    target_value = Column(Numeric(15, 2))
    actual_value = Column(Numeric(15, 2))
    metric_type = Column(String(50))  # revenue, deals_count, conversion_rate
    start_date = Column(Date)
    end_date = Column(Date)
    created_at = Column(DateTime, server_default=func.now())


# ==================== ACTIVITY LOG ====================

class Activity(Base):
    """Activity log for all entities"""
    __tablename__ = "activities"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    
    # Entity
    entity_type = Column(String(50))  # client, deal, task, document
    entity_id = Column(Integer)
    
    # Action
    action = Column(String(50))  # created, updated, deleted, viewed
    description = Column(Text)
    old_values = Column(JSON)
    new_values = Column(JSON)
    
    # Context
    ip_address = Column(String(45))
    user_agent = Column(String(255))
    
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    user = relationship("User", back_populates="activities")


# ==================== INTEGRATIONS ====================

class Integration(Base):
    """External integrations"""
    __tablename__ = "integrations"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    integration_type = Column(String(50))  # telephony, email, ads, payment, erp, bi
    config = Column(JSON)  # API keys, endpoints, etc.
    is_active = Column(Boolean, default=True)
    last_sync = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())


class Webhook(Base):
    """Webhooks"""
    __tablename__ = "webhooks"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    url = Column(String(500), nullable=False)
    events = Column(JSON)  # ["deal.created", "task.completed"]
    secret = Column(String(255))
    is_active = Column(Boolean, default=True)
    last_triggered = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())


# ==================== SETTINGS ====================

class CustomField(Base):
    """Custom fields for entities"""
    __tablename__ = "custom_fields"

    id = Column(Integer, primary_key=True)
    entity_type = Column(String(50))  # client, deal, task
    name = Column(String(100), nullable=False)
    field_type = Column(String(20))  # text, number, select, multiselect, date, checkbox
    options = Column(JSON)  # For select/multiselect
    is_required = Column(Boolean, default=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, server_default=func.now())


class Setting(Base):
    """System settings"""
    __tablename__ = "settings"

    id = Column(Integer, primary_key=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(Text)
    category = Column(String(50))  # general, email, telephony, etc.
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now())


# ==================== SCALABILITY ====================

class Office(Base):
    """Offices / Branches"""
    __tablename__ = "offices"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    code = Column(String(20))  # Office code
    address = Column(String(255))
    city = Column(String(100))
    country = Column(String(100))
    phone = Column(String(30))
    email = Column(String(120))
    
    # Manager
    director_id = Column(Integer, ForeignKey('users.id'))
    
    # Legal entity
    legal_entity_id = Column(Integer, ForeignKey('legal_entities.id'))
    
    # Status
    is_active = Column(Boolean, default=True)
    is_headquarters = Column(Boolean, default=False)
    
    # Working hours
    working_hours = Column(JSON)  # {"mon": {"start": "09:00", "end": "18:00"}, ...}
    
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    director = relationship("User", foreign_keys=[director_id])
    legal_entity = relationship("LegalEntity", back_populates="offices")


class LegalEntity(Base):
    """Legal entities for multi-company structure"""
    __tablename__ = "legal_entities"

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    short_name = Column(String(100))
    inn = Column(String(20))  # Tax ID
    kpp = Column(String(20))  # Tax registration reason code
    ogrn = Column(String(20))  # Primary state registration number
    legal_address = Column(String(255))
    physical_address = Column(String(255))
    phone = Column(String(30))
    email = Column(String(120))
    website = Column(String(255))
    
    # Bank details
    bank_name = Column(String(200))
    bank_bik = Column(String(10))
    bank_account = Column(String(30))
    corr_account = Column(String(30))
    
    # Director
    general_director = Column(String(150))
    
    # Status
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    offices = relationship("Office", back_populates="legal_entity")


class BusinessProcess(Base):
    """Business process templates"""
    __tablename__ = "business_processes"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    process_type = Column(String(50))  # deal, task, client, document
    
    # Steps
    steps = Column(JSON)  # [{"name": "Step 1", "action": "...", "assignee_role": "manager"}, ...]
    
    # Triggers
    trigger_type = Column(String(50))  # manual, auto_on_create, auto_on_status
    trigger_config = Column(JSON)
    
    # Settings
    is_active = Column(Boolean, default=True)
    auto_start = Column(Boolean, default=False)
    
    created_at = Column(DateTime, server_default=func.now())


class BusinessProcessInstance(Base):
    """Business process instance (running process)"""
    __tablename__ = "business_process_instances"

    id = Column(Integer, primary_key=True)
    process_id = Column(Integer, ForeignKey('business_processes.id'))
    
    # Entity
    entity_type = Column(String(50))
    entity_id = Column(Integer)
    
    # Progress
    current_step = Column(Integer, default=0)
    status = Column(String(20), default="running")  # running, completed, cancelled
    
    # History
    history = Column(JSON)  # [{"step": 1, "completed_at": "...", "completed_by": 1}, ...]
    
    started_at = Column(DateTime, server_default=func.now())
    completed_at = Column(DateTime)


# ==================== NOTIFICATIONS ====================

class Notification(Base):
    """User notifications"""
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    title = Column(String(200), nullable=False)
    message = Column(Text)
    notification_type = Column(String(50))  # task, deal, system
    entity_type = Column(String(50))
    entity_id = Column(Integer)
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())


# ==================== INITIALIZATION ====================

async def init_db():
    """Initialize database tables"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all, checkfirst=True)


async def seed_default_data():
    """Seed default data (pipelines, stages, etc.)"""
    async with async_session() as session:
        # Check if default pipeline exists
        from sqlalchemy import select
        result = await session.execute(select(Pipeline).where(Pipeline.is_default == True))
        if result.scalar_one_or_none():
            return  # Already seeded
        
        # Create default pipeline
        pipeline = Pipeline(name="Основная воронка", is_default=True)
        session.add(pipeline)
        await session.flush()
        
        # Create default stages
        stages = [
            PipelineStage(pipeline_id=pipeline.id, name="Новый лид", probability=10, sort_order=1, color="#94a3b8"),
            PipelineStage(pipeline_id=pipeline.id, name="Квалификация", probability=20, sort_order=2, color="#f97316"),
            PipelineStage(pipeline_id=pipeline.id, name="Встреча", probability=40, sort_order=3, color="#eab308"),
            PipelineStage(pipeline_id=pipeline.id, name="КП отправлено", probability=60, sort_order=4, color="#3b82f6"),
            PipelineStage(pipeline_id=pipeline.id, name="Переговоры", probability=70, sort_order=5, color="#8b5cf6"),
            PipelineStage(pipeline_id=pipeline.id, name="Договор", probability=90, sort_order=6, color="#06b6d4"),
            PipelineStage(pipeline_id=pipeline.id, name="Успешно", probability=100, sort_order=7, color="#22c55e", is_won=True),
            PipelineStage(pipeline_id=pipeline.id, name="Закрыто", probability=0, sort_order=8, color="#ef4444", is_lost=True),
        ]
        session.add_all(stages)
        
        # Create default document templates
        templates = [
            DocumentTemplate(name="Договор", document_type="contract", content="Шаблон договора"),
            DocumentTemplate(name="Счет", document_type="invoice", content="Шаблон счета"),
            DocumentTemplate(name="Коммерческое предложение", document_type="proposal", content="Шаблон КП"),
            DocumentTemplate(name="Акт", document_type="act", content="Шаблон акта"),
        ]
        session.add_all(templates)
        
        await session.commit()
