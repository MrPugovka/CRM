# main.py - Full CRM Application
from fastapi import FastAPI, Request, Form, HTTPException, status, Query, UploadFile, File as FastAPIFile
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select, func, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, joinedload
from datetime import datetime, date, timedelta
from decimal import Decimal
import json
import os
import uuid
from typing import Optional, List

from models import (
    Base, engine, async_session, init_db, seed_default_data,
    User, Team, Role,
    Client, ClientType, ClientStatus,
    Pipeline, PipelineStage, Deal, DealHistory, DealContact,
    Task, TaskType, TaskPriority,
    Communication, MessageTemplate, EmailAccount,
    Document, DocumentTemplate,
    File,
    CalendarEvent,
    Dashboard, Report, KPI,
    Activity,
    Integration, Webhook,
    CustomField, Setting,
    Notification,
    Automation, AutomationLog,
    SLARule, SLATracking,
    EmailCampaign, EmailCampaignRecipient, EmailTrackingEvent,
    TaskKPI,
    Office, LegalEntity, BusinessProcess, BusinessProcessInstance
)

app = FastAPI(title="CRM System")
templates = Jinja2Templates(directory="templates")

# Create uploads directory if not exists
os.makedirs("uploads", exist_ok=True)

# Mount static files
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


# ==================== STARTUP ====================

@app.on_event("startup")
async def startup():
    await init_db()
    await seed_default_data()


# ==================== CONTEXT PROCESSORS ====================

def get_nav_counts():
    """Get counts for navigation badges"""
    return {}  # Will be populated per request


# ==================== HELPERS ====================

def format_currency(amount, currency="RUB"):
    """Format currency for display"""
    if amount is None:
        return "0 ₽"
    symbols = {"RUB": "₽", "USD": "$", "EUR": "€"}
    return f"{float(amount):,.0f} {symbols.get(currency, currency)}"


def format_date(dt):
    """Format date for display"""
    if not dt:
        return ""
    if isinstance(dt, str):
        return dt
    return dt.strftime("%d.%m.%Y")


def format_datetime(dt):
    """Format datetime for display"""
    if not dt:
        return ""
    if isinstance(dt, str):
        return dt
    return dt.strftime("%d.%m.%Y %H:%M")


templates.env.filters["currency"] = format_currency
templates.env.filters["date"] = format_date
templates.env.filters["datetime"] = format_datetime

# Add globals for templates (use py_date to avoid conflict with date filter)
templates.env.globals["py_date"] = date
templates.env.globals["py_datetime"] = datetime
templates.env.globals["timedelta"] = timedelta


async def log_activity(session, user_id, entity_type, entity_id, action, description, old_values=None, new_values=None):
    """Log activity"""
    activity = Activity(
        user_id=user_id,
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        description=description,
        old_values=old_values,
        new_values=new_values
    )
    session.add(activity)
