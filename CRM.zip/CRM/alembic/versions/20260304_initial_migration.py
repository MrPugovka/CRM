"""
Initial Migration - Create all tables

Revision ID: 20260304_initial
Revises: 
Create Date: 2026-03-04 16:00:00.000000

This migration creates all initial tables for the CRM system:
- companies (multi-tenancy)
- departments, teams (organization structure)
- users, roles, permissions (RBAC)
- refresh_tokens (authentication)
- audit_logs (audit trail)
- notifications, notification_preferences
"""
from typing import Sequence, Union
import uuid

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '20260304_initial'
down_revision: Union[str, None] = None
branch_labels: Union[Sequence[str], None] = None
depends_on: Union[Sequence[str], None] = None


def upgrade() -> None:
    """Create all tables for the CRM system."""
    
    # ==================== Companies (Multi-tenancy) ====================
    op.create_table(
        'companies',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('name', sa.String(150), nullable=False),
        sa.Column('code', sa.String(30), unique=True, nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('website', sa.String(255), nullable=True),
        sa.Column('phone', sa.String(30), nullable=True),
        sa.Column('email', sa.String(120), nullable=True),
        sa.Column('address', sa.Text(), nullable=True),
        sa.Column('logo_url', sa.String(255), nullable=True),
        sa.Column('timezone', sa.String(50), default='UTC'),
        sa.Column('currency', sa.String(3), default='USD'),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_verified', sa.Boolean(), default=False),
        sa.Column('subscription_plan', sa.String(20), default='free'),
        sa.Column('subscription_expires_at', sa.DateTime(), nullable=True),
        sa.Column('settings', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
    )
    op.create_index('ix_companies_code', 'companies', ['code'])
    op.create_index('ix_companies_is_active', 'companies', ['is_active'])
    
    # ==================== Departments ====================
    op.create_table(
        'departments',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('company_id', sa.String(36), sa.ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('code', sa.String(20), unique=True, nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('parent_id', sa.String(36), sa.ForeignKey('departments.id'), nullable=True),
        sa.Column('manager_id', sa.String(36), nullable=True),  # Foreign key added after users table
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
    )
    
    # ==================== Teams ====================
    op.create_table(
        'teams',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('company_id', sa.String(36), sa.ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('department_id', sa.String(36), sa.ForeignKey('departments.id'), nullable=True),
        sa.Column('manager_id', sa.String(36), nullable=True),  # Foreign key added after users table
        sa.Column('parent_team_id', sa.String(36), sa.ForeignKey('teams.id'), nullable=True),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
    )
    
    # ==================== Permissions ====================
    op.create_table(
        'permissions',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('code', sa.String(80), unique=True, nullable=False),
        sa.Column('entity', sa.String(50), nullable=False),
        sa.Column('action', sa.String(20), nullable=False),
        sa.Column('data_scope', sa.String(20), default='all'),
        sa.Column('field_name', sa.String(50), nullable=True),
        sa.Column('field_actions', sa.JSON(), nullable=True),
        sa.Column('restricted_fields', sa.JSON(), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
    )
    
    # ==================== Roles ====================
    op.create_table(
        'roles',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('company_id', sa.String(36), sa.ForeignKey('companies.id', ondelete='CASCADE'), nullable=True, index=True),
        sa.Column('name', sa.String(50), nullable=False, unique=True),
        sa.Column('code', sa.String(30), nullable=False, unique=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('parent_id', sa.String(36), sa.ForeignKey('roles.id'), nullable=True),
        sa.Column('level', sa.Integer(), default=0),
        sa.Column('is_system', sa.Boolean(), default=False),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
    )
    
    # ==================== Role-Permissions Association ====================
    op.create_table(
        'role_permissions',
        sa.Column('role_id', sa.String(36), sa.ForeignKey('roles.id'), primary_key=True),
        sa.Column('permission_id', sa.String(36), sa.ForeignKey('permissions.id'), primary_key=True),
    )
    
    # ==================== Users ====================
    op.create_table(
        'users',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('company_id', sa.String(36), sa.ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True),
        sa.Column('email', sa.String(120), unique=True, nullable=False, index=True),
        sa.Column('password_hash', sa.String(255), nullable=False),
        sa.Column('full_name', sa.String(150), nullable=False),
        sa.Column('phone', sa.String(30), nullable=True),
        sa.Column('avatar', sa.String(255), nullable=True),
        sa.Column('role', sa.String(20), default='employee', nullable=False),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_superuser', sa.Boolean(), default=False),
        sa.Column('email_verified', sa.Boolean(), default=False),
        sa.Column('department_id', sa.String(36), sa.ForeignKey('departments.id'), nullable=True),
        sa.Column('team_id', sa.String(36), sa.ForeignKey('teams.id'), nullable=True),
        sa.Column('last_login', sa.DateTime(), nullable=True),
        sa.Column('login_count', sa.Integer(), default=0),
        sa.Column('failed_login_count', sa.Integer(), default=0),
        sa.Column('locked_until', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
    )
    
    # ==================== User-Roles Association ====================
    op.create_table(
        'user_roles',
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id'), primary_key=True),
        sa.Column('role_id', sa.String(36), sa.ForeignKey('roles.id'), primary_key=True),
    )
    
    # Add foreign key constraints that reference users (after users table exists)
    op.create_foreign_key('fk_departments_manager', 'departments', 'users', ['manager_id'], ['id'])
    op.create_foreign_key('fk_teams_manager', 'teams', 'users', ['manager_id'], ['id'])
    
    # ==================== Refresh Tokens ====================
    op.create_table(
        'refresh_tokens',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('token', sa.String(500), unique=True, nullable=False, index=True),
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('expires_at', sa.DateTime(), nullable=False),
        sa.Column('revoked', sa.Boolean(), default=False),
        sa.Column('revoked_at', sa.DateTime(), nullable=True),
        sa.Column('device_info', sa.String(255), nullable=True),
        sa.Column('ip_address', sa.String(45), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
    )
    
    # ==================== Audit Logs ====================
    op.create_table(
        'audit_logs',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('company_id', sa.String(36), nullable=False, index=True),
        sa.Column('action', sa.String(50), nullable=False),
        sa.Column('entity_type', sa.String(50), nullable=False),
        sa.Column('entity_id', sa.String(36), nullable=True),
        sa.Column('user_id', sa.String(36), nullable=True, index=True),
        sa.Column('user_email', sa.String(120), nullable=True),
        sa.Column('ip_address', sa.String(45), nullable=True),
        sa.Column('user_agent', sa.Text(), nullable=True),
        sa.Column('request_id', sa.String(36), nullable=True, index=True),
        sa.Column('old_values', sa.JSON(), nullable=True),
        sa.Column('new_values', sa.JSON(), nullable=True),
        sa.Column('changes', sa.JSON(), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('meta_data', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_audit_logs_entity', 'audit_logs', ['entity_type', 'entity_id'])
    op.create_index('ix_audit_logs_action', 'audit_logs', ['action'])
    op.create_index('ix_audit_logs_created_at', 'audit_logs', ['created_at'])
    op.create_index('ix_audit_logs_ip', 'audit_logs', ['ip_address'])
    
    # ==================== Notifications ====================
    op.create_table(
        'notifications',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('notification_type', sa.String(50), nullable=False),
        sa.Column('title', sa.String(200), nullable=False),
        sa.Column('message', sa.Text(), nullable=True),
        sa.Column('data', sa.JSON(), nullable=True),
        sa.Column('is_read', sa.Boolean(), default=False),
        sa.Column('read_at', sa.DateTime(), nullable=True),
        sa.Column('sent_via', sa.JSON(), nullable=True),
        sa.Column('sent_at', sa.DateTime(), nullable=True),
        sa.Column('entity_type', sa.String(50), nullable=True),
        sa.Column('entity_id', sa.String(36), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_notifications_user_id', 'notifications', ['user_id'])
    op.create_index('ix_notifications_is_read', 'notifications', ['is_read'])
    op.create_index('ix_notifications_created_at', 'notifications', ['created_at'])
    
    # ==================== Notification Preferences ====================
    op.create_table(
        'notification_preferences',
        sa.Column('id', sa.String(36), primary_key=True, default=lambda: str(uuid.uuid4())),
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id'), nullable=False, unique=True),
        sa.Column('in_app_enabled', sa.Boolean(), default=True),
        sa.Column('email_enabled', sa.Boolean(), default=True),
        sa.Column('push_enabled', sa.Boolean(), default=False),
        sa.Column('task_overdue_enabled', sa.Boolean(), default=True),
        sa.Column('task_reminder_enabled', sa.Boolean(), default=True),
        sa.Column('mention_enabled', sa.Boolean(), default=True),
        sa.Column('deal_status_enabled', sa.Boolean(), default=True),
        sa.Column('system_enabled', sa.Boolean(), default=True),
        sa.Column('quiet_hours_start', sa.String(5), nullable=True),
        sa.Column('quiet_hours_end', sa.String(5), nullable=True),
        sa.Column('quiet_hours_timezone', sa.String(50), default='UTC'),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # ==================== Insert Default Data ====================
    # Insert default system company
    system_company_id = str(uuid.uuid4())
    op.execute(f"""
        INSERT INTO companies (id, name, code, description, is_active, is_verified, subscription_plan)
        VALUES ('{system_company_id}', 'System Company', 'system', 'Default system company', true, true, 'enterprise')
    """)
    
    # Insert default permissions
    default_permissions = [
        (str(uuid.uuid4()), 'View Users', 'users.read', 'users', 'read'),
        (str(uuid.uuid4()), 'Create Users', 'users.create', 'users', 'create'),
        (str(uuid.uuid4()), 'Update Users', 'users.update', 'users', 'update'),
        (str(uuid.uuid4()), 'Delete Users', 'users.delete', 'users', 'delete'),
        (str(uuid.uuid4()), 'View Audit Logs', 'audit.read', 'audit', 'read'),
        (str(uuid.uuid4()), 'System Admin', 'system.admin', 'system', 'admin'),
    ]
    
    for perm_id, name, code, entity, action in default_permissions:
        op.execute(f"""
            INSERT INTO permissions (id, name, code, entity, action, is_active)
            VALUES ('{perm_id}', '{name}', '{code}', '{entity}', '{action}', true)
        """)


def downgrade() -> None:
    """Drop all tables."""
    op.drop_table('notification_preferences')
    op.drop_table('notifications')
    op.drop_table('audit_logs')
    op.drop_table('refresh_tokens')
    op.drop_table('user_roles')
    op.drop_table('role_permissions')
    op.drop_table('users')
    op.drop_table('roles')
    op.drop_table('permissions')
    op.drop_table('teams')
    op.drop_table('departments')
    op.drop_table('companies')
