"""
Make AuditLog.company_id NOT NULL

Revision ID: 20260304_auditlog_company_id_not_null
Revises: 
Create Date: 2026-03-04 16:00:00.000000

This migration:
1. Updates existing NULL company_id values to a default system company
2. Makes company_id column NOT NULL
3. Adds validation to ensure all audit logs have company context
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql, mysql, sqlite

# revision identifiers, used by Alembic.
revision: str = '20260304_make_auditlog_company_id_not_null'
down_revision: str = '20260304_initial'
branch_labels: Union[Sequence[str], None] = None
depends_on: Union[Sequence[str], None] = None


def upgrade() -> None:
    """
    Upgrade: Make company_id NOT NULL
    
    Steps:
    1. First, set a default company_id for existing NULL entries
    2. Then alter the column to be NOT NULL
    """
    # Get database connection
    conn = op.get_bind()
    
    # Set default company_id for existing NULL records
    # Using '00000000-0000-0000-0000-000000000000' as system/default company
    op.execute("""
        UPDATE audit_logs 
        SET company_id = '00000000-0000-0000-0000-000000000000' 
        WHERE company_id IS NULL
    """)
    
    # Make company_id NOT NULL
    # Use batch mode for SQLite compatibility
    dialect = conn.dialect.name
    
    if dialect == 'sqlite':
        # SQLite requires table recreation for column changes
        with op.batch_alter_table('audit_logs') as batch_op:
            batch_op.alter_column(
                'company_id',
                existing_type=sa.String(36),
                nullable=False
            )
    else:
        # PostgreSQL, MySQL, and others
        op.alter_column(
            'audit_logs',
            'company_id',
            existing_type=sa.String(36),
            nullable=False
        )
    
    # Add comment explaining the constraint
    if dialect == 'postgresql':
        op.execute("""
            COMMENT ON COLUMN audit_logs.company_id IS 
            'Company ID for multi-tenancy - REQUIRED for all audit log entries'
        """)


def downgrade() -> None:
    """
    Downgrade: Make company_id NULLable again
    """
    conn = op.get_bind()
    dialect = conn.dialect.name
    
    if dialect == 'sqlite':
        with op.batch_alter_table('audit_logs') as batch_op:
            batch_op.alter_column(
                'company_id',
                existing_type=sa.String(36),
                nullable=True
            )
    else:
        op.alter_column(
            'audit_logs',
            'company_id',
            existing_type=sa.String(36),
            nullable=True
        )