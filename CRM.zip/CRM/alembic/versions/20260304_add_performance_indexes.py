"""
Add Performance Indexes

Revision ID: 20260304_indexes
Revises: 20260304_make_auditlog_company_id_not_null
Create Date: 2026-03-04 16:30:00.000000

This migration adds all performance indexes for the CRM system.
Indexes improve query performance on frequently accessed columns.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = '20260304_indexes'
down_revision: str = '20260304_make_auditlog_company_id_not_null'
branch_labels: Union[Sequence[str], None] = None
depends_on: Union[Sequence[str], None] = None


def upgrade() -> None:
    """Create all performance indexes."""
    
    # ==================== Users ====================
    op.create_index('ix_users_phone', 'users', ['phone'])
    op.create_index('ix_users_status', 'users', ['is_active'])
    op.create_index('ix_users_role', 'users', ['role'])
    op.create_index('ix_users_department_id', 'users', ['department_id'])
    op.create_index('ix_users_team_id', 'users', ['team_id'])
    op.create_index('ix_users_created_at', 'users', ['created_at'])
    
    # ==================== Departments ====================
    op.create_index('ix_departments_company_id', 'departments', ['company_id'])
    op.create_index('ix_departments_parent_id', 'departments', ['parent_id'])
    op.create_index('ix_departments_is_active', 'departments', ['is_active'])
    
    # ==================== Teams ====================
    op.create_index('ix_teams_company_id', 'teams', ['company_id'])
    op.create_index('ix_teams_department_id', 'teams', ['department_id'])
    op.create_index('ix_teams_parent_team_id', 'teams', ['parent_team_id'])
    op.create_index('ix_teams_is_active', 'teams', ['is_active'])
    
    # ==================== Roles ====================
    op.create_index('ix_roles_company_id', 'roles', ['company_id'])
    op.create_index('ix_roles_parent_id', 'roles', ['parent_id'])
    op.create_index('ix_roles_is_system', 'roles', ['is_system'])
    op.create_index('ix_roles_is_active', 'roles', ['is_active'])
    
    # ==================== Permissions ====================
    op.create_index('ix_permissions_entity', 'permissions', ['entity'])
    op.create_index('ix_permissions_action', 'permissions', ['action'])
    op.create_index('ix_permissions_is_active', 'permissions', ['is_active'])
    op.create_index('ix_permissions_code_entity', 'permissions', ['code', 'entity'])
    
    # ==================== Refresh Tokens ====================
    op.create_index('ix_refresh_tokens_user_id', 'refresh_tokens', ['user_id'])
    op.create_index('ix_refresh_tokens_revoked', 'refresh_tokens', ['revoked'])
    op.create_index('ix_refresh_tokens_expires_at', 'refresh_tokens', ['expires_at'])
    
    # ==================== Audit Logs ====================
    # Additional indexes beyond those in initial migration
    op.create_index('ix_audit_logs_user_id_created', 'audit_logs', ['user_id', 'created_at'])
    op.create_index('ix_audit_logs_company_id_created', 'audit_logs', ['company_id', 'created_at'])


def downgrade() -> None:
    """Drop all performance indexes."""
    
    # Users
    op.drop_index('ix_users_phone', table_name='users')
    op.drop_index('ix_users_status', table_name='users')
    op.drop_index('ix_users_role', table_name='users')
    op.drop_index('ix_users_department_id', table_name='users')
    op.drop_index('ix_users_team_id', table_name='users')
    op.drop_index('ix_users_created_at', table_name='users')
    
    # Departments
    op.drop_index('ix_departments_company_id', table_name='departments')
    op.drop_index('ix_departments_parent_id', table_name='departments')
    op.drop_index('ix_departments_is_active', table_name='departments')
    
    # Teams
    op.drop_index('ix_teams_company_id', table_name='teams')
    op.drop_index('ix_teams_department_id', table_name='teams')
    op.drop_index('ix_teams_parent_team_id', table_name='teams')
    op.drop_index('ix_teams_is_active', table_name='teams')
    
    # Roles
    op.drop_index('ix_roles_company_id', table_name='roles')
    op.drop_index('ix_roles_parent_id', table_name='roles')
    op.drop_index('ix_roles_is_system', table_name='roles')
    op.drop_index('ix_roles_is_active', table_name='roles')
    
    # Permissions
    op.drop_index('ix_permissions_entity', table_name='permissions')
    op.drop_index('ix_permissions_action', table_name='permissions')
    op.drop_index('ix_permissions_is_active', table_name='permissions')
    op.drop_index('ix_permissions_code_entity', table_name='permissions')
    
    # Refresh Tokens
    op.drop_index('ix_refresh_tokens_user_id', table_name='refresh_tokens')
    op.drop_index('ix_refresh_tokens_revoked', table_name='refresh_tokens')
    op.drop_index('ix_refresh_tokens_expires_at', table_name='refresh_tokens')
    
    # Audit Logs
    op.drop_index('ix_audit_logs_user_id_created', table_name='audit_logs')
    op.drop_index('ix_audit_logs_company_id_created', table_name='audit_logs')
