"""
Users Module Repository
Data access layer for User, Role, Permission entities
"""
from typing import Optional, List, TypeVar, Type
from uuid import UUID
from datetime import datetime, timezone
from sqlalchemy import select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.modules.users.models import User, Role, Permission, Department, Team, RefreshToken


T = TypeVar("T")


class SoftDeleteMixin:
    """
    Mixin to add soft delete filtering to repository queries.
    Automatically filters out soft-deleted records unless explicitly requested.
    """
    
    @staticmethod
    def filter_not_deleted(query, model_class: Type[T], include_deleted: bool = False):
        """
        Apply soft delete filter to query.
        
        Args:
            query: SQLAlchemy query object
            model_class: The model class being queried
            include_deleted: If True, include soft-deleted records
            
        Returns:
            Filtered query
        """
        if not include_deleted and hasattr(model_class, 'deleted_at'):
            query = query.where(model_class.deleted_at.is_(None))
        return query
    
    @staticmethod
    def filter_active_only(query, model_class: Type[T]):
        """
        Apply filter for active (not deleted and active) records.
        
        Args:
            query: SQLAlchemy query object
            model_class: The model class being queried
            
        Returns:
            Filtered query
        """
        if hasattr(model_class, 'deleted_at'):
            query = query.where(model_class.deleted_at.is_(None))
        if hasattr(model_class, 'is_active'):
            query = query.where(model_class.is_active.is_(True))
        return query


class UserRepository(SoftDeleteMixin):
    """Repository for User entity operations with soft delete filtering"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, user: User) -> User:
        """Create a new user"""
        self.db.add(user)
        await self.db.flush()
        await self.db.refresh(user)
        return user
    
    async def get_by_id(self, user_id: UUID, include_deleted: bool = False) -> Optional[User]:
        """Get user by ID with soft delete filtering"""
        query = select(User).options(
            selectinload(User.roles).selectinload(Role.permissions)
        ).where(User.id == user_id)
        
        query = self.filter_not_deleted(query, User, include_deleted)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_email(self, email: str, include_deleted: bool = False) -> Optional[User]:
        """Get user by email with soft delete filtering"""
        query = select(User).options(
            selectinload(User.roles).selectinload(Role.permissions)
        ).where(User.email == email.lower())
        
        query = self.filter_not_deleted(query, User, include_deleted)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_list(
        self,
        page: int = 1,
        page_size: int = 20,
        search: Optional[str] = None,
        department_id: Optional[UUID] = None,
        team_id: Optional[UUID] = None,
        is_active: Optional[bool] = None,
        include_deleted: bool = False
    ) -> tuple[List[User], int]:
        """Get paginated list of users"""
        query = select(User).options(
            selectinload(User.roles)
        )
        
        # Apply filters
        if not include_deleted:
            query = query.where(User.deleted_at.is_(None))
        
        if search:
            query = query.where(
                or_(
                    User.email.ilike(f"%{search}%"),
                    User.full_name.ilike(f"%{search}%")
                )
            )
        
        if department_id:
            query = query.where(User.department_id == department_id)
        
        if team_id:
            query = query.where(User.team_id == team_id)
        
        if is_active is not None:
            query = query.where(User.is_active == is_active)
        
        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await self.db.scalar(count_query)
        
        # Apply pagination
        query = query.offset((page - 1) * page_size).limit(page_size)
        query = query.order_by(User.created_at.desc())
        
        result = await self.db.execute(query)
        users = list(result.scalars().all())
        
        return users, total or 0
    
    async def update(self, user: User) -> User:
        """Update user"""
        user.updated_at = datetime.now(timezone.utc)
        await self.db.flush()
        await self.db.refresh(user)
        return user
    
    async def soft_delete(self, user_id: UUID) -> bool:
        """Soft delete user"""
        user = await self.get_by_id(user_id)
        if user:
            user.deleted_at = datetime.now(timezone.utc)
            await self.db.flush()
            return True
        return False
    
    async def restore(self, user_id: UUID) -> bool:
        """Restore soft deleted user"""
        user = await self.get_by_id(user_id, include_deleted=True)
        if user and user.deleted_at:
            user.deleted_at = None
            await self.db.flush()
            return True
        return False
    
    async def assign_roles(self, user_id: UUID, role_ids: List[UUID]) -> bool:
        """Assign roles to user with soft delete filtering"""
        user = await self.get_by_id(user_id)
        if not user:
            return False
        
        # Only assign active, non-deleted roles
        query = select(Role).where(Role.id.in_(role_ids))
        query = self.filter_not_deleted(query, Role)
        query = query.where(Role.is_active.is_(True))
        
        roles = await self.db.execute(query)
        user.roles = list(roles.scalars().all())
        await self.db.flush()
        return True


class RoleRepository(SoftDeleteMixin):
    """Repository for Role entity operations with soft delete filtering"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, role: Role) -> Role:
        """Create a new role"""
        self.db.add(role)
        await self.db.flush()
        await self.db.refresh(role)
        return role
    
    async def get_by_id(self, role_id: UUID, include_deleted: bool = False) -> Optional[Role]:
        """Get role by ID with soft delete filtering"""
        query = select(Role).options(
            selectinload(Role.permissions)
        ).where(Role.id == role_id)
        
        query = self.filter_not_deleted(query, Role, include_deleted)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_code(self, code: str, include_deleted: bool = False) -> Optional[Role]:
        """Get role by code with soft delete filtering"""
        query = select(Role).options(
            selectinload(Role.permissions)
        ).where(Role.code == code)
        
        query = self.filter_not_deleted(query, Role, include_deleted)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_list(
        self,
        page: int = 1,
        page_size: int = 20,
        is_active: Optional[bool] = None,
        include_deleted: bool = False
    ) -> tuple[List[Role], int]:
        """Get paginated list of roles with soft delete filtering"""
        query = select(Role).options(selectinload(Role.permissions))
        
        query = self.filter_not_deleted(query, Role, include_deleted)
        
        if is_active is not None:
            query = query.where(Role.is_active == is_active)
        
        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await self.db.scalar(count_query)
        
        # Apply pagination
        query = query.offset((page - 1) * page_size).limit(page_size)
        query = query.order_by(Role.level, Role.name)
        
        result = await self.db.execute(query)
        roles = list(result.scalars().all())
        
        return roles, total or 0
    
    async def get_all_active(self) -> List[Role]:
        """Get all active roles with soft delete filtering"""
        query = select(Role).options(
            selectinload(Role.permissions)
        )
        query = self.filter_active_only(query, Role)
        query = query.order_by(Role.level, Role.name)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def update(self, role: Role) -> Role:
        """Update role"""
        role.updated_at = datetime.now(timezone.utc)
        await self.db.flush()
        await self.db.refresh(role)
        return role
    
    async def delete(self, role_id: UUID) -> bool:
        """Delete role (soft delete for non-system roles)"""
        role = await self.get_by_id(role_id)
        if role and not role.is_system:
            role.deleted_at = datetime.now(timezone.utc)
            await self.db.flush()
            return True
        return False
    
    async def assign_permissions(self, role_id: UUID, permission_ids: List[UUID]) -> bool:
        """Assign permissions to role with soft delete filtering"""
        role = await self.get_by_id(role_id)
        if not role:
            return False
        
        # Only assign active, non-deleted permissions
        query = select(Permission).where(Permission.id.in_(permission_ids))
        query = self.filter_not_deleted(query, Permission)
        query = query.where(Permission.is_active.is_(True))
        
        permissions = await self.db.execute(query)
        role.permissions = list(permissions.scalars().all())
        await self.db.flush()
        return True


class PermissionRepository(SoftDeleteMixin):
    """Repository for Permission entity operations with soft delete filtering"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, permission: Permission) -> Permission:
        """Create a new permission"""
        self.db.add(permission)
        await self.db.flush()
        await self.db.refresh(permission)
        return permission
    
    async def get_by_id(self, permission_id: UUID, include_deleted: bool = False) -> Optional[Permission]:
        """Get permission by ID with soft delete filtering"""
        query = select(Permission).where(Permission.id == permission_id)
        query = self.filter_not_deleted(query, Permission, include_deleted)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_code(self, code: str, include_deleted: bool = False) -> Optional[Permission]:
        """Get permission by code with soft delete filtering"""
        query = select(Permission).where(Permission.code == code)
        query = self.filter_not_deleted(query, Permission, include_deleted)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_list(
        self,
        page: int = 1,
        page_size: int = 50,
        entity: Optional[str] = None,
        is_field_permission: Optional[bool] = None,
        is_active: Optional[bool] = None,
        include_deleted: bool = False
    ) -> tuple[List[Permission], int]:
        """Get paginated list of permissions with soft delete filtering"""
        query = select(Permission)
        
        query = self.filter_not_deleted(query, Permission, include_deleted)
        
        if entity:
            query = query.where(Permission.entity == entity)
        
        if is_field_permission is not None:
            if is_field_permission:
                query = query.where(Permission.field_name.isnot(None))
            else:
                query = query.where(Permission.field_name.is_(None))
        
        if is_active is not None:
            query = query.where(Permission.is_active == is_active)
        
        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await self.db.scalar(count_query)
        
        # Apply pagination
        query = query.offset((page - 1) * page_size).limit(page_size)
        query = query.order_by(Permission.entity, Permission.action)
        
        result = await self.db.execute(query)
        permissions = list(result.scalars().all())
        
        return permissions, total or 0
    
    async def get_by_entity(self, entity: str, include_deleted: bool = False) -> List[Permission]:
        """Get all permissions for an entity with soft delete filtering"""
        query = select(Permission).where(
            Permission.entity == entity
        )
        query = self.filter_not_deleted(query, Permission, include_deleted)
        query = query.where(Permission.is_active == True)
        query = query.order_by(Permission.action)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def get_entities(self) -> List[str]:
        """Get list of all entities that have permissions"""
        query = select(Permission.entity).distinct().order_by(Permission.entity)
        result = await self.db.execute(query)
        return [row[0] for row in result.all()]


class RefreshTokenRepository(SoftDeleteMixin):
    """Repository for RefreshToken entity operations"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, token: RefreshToken) -> RefreshToken:
        """Create a new refresh token"""
        self.db.add(token)
        await self.db.flush()
        await self.db.refresh(token)
        return token
    
    async def get_by_token(self, token: str, include_deleted: bool = False) -> Optional[RefreshToken]:
        """Get refresh token by token string with soft delete filtering"""
        query = select(RefreshToken).where(
            RefreshToken.token == token,
            RefreshToken.revoked == False
        )
        query = self.filter_not_deleted(query, RefreshToken, include_deleted)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def revoke(self, token: str) -> bool:
        """Revoke a refresh token"""
        refresh_token = await self.get_by_token(token)
        if refresh_token:
            refresh_token.revoked = True
            refresh_token.revoked_at = datetime.now(timezone.utc)
            await self.db.flush()
            return True
        return False
    
    async def revoke_all_for_user(self, user_id: UUID) -> int:
        """Revoke all refresh tokens for a user"""
        query = select(RefreshToken).where(
            RefreshToken.user_id == user_id,
            RefreshToken.revoked == False
        )
        query = self.filter_not_deleted(query, RefreshToken)
        result = await self.db.execute(query)
        tokens = result.scalars().all()
        
        count = 0
        for token in tokens:
            token.revoked = True
            token.revoked_at = datetime.now(timezone.utc)
            count += 1
        
        await self.db.flush()
        return count