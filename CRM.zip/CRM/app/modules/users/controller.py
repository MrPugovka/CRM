"""
Users Module Controller
REST API endpoints for User, Role, Permission operations
"""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_user, get_current_active_user, PermissionChecker
from app.modules.users.schemas import (
    UserCreate, UserUpdate, UserResponse, UserListResponse, UserBrief,
    RoleCreate, RoleUpdate, RoleResponse, RoleListResponse, RoleBrief,
    PermissionCreate, PermissionUpdate, PermissionResponse, PermissionListResponse,
    LoginRequest, TokenResponse, RefreshTokenRequest, PasswordChange
)
from app.modules.users.services import UserService, RoleService, PermissionService
from app.modules.users.models import User

router = APIRouter(prefix="/api/v1", tags=["Users & Authentication"])


# ==================== Authentication Endpoints ====================

@router.post("/auth/login", response_model=TokenResponse)
async def login(
    login_data: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """
    Authenticate user and return JWT tokens.
    
    - **email**: User email address
    - **password**: User password
    """
    service = UserService(db)
    try:
        return await service.authenticate(
            email=login_data.email,
            password=login_data.password,
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent")
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )


@router.post("/auth/refresh", response_model=TokenResponse)
async def refresh_token(
    token_data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Refresh access token using refresh token.
    
    - **refresh_token**: Valid refresh token
    """
    service = UserService(db)
    try:
        return await service.refresh_tokens(token_data.refresh_token)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )


@router.post("/auth/logout")
async def logout(
    token_data: RefreshTokenRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Logout user by revoking refresh token.
    
    Requires authentication.
    """
    service = UserService(db)
    await service.logout(token_data.refresh_token, current_user.id)
    return {"message": "Successfully logged out"}


@router.post("/auth/change-password")
async def change_password(
    password_data: PasswordChange,
    current_user: User = Depends(get_current_active_user),
    request: Request = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Change current user's password.
    
    Requires authentication.
    """
    service = UserService(db)
    try:
        await service.change_password(
            user_id=current_user.id,
            password_data=password_data,
            ip_address=request.client.host if request and request.client else None
        )
        return {"message": "Password changed successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/auth/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
):
    """
    Get current authenticated user information.
    
    Requires authentication.
    """
    return UserResponse.model_validate(current_user)


# ==================== User Endpoints ====================

@router.post("/users", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate,
    request: Request,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.write"))
):
    """
    Create a new user.
    
    Requires permission: users.write
    """
    service = UserService(db)
    try:
        user = await service.create_user(
            user_data=user_data,
            created_by_id=current_user.id,
            created_by_email=current_user.email,
            ip_address=request.client.host if request.client else None
        )
        return UserResponse.model_validate(user)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/users", response_model=UserListResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    department_id: Optional[UUID] = None,
    team_id: Optional[UUID] = None,
    is_active: Optional[bool] = None,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.read"))
):
    """
    List users with pagination and filters.
    
    Requires permission: users.read
    """
    service = UserService(db)
    users, total = await service.get_users(
        page=page,
        page_size=page_size,
        search=search,
        department_id=department_id,
        team_id=team_id,
        is_active=is_active
    )
    
    return UserListResponse(
        items=[UserResponse.model_validate(u) for u in users],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )


@router.get("/users/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.read"))
):
    """
    Get user by ID.
    
    Requires permission: users.read
    """
    service = UserService(db)
    user = await service.get_user(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with ID {user_id} not found"
        )
    return UserResponse.model_validate(user)


@router.put("/users/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: UUID,
    user_data: UserUpdate,
    request: Request,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.write"))
):
    """
    Update user.
    
    Requires permission: users.write
    """
    service = UserService(db)
    try:
        user = await service.update_user(
            user_id=user_id,
            user_data=user_data,
            updated_by_id=current_user.id,
            updated_by_email=current_user.email,
            ip_address=request.client.host if request.client else None
        )
        return UserResponse.model_validate(user)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: UUID,
    request: Request,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.delete"))
):
    """
    Soft delete user.
    
    Requires permission: users.delete
    """
    service = UserService(db)
    try:
        await service.delete_user(
            user_id=user_id,
            deleted_by_id=current_user.id,
            deleted_by_email=current_user.email,
            ip_address=request.client.host if request.client else None
        )
        return {"message": "User deleted successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# ==================== Role Endpoints ====================

@router.post("/roles", response_model=RoleResponse, status_code=status.HTTP_201_CREATED)
async def create_role(
    role_data: RoleCreate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.manage_roles"))
):
    """
    Create a new role.
    
    Requires permission: users.manage_roles
    """
    service = RoleService(db)
    try:
        role = await service.create_role(
            role_data=role_data,
            created_by_id=current_user.id
        )
        return RoleResponse.model_validate(role)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/roles", response_model=RoleListResponse)
async def list_roles(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.read"))
):
    """
    List roles with pagination.
    
    Requires permission: users.read
    """
    service = RoleService(db)
    roles, total = await service.get_roles(page=page, page_size=page_size)
    
    return RoleListResponse(
        items=[RoleResponse.model_validate(r) for r in roles],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )


@router.get("/roles/all", response_model=list[RoleBrief])
async def list_all_roles(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    List all active roles (for dropdowns).
    
    Requires authentication.
    """
    service = RoleService(db)
    roles = await service.get_all_active_roles()
    return [RoleBrief.model_validate(r) for r in roles]


@router.get("/roles/{role_id}", response_model=RoleResponse)
async def get_role(
    role_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.read"))
):
    """
    Get role by ID.
    
    Requires permission: users.read
    """
    service = RoleService(db)
    role = await service.get_role(role_id)
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with ID {role_id} not found"
        )
    return RoleResponse.model_validate(role)


@router.put("/roles/{role_id}", response_model=RoleResponse)
async def update_role(
    role_id: UUID,
    role_data: RoleUpdate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.manage_roles"))
):
    """
    Update role.
    
    Requires permission: users.manage_roles
    """
    service = RoleService(db)
    try:
        role = await service.update_role(
            role_id=role_id,
            role_data=role_data,
            updated_by_id=current_user.id
        )
        return RoleResponse.model_validate(role)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete("/roles/{role_id}")
async def delete_role(
    role_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.manage_roles"))
):
    """
    Delete role.
    
    Requires permission: users.manage_roles
    """
    service = RoleService(db)
    try:
        await service.delete_role(role_id=role_id, deleted_by_id=current_user.id)
        return {"message": "Role deleted successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# ==================== Permission Endpoints ====================

@router.post("/permissions", response_model=PermissionResponse, status_code=status.HTTP_201_CREATED)
async def create_permission(
    perm_data: PermissionCreate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.manage_roles"))
):
    """
    Create a new permission.
    
    Requires permission: users.manage_roles
    """
    service = PermissionService(db)
    try:
        permission = await service.create_permission(
            perm_data=perm_data,
            created_by_id=current_user.id
        )
        return PermissionResponse.model_validate(permission)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/permissions", response_model=PermissionListResponse)
async def list_permissions(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    entity: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.read"))
):
    """
    List permissions with pagination.
    
    Requires permission: users.read
    """
    service = PermissionService(db)
    permissions, total = await service.get_permissions(
        page=page,
        page_size=page_size,
        entity=entity
    )
    
    return PermissionListResponse(
        items=[PermissionResponse.model_validate(p) for p in permissions],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )


@router.get("/permissions/entities", response_model=list[str])
async def list_entities(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    List all entities that have permissions.
    
    Requires authentication.
    """
    service = PermissionService(db)
    return await service.get_entities()


@router.get("/permissions/{permission_id}", response_model=PermissionResponse)
async def get_permission(
    permission_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.read"))
):
    """
    Get permission by ID.
    
    Requires permission: users.read
    """
    service = PermissionService(db)
    permission = await service.get_permission(permission_id)
    if not permission:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Permission with ID {permission_id} not found"
        )
    return PermissionResponse.model_validate(permission)


@router.put("/permissions/{permission_id}", response_model=PermissionResponse)
async def update_permission(
    permission_id: UUID,
    perm_data: PermissionUpdate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(PermissionChecker("users.manage_roles"))
):
    """
    Update permission.
    
    Requires permission: users.manage_roles
    """
    service = PermissionService(db)
    try:
        permission = await service.update_permission(
            permission_id=permission_id,
            perm_data=perm_data,
            updated_by_id=current_user.id
        )
        return PermissionResponse.model_validate(permission)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )