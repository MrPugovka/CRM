"""
Users Module Models
User, Role, Permission, Department entities with UUID and soft delete
"""
from sqlalchemy import Column, String, Text, Boolean, Integer, ForeignKey, DateTime, Table, JSON, Enum
from sqlalchemy.orm import relationship
import uuid
import enum

from app.core.database import Base


class UserRole(str, enum.Enum):
    """User role enumeration for multi-tenancy"""
    COMPANY_ADMIN = "company_admin"  # Full access within company
    MANAGER = "manager"              # Management access within company
    EMPLOYEE = "employee"            # Standard employee access
    READONLY = "readonly"            # View-only access


class DataScope(str, enum.Enum):
    """Data visibility scope for permissions"""
    OWN = "own"              # Only own records
    DEPARTMENT = "department"  # Records from user's department
    TEAM = "team"            # Records from user's team
    ALL = "all"              # All records (no restriction)


class PermissionAction(str, enum.Enum):
    """Permission action types"""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    EXPORT = "export"
    ASSIGN = "assign"
    APPROVE = "approve"


# Association table for User-Role many-to-many relationship
# Using String(36) for cross-database compatibility (SQLite, PostgreSQL, MySQL)
user_roles = Table(
    'user_roles',
    Base.metadata,
    Column('user_id', String(36), ForeignKey('users.id'), primary_key=True),
    Column('role_id', String(36), ForeignKey('roles.id'), primary_key=True)
)

# Association table for Role-Permission many-to-many relationship
role_permissions = Table(
    'role_permissions',
    Base.metadata,
    Column('role_id', String(36), ForeignKey('roles.id'), primary_key=True),
    Column('permission_id', String(36), ForeignKey('permissions.id'), primary_key=True)
)


class Company(Base):
    """
    Companies / Organizations for multi-tenancy
    Each company is a separate tenant with isolated data
    """
    __tablename__ = "companies"
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    # Company info
    name = Column(String(150), nullable=False)
    code = Column(String(30), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    website = Column(String(255), nullable=True)
    phone = Column(String(30), nullable=True)
    email = Column(String(120), nullable=True)
    address = Column(Text, nullable=True)
    logo_url = Column(String(255), nullable=True)
    
    # Settings
    timezone = Column(String(50), default='UTC')
    currency = Column(String(3), default='USD')
    
    # Status
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    # Subscription
    subscription_plan = Column(String(20), default='free')
    subscription_expires_at = Column(DateTime, nullable=True)
    
    # Additional settings
    settings = Column(JSON, nullable=True)
    
    # Relationships
    users = relationship("User", back_populates="company", foreign_keys="User.company_id")
    
    def __repr__(self):
        return f"<Company {self.name}>"


class Department(Base):
    """
    Departments / organizational units
    Multi-tenant: Each department belongs to a company
    """
    __tablename__ = "departments"
    
    # Multi-tenancy: Company association (REQUIRED)
    company_id = Column(String(36), ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Override base id to not use autoincrement
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    name = Column(String(100), nullable=False)
    code = Column(String(20), unique=True)  # Short code like "SALES", "IT"
    description = Column(Text)
    parent_id = Column(String(36), ForeignKey('departments.id'))
    manager_id = Column(String(36), ForeignKey('users.id'))
    is_active = Column(Boolean, default=True)
    
    # Relationships
    parent = relationship("Department", remote_side=[id], backref="children")
    manager = relationship("User", foreign_keys=[manager_id], backref="managed_department")
    teams = relationship("Team", back_populates="department")
    
    def __repr__(self):
        return f"<Department {self.name}>"


class User(Base):
    """
    System users / employees
    Multi-tenant: Each user belongs to a company
    """
    __tablename__ = "users"
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    # Multi-tenancy: Company association (REQUIRED)
    company_id = Column(String(36), ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Authentication
    email = Column(String(120), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    
    # Profile
    full_name = Column(String(150), nullable=False)
    phone = Column(String(30))
    avatar = Column(String(255))
    
    # Role assignment for multi-tenancy
    role = Column(String(20), default=UserRole.EMPLOYEE.value, nullable=False)
    
    # Status
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)  # Superuser can access all companies
    email_verified = Column(Boolean, default=False)
    
    # Organization (within company)
    department_id = Column(String(36), ForeignKey('departments.id'))
    team_id = Column(String(36), ForeignKey('teams.id'))
    
    # Authentication tracking
    last_login = Column(DateTime)
    login_count = Column(Integer, default=0)
    failed_login_count = Column(Integer, default=0)
    locked_until = Column(DateTime)
    
    # Relationships
    company = relationship("Company", back_populates="users", foreign_keys=[company_id])
    department = relationship("Department", foreign_keys=[department_id], backref="members")
    team = relationship("Team", back_populates="members", foreign_keys=[team_id])
    roles = relationship("Role", secondary=user_roles, back_populates="users")
    
    def __repr__(self):
        return f"<User {self.email}>"
    
    @property
    def is_deleted(self) -> bool:
        """Check if entity is soft deleted"""
        return self.deleted_at is not None
    
    def has_permission(self, permission_code: str) -> bool:
        """Check if user has a specific permission through any of their roles"""
        if self.is_superuser:
            return True
        
        for role in self.roles:
            for permission in role.permissions:
                if permission.code == permission_code:
                    return True
        return False
    
    def get_all_permissions(self) -> set:
        """Get all permissions from all roles"""
        permissions = set()
        if self.is_superuser:
            return set()  # Superuser has all permissions
        
        for role in self.roles:
            if role.is_active:
                for permission in role.permissions:
                    if permission.is_active:
                        permissions.add(permission.code)
        return permissions


class Team(Base):
    """
    Teams within departments
    Multi-tenant: Each team belongs to a company
    """
    __tablename__ = "teams"
    
    # Multi-tenancy: Company association (REQUIRED)
    company_id = Column(String(36), ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    name = Column(String(100), nullable=False)
    description = Column(Text)
    department_id = Column(String(36), ForeignKey('departments.id'))
    manager_id = Column(String(36), ForeignKey('users.id'))
    parent_team_id = Column(String(36), ForeignKey('teams.id'))
    is_active = Column(Boolean, default=True)
    
    # Relationships
    department = relationship("Department", back_populates="teams")
    members = relationship("User", back_populates="team", foreign_keys="User.team_id")
    manager = relationship("User", foreign_keys=[manager_id])
    
    def __repr__(self):
        return f"<Team {self.name}>"


class Role(Base):
    """
    Custom roles with RBAC support
    Multi-tenant: Each role belongs to a company (or is system-wide)
    """
    __tablename__ = "roles"
    
    # Multi-tenancy: Company association (null for system roles)
    company_id = Column(String(36), ForeignKey('companies.id', ondelete='CASCADE'), nullable=True, index=True)
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    name = Column(String(50), nullable=False, unique=True)
    code = Column(String(30), nullable=False, unique=True)  # Machine-readable code
    description = Column(Text)
    
    # Role hierarchy
    parent_id = Column(String(36), ForeignKey('roles.id'))  # For role inheritance
    level = Column(Integer, default=0)  # Hierarchy level (0 = top)
    
    # Status
    is_system = Column(Boolean, default=False)  # System roles cannot be deleted
    is_active = Column(Boolean, default=True)
    
    # Relationships
    users = relationship("User", secondary=user_roles, back_populates="roles")
    permissions = relationship("Permission", secondary=role_permissions, back_populates="roles")
    parent = relationship("Role", remote_side=[id], backref="children")
    
    def __repr__(self):
        return f"<Role {self.name}>"


class Permission(Base):
    """
    Granular permissions for RBAC with data scope and field restrictions
    """
    __tablename__ = "permissions"
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    name = Column(String(100), nullable=False)
    code = Column(String(80), nullable=False, unique=True)  # e.g., "clients.read", "deals.write"
    
    # Permission scope
    entity = Column(String(50), nullable=False)  # clients, deals, tasks, etc.
    action = Column(String(20), nullable=False)  # read, write, delete, export, etc.
    
    # Data visibility scope - restricts what data user can see/access
    data_scope = Column(String(20), default=DataScope.ALL.value)  # own, team, department, all
    
    # Field-level permissions (optional)
    field_name = Column(String(50))  # If set, this is a field-level permission
    field_actions = Column(JSON)  # ["read", "write"] for specific field
    
    # Field restrictions - fields that cannot be edited
    restricted_fields = Column(JSON)  # ["budget", "status"] - fields user cannot modify
    
    # Description
    description = Column(Text)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Relationships
    roles = relationship("Role", secondary=role_permissions, back_populates="permissions")
    
    def __repr__(self):
        return f"<Permission {self.code}>"
    
    def check_data_access(self, user: 'User', entity_owner_id: str = None, 
                          entity_department_id: str = None, entity_team_id: str = None) -> bool:
        """
        Check if user can access entity based on data scope
        
        Args:
            user: User requesting access
            entity_owner_id: ID of entity owner/creator
            entity_department_id: ID of department that owns entity
            entity_team_id: ID of team that owns entity
        
        Returns:
            True if user can access, False otherwise
        """
        scope = DataScope(self.data_scope)
        
        if scope == DataScope.ALL:
            return True
        
        if scope == DataScope.OWN:
            return entity_owner_id == user.id
        
        if scope == DataScope.DEPARTMENT:
            return entity_department_id == user.department_id
        
        if scope == DataScope.TEAM:
            return entity_team_id == user.team_id
        
        return False
    
    def get_allowed_fields(self, action: str = 'read') -> tuple:
        """
        Get allowed and restricted fields for an action
        
        Args:
            action: Action to check (read, update)
        
        Returns:
            Tuple of (allowed_fields, restricted_fields)
        """
        if self.field_name:
            # This is a field-level permission
            field_actions = self.field_actions or []
            if action in field_actions:
                return ([self.field_name], [])
            else:
                return ([], [self.field_name])
        
        # Entity-level permission
        restricted = self.restricted_fields or []
        return ([], restricted)


class RefreshToken(Base):
    """
    JWT Refresh tokens for authentication
    """
    __tablename__ = "refresh_tokens"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    
    token = Column(String(500), unique=True, nullable=False, index=True)
    user_id = Column(String(36), ForeignKey('users.id'), nullable=False)
    
    expires_at = Column(DateTime, nullable=False)
    revoked = Column(Boolean, default=False)
    revoked_at = Column(DateTime)
    
    # Device/Session info
    device_info = Column(String(255))
    ip_address = Column(String(45))
    
    # Relationships
    user = relationship("User", backref="refresh_tokens")
    
    def __repr__(self):
        return f"<RefreshToken {self.id}>"