"""
Users Module Service
Business logic layer for User, Role, Permission operations
"""
from typing import Optional, List
from uuid import UUID
from datetime import datetime, timedelta, timezone
import secrets

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    hash_password, verify_password, decode_token
)
from app.core.audit import AuditService, AuditAction
from app.modules.users.models import User, Role, Permission, Department, Team, RefreshToken
from app.modules.users.repository import (
    UserRepository, RoleRepository, PermissionRepository, RefreshTokenRepository
)
from app.modules.users.schemas import (
    UserCreate, UserUpdate, UserResponse,
    RoleCreate, RoleUpdate, RoleResponse,
    PermissionCreate, PermissionUpdate, PermissionResponse,
    LoginRequest, TokenResponse, PasswordChange
)


class UserService:
    """Service for User operations"""
    
    def __init__(self, db: AsyncSession, auth_service=None):
        self.db = db
        self.user_repo = UserRepository(db)
        self.role_repo = RoleRepository(db)
        self.token_repo = RefreshTokenRepository(db)
        self.audit = AuditService(db)
        self._auth_service = auth_service
    
    def _create_access_token(self, user_id: UUID, additional_claims: dict = None) -> str:
        """Create access token using AuthService if available, otherwise create directly"""
        if self._auth_service:
            return self._auth_service.create_access_token(user_id)
        # Fallback to direct creation (for backward compatibility during transition)
        from app.core.security import create_access_token
        return create_access_token(subject=str(user_id), additional_claims=additional_claims)
    
    def _create_refresh_token(self, user_id: UUID) -> str:
        """Create refresh token using AuthService if available, otherwise create directly"""
        if self._auth_service:
            return self._auth_service.create_refresh_token(user_id)
        # Fallback to direct creation (for backward compatibility during transition)
        from app.core.security import create_refresh_token
        return create_refresh_token(subject=str(user_id))
    
    async def create_user(
        self,
        user_data: UserCreate,
        created_by_id: Optional[UUID] = None,
        created_by_email: Optional[str] = None,
        ip_address: Optional[str] = None,
        company_id: Optional[UUID] = None
    ) -> User:
        """Create a new user with company_id validation"""
        # Check if email already exists
        existing = await self.user_repo.get_by_email(user_data.email)
        if existing:
            raise ValueError(f"User with email {user_data.email} already exists")
        
        # Validate company_id is provided
        if not company_id:
            raise ValueError("company_id is required for user creation")
        
        # Create user with company_id
        user = User(
            email=user_data.email.lower(),
            password_hash=hash_password(user_data.password),
            full_name=user_data.full_name,
            phone=user_data.phone,
            role=user_data.role,
            department_id=user_data.department_id,
            team_id=user_data.team_id,
            company_id=company_id
        )
        
        user = await self.user_repo.create(user)
        
        # Assign roles
        if user_data.role_ids:
            await self.user_repo.assign_roles(user.id, user_data.role_ids)
        
        # Audit log with required company_id
        await self.audit.log_create(
            entity_type="user",
            entity_id=str(user.id),
            new_values={"email": user.email, "full_name": user.full_name},
            company_id=str(company_id),  # REQUIRED
            user_id=str(created_by_id) if created_by_id else None,
            user_email=created_by_email,
            ip_address=ip_address
        )
        
        # Explicit commit (since get_db no longer auto-commits)
        await self.db.commit()
        
        return user
    
    async def get_user(self, user_id: UUID) -> Optional[User]:
        """Get user by ID"""
        return await self.user_repo.get_by_id(user_id)
    
    async def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email"""
        return await self.user_repo.get_by_email(email)
    
    async def get_users(
        self,
        page: int = 1,
        page_size: int = 20,
        search: Optional[str] = None,
        department_id: Optional[UUID] = None,
        team_id: Optional[UUID] = None,
        is_active: Optional[bool] = None
    ) -> tuple[List[User], int]:
        """Get paginated list of users"""
        return await self.user_repo.get_list(
            page=page,
            page_size=page_size,
            search=search,
            department_id=department_id,
            team_id=team_id,
            is_active=is_active
        )
    
    async def update_user(
        self,
        user_id: UUID,
        user_data: UserUpdate,
        updated_by_id: Optional[UUID] = None,
        updated_by_email: Optional[str] = None,
        ip_address: Optional[str] = None
    ) -> User:
        """Update user"""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ValueError(f"User with ID {user_id} not found")
        
        # Store old values for audit
        old_values = {
            "email": user.email,
            "full_name": user.full_name,
            "phone": user.phone,
            "role": user.role,
            "is_active": user.is_active
        }
        
        # Update fields
        if user_data.email is not None:
            existing = await self.user_repo.get_by_email(user_data.email)
            if existing and existing.id != user_id:
                raise ValueError(f"Email {user_data.email} already in use")
            user.email = user_data.email.lower()
        
        if user_data.full_name is not None:
            user.full_name = user_data.full_name
        
        if user_data.phone is not None:
            user.phone = user_data.phone
        
        if user_data.role is not None:
            user.role = user_data.role
        
        if user_data.department_id is not None:
            user.department_id = user_data.department_id
        
        if user_data.team_id is not None:
            user.team_id = user_data.team_id
        
        if user_data.is_active is not None:
            user.is_active = user_data.is_active
        
        user = await self.user_repo.update(user)
        
        # Update roles
        if user_data.role_ids is not None:
            await self.user_repo.assign_roles(user_id, user_data.role_ids)
        
        # New values for audit
        new_values = {
            "email": user.email,
            "full_name": user.full_name,
            "phone": user.phone,
            "role": user.role,
            "is_active": user.is_active
        }
        
        # Audit log with required company_id
        await self.audit.log_update(
            entity_type="user",
            entity_id=str(user.id),
            old_values=old_values,
            new_values=new_values,
            changes={k: {"old": old_values[k], "new": new_values[k]} 
                    for k in old_values if old_values[k] != new_values[k]},
            company_id=str(user.company_id),  # REQUIRED
            user_id=str(updated_by_id) if updated_by_id else None,
            user_email=updated_by_email,
            ip_address=ip_address
        )
        
        # Explicit commit
        await self.db.commit()
        
        return user
    
    async def delete_user(
        self,
        user_id: UUID,
        deleted_by_id: Optional[UUID] = None,
        deleted_by_email: Optional[str] = None,
        ip_address: Optional[str] = None
    ) -> bool:
        """Soft delete user"""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ValueError(f"User with ID {user_id} not found")
        
        # User must have company_id for audit logging
        if not user.company_id:
            raise ValueError("Cannot delete user without company_id")
        
        # Revoke all refresh tokens
        await self.token_repo.revoke_all_for_user(user_id)
        
        # Soft delete
        result = await self.user_repo.soft_delete(user_id)
        
        if result:
            # Audit log with required company_id
            await self.audit.log_delete(
                entity_type="user",
                entity_id=str(user_id),
                old_values={"email": user.email, "full_name": user.full_name},
                company_id=str(user.company_id),  # REQUIRED
                user_id=str(deleted_by_id) if deleted_by_id else None,
                user_email=deleted_by_email,
                ip_address=ip_address,
                soft=True
            )
        
        # Explicit commit
        await self.db.commit()
        
        return result
    
    async def authenticate(
        self,
        email: str,
        password: str,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> TokenResponse:
        """Authenticate user and return tokens"""
        user = await self.user_repo.get_by_email(email)
        
        if not user or not verify_password(password, user.password_hash):
            raise ValueError("Invalid email or password")
        
        if not user.is_active:
            raise ValueError("User account is disabled")
        
        if user.deleted_at:
            raise ValueError("User account has been deleted")
        
        # Generate tokens with company context
        additional_claims = {
            "email": user.email,
            "role": user.role,
            "roles": [r.code for r in user.roles],
        }
        
        # Add company_id to token if user belongs to a company
        if user.company_id:
            additional_claims["company_id"] = str(user.company_id)
        
        # Use AuthService for token creation if available (single point of JWT generation)
        if self._auth_service:
            access_token = self._auth_service.create_access_token(user.id)
            refresh_token = self._auth_service.create_refresh_token(user.id)
        else:
            # Fallback to direct creation for backward compatibility
            from app.core.security import create_access_token, create_refresh_token
            access_token = create_access_token(
                subject=str(user.id),
                additional_claims=additional_claims
            )
            refresh_token = create_refresh_token(subject=str(user.id))
        
        # Store refresh token
        import uuid
        token_record = RefreshToken(
            id=str(uuid.uuid4()),
            token=refresh_token,
            user_id=user.id,
            expires_at=datetime.now(timezone.utc) + timedelta(days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS),
            ip_address=ip_address,
            device_info=user_agent
        )
        await self.token_repo.create(token_record)
        
        # Update login stats
        user.last_login = datetime.now(timezone.utc)
        user.login_count = (user.login_count or 0) + 1
        await self.user_repo.update(user)
        
        # Audit log with required company_id
        if not user.company_id:
            raise ValueError("User must have company_id to login")
        
        await self.audit.log_login(
            user_id=str(user.id),
            user_email=user.email,
            company_id=str(user.company_id),  # REQUIRED
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        # Explicit commit for login stats and token storage
        await self.db.commit()
        
        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            user=UserResponse.model_validate(user)
        )
    
    async def refresh_tokens(self, refresh_token: str) -> TokenResponse:
        """Refresh access token using refresh token"""
        # Validate refresh token
        token_record = await self.token_repo.get_by_token(refresh_token)
        
        if not token_record:
            raise ValueError("Invalid refresh token")
        
        if token_record.expires_at < datetime.now(timezone.utc):
            raise ValueError("Refresh token has expired")
        
        # Get user
        user = await self.user_repo.get_by_id(token_record.user_id)
        if not user or not user.is_active or user.deleted_at:
            raise ValueError("User not found or inactive")
        
        # Revoke old token
        await self.token_repo.revoke(refresh_token)
        
        # Generate new tokens with company context
        additional_claims = {
            "email": user.email,
            "role": user.role,
            "roles": [r.code for r in user.roles],
        }
        
        # Add company_id to token if user belongs to a company
        if user.company_id:
            additional_claims["company_id"] = str(user.company_id)
        
        # Use AuthService for token creation if available (single point of JWT generation)
        if self._auth_service:
            new_access_token = self._auth_service.create_access_token(user.id)
            new_refresh_token = self._auth_service.create_refresh_token(user.id)
        else:
            # Fallback to direct creation for backward compatibility
            from app.core.security import create_access_token, create_refresh_token
            new_access_token = create_access_token(
                subject=str(user.id),
                additional_claims=additional_claims
            )
            new_refresh_token = create_refresh_token(subject=str(user.id))
        
        # Store new refresh token
        new_token_record = RefreshToken(
            token=new_refresh_token,
            user_id=user.id,
            expires_at=datetime.now(timezone.utc) + timedelta(days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS)
        )
        await self.token_repo.create(new_token_record)
        
        # Explicit commit
        await self.db.commit()
        
        return TokenResponse(
            access_token=new_access_token,
            refresh_token=new_refresh_token,
            expires_in=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            user=UserResponse.model_validate(user)
        )
    
    async def logout(self, refresh_token: str, user_id: UUID, company_id: str) -> bool:
        """Logout user by revoking refresh token"""
        # Get user for company_id
        user = await self.user_repo.get_by_id(user_id)
        if not user or not user.company_id:
            raise ValueError("User must have company_id for audit logging")
        
        await self.audit.log_logout(
            user_id=str(user_id),
            user_email=user.email,
            company_id=str(user.company_id)  # REQUIRED
        )
        result = await self.token_repo.revoke(refresh_token)
        await self.db.commit()
        return result
    
    async def change_password(
        self,
        user_id: UUID,
        password_data: PasswordChange,
        ip_address: Optional[str] = None
    ) -> bool:
        """Change user password"""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ValueError("User not found")
        
        if not verify_password(password_data.current_password, user.password_hash):
            raise ValueError("Current password is incorrect")
        
        user.password_hash = hash_password(password_data.new_password)
        await self.user_repo.update(user)
        
        # Revoke all refresh tokens (force re-login)
        await self.token_repo.revoke_all_for_user(user_id)
        
        # Audit log with required company_id
        if not user.company_id:
            raise ValueError("User must have company_id for audit logging")
        
        await self.audit.log(
            action=AuditAction.UPDATE,
            entity_type="user",
            entity_id=str(user_id),
            company_id=str(user.company_id),  # REQUIRED
            description="Password changed",
            ip_address=ip_address
        )
        
        # Explicit commit
        await self.db.commit()
        
        return True
    
    async def check_permission(self, user_id: UUID, permission_code: str) -> bool:
        """Check if user has a specific permission"""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            return False
        
        return user.has_permission(permission_code)


class RoleService:
    """Service for Role operations"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        self.role_repo = RoleRepository(db)
        self.audit = AuditService(db)
    
    async def create_role(
        self,
        role_data: RoleCreate,
        created_by_id: Optional[UUID] = None,
        company_id: Optional[str] = None
    ) -> Role:
        """Create a new role"""
        # Check if code already exists
        existing = await self.role_repo.get_by_code(role_data.code)
        if existing:
            raise ValueError(f"Role with code {role_data.code} already exists")
        
        role = Role(
            name=role_data.name,
            code=role_data.code,
            description=role_data.description,
            level=role_data.level,
            parent_id=role_data.parent_id
        )
        
        role = await self.role_repo.create(role)
        
        # Assign permissions
        if role_data.permission_ids:
            await self.role_repo.assign_permissions(role.id, role_data.permission_ids)
        
        # Audit log - company_id required
        if not company_id:
            raise ValueError("company_id is required for role creation audit log")
        
        await self.audit.log_create(
            entity_type="role",
            entity_id=str(role.id),
            new_values={"name": role.name, "code": role.code},
            company_id=company_id,  # REQUIRED
            user_id=str(created_by_id) if created_by_id else None
        )
        
        # Explicit commit
        await self.db.commit()
        
        return role
    
    async def get_role(self, role_id: UUID) -> Optional[Role]:
        """Get role by ID"""
        return await self.role_repo.get_by_id(role_id)
    
    async def get_roles(self, page: int = 1, page_size: int = 20) -> tuple[List[Role], int]:
        """Get paginated list of roles"""
        return await self.role_repo.get_list(page=page, page_size=page_size)
    
    async def get_all_active_roles(self) -> List[Role]:
        """Get all active roles"""
        return await self.role_repo.get_all_active()
    
    async def update_role(
        self,
        role_id: UUID,
        role_data: RoleUpdate,
        updated_by_id: Optional[UUID] = None,
        company_id: Optional[str] = None
    ) -> Role:
        """Update role"""
        role = await self.role_repo.get_by_id(role_id)
        if not role:
            raise ValueError(f"Role with ID {role_id} not found")
        
        if role.is_system:
            raise ValueError("Cannot modify system role")
        
        old_values = {"name": role.name, "description": role.description}
        
        if role_data.name is not None:
            role.name = role_data.name
        if role_data.description is not None:
            role.description = role_data.description
        if role_data.level is not None:
            role.level = role_data.level
        if role_data.parent_id is not None:
            role.parent_id = role_data.parent_id
        if role_data.is_active is not None:
            role.is_active = role_data.is_active
        
        role = await self.role_repo.update(role)
        
        if role_data.permission_ids is not None:
            await self.role_repo.assign_permissions(role_id, role_data.permission_ids)
        
        # Audit log - company_id required
        if not company_id:
            raise ValueError("company_id is required for role update audit log")
        
        await self.audit.log_update(
            entity_type="role",
            entity_id=str(role.id),
            old_values=old_values,
            new_values={"name": role.name, "description": role.description},
            company_id=company_id,  # REQUIRED
            user_id=str(updated_by_id) if updated_by_id else None
        )
        
        # Explicit commit
        await self.db.commit()
        
        return role
    
    async def delete_role(
        self,
        role_id: UUID,
        deleted_by_id: Optional[UUID] = None,
        company_id: Optional[str] = None
    ) -> bool:
        """Delete role"""
        role = await self.role_repo.get_by_id(role_id)
        if not role:
            raise ValueError(f"Role with ID {role_id} not found")
        
        if role.is_system:
            raise ValueError("Cannot delete system role")
        
        result = await self.role_repo.delete(role_id)
        
        if result:
            # Audit log - company_id required
            if not company_id:
                raise ValueError("company_id is required for role deletion audit log")
            
            await self.audit.log_delete(
                entity_type="role",
                entity_id=str(role_id),
                old_values={"name": role.name, "code": role.code},
                company_id=company_id,  # REQUIRED
                user_id=str(deleted_by_id) if deleted_by_id else None,
                soft=True
            )
            # Explicit commit
            await self.db.commit()
        
        return result


class PermissionService:
    """Service for Permission operations"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        self.perm_repo = PermissionRepository(db)
        self.audit = AuditService(db)
    
    async def create_permission(
        self,
        perm_data: PermissionCreate,
        created_by_id: Optional[UUID] = None,
        company_id: Optional[str] = None
    ) -> Permission:
        """Create a new permission"""
        # Check if code already exists
        existing = await self.perm_repo.get_by_code(perm_data.code)
        if existing:
            raise ValueError(f"Permission with code {perm_data.code} already exists")
        
        permission = Permission(
            name=perm_data.name,
            code=perm_data.code,
            entity=perm_data.entity,
            action=perm_data.action,
            field_name=perm_data.field_name,
            field_actions=perm_data.field_actions,
            description=perm_data.description
        )
        
        permission = await self.perm_repo.create(permission)
        
        # Audit log - company_id required
        if not company_id:
            raise ValueError("company_id is required for permission creation audit log")
        
        await self.audit.log_create(
            entity_type="permission",
            entity_id=str(permission.id),
            new_values={"name": permission.name, "code": permission.code},
            company_id=company_id,  # REQUIRED
            user_id=str(created_by_id) if created_by_id else None
        )
        
        # Explicit commit
        await self.db.commit()
        
        return permission
    
    async def get_permission(self, permission_id: UUID) -> Optional[Permission]:
        """Get permission by ID"""
        return await self.perm_repo.get_by_id(permission_id)
    
    async def get_permissions(
        self,
        page: int = 1,
        page_size: int = 50,
        entity: Optional[str] = None
    ) -> tuple[List[Permission], int]:
        """Get paginated list of permissions"""
        return await self.perm_repo.get_list(page=page, page_size=page_size, entity=entity)
    
    async def get_entities(self) -> List[str]:
        """Get list of all entities"""
        return await self.perm_repo.get_entities()
    
    async def update_permission(
        self,
        permission_id: UUID,
        perm_data: PermissionUpdate,
        updated_by_id: Optional[UUID] = None,
        company_id: Optional[str] = None
    ) -> Permission:
        """Update permission"""
        permission = await self.perm_repo.get_by_id(permission_id)
        if not permission:
            raise ValueError(f"Permission with ID {permission_id} not found")
        
        old_values = {"name": permission.name, "description": permission.description}
        
        if perm_data.name is not None:
            permission.name = perm_data.name
        if perm_data.description is not None:
            permission.description = perm_data.description
        if perm_data.is_active is not None:
            permission.is_active = perm_data.is_active
        if perm_data.field_actions is not None:
            permission.field_actions = perm_data.field_actions
        
        await self.db.flush()
        
        # Audit log - company_id required
        if not company_id:
            raise ValueError("company_id is required for permission update audit log")
        
        await self.audit.log_update(
            entity_type="permission",
            entity_id=str(permission.id),
            old_values=old_values,
            new_values={"name": permission.name, "description": permission.description},
            company_id=company_id,  # REQUIRED
            user_id=str(updated_by_id) if updated_by_id else None
        )
        
        # Explicit commit
        await self.db.commit()
        
        return permission