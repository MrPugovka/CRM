"""
Users Module Schemas (DTOs)
Pydantic models for request/response validation
"""
from pydantic import BaseModel, Field, EmailStr, field_validator
from typing import Optional, List
from datetime import datetime
from uuid import UUID
import re


# ==================== Permission Schemas ====================

class PermissionBase(BaseModel):
    """Base permission schema"""
    name: str = Field(..., min_length=1, max_length=100)
    code: str = Field(..., min_length=1, max_length=80)
    entity: str = Field(..., min_length=1, max_length=50)
    action: str = Field(..., min_length=1, max_length=20)
    data_scope: str = Field(default="all", description="Data visibility scope: own, team, department, all")
    field_name: Optional[str] = Field(None, max_length=50)
    field_actions: Optional[List[str]] = None
    restricted_fields: Optional[List[str]] = Field(None, description="Fields that cannot be modified")
    description: Optional[str] = None
    
    @field_validator('code')
    @classmethod
    def validate_code(cls, v):
        if not re.match(r'^[a-z_]+\.[a-z_]+$', v):
            raise ValueError('Code must be in format "entity.action" (e.g., "clients.read")')
        return v
    
    @field_validator('data_scope')
    @classmethod
    def validate_data_scope(cls, v):
        valid_scopes = ['own', 'team', 'department', 'all']
        if v not in valid_scopes:
            raise ValueError(f'data_scope must be one of: {valid_scopes}')
        return v


class PermissionCreate(PermissionBase):
    """Schema for creating a permission"""
    pass


class PermissionUpdate(BaseModel):
    """Schema for updating a permission"""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    data_scope: Optional[str] = None
    field_actions: Optional[List[str]] = None
    restricted_fields: Optional[List[str]] = None
    
    @field_validator('data_scope')
    @classmethod
    def validate_data_scope(cls, v):
        if v is not None:
            valid_scopes = ['own', 'team', 'department', 'all']
            if v not in valid_scopes:
                raise ValueError(f'data_scope must be one of: {valid_scopes}')
        return v


class PermissionResponse(PermissionBase):
    """Schema for permission response"""
    id: UUID
    is_active: bool
    created_at: datetime
    
    model_config = {"from_attributes": True}


# ==================== Role Schemas ====================

class RoleBase(BaseModel):
    """Base role schema"""
    name: str = Field(..., min_length=1, max_length=50)
    code: str = Field(..., min_length=1, max_length=30)
    description: Optional[str] = None
    level: int = Field(default=0, ge=0)
    
    @field_validator('code')
    @classmethod
    def validate_code(cls, v):
        if not re.match(r'^[a-z_]+$', v):
            raise ValueError('Code must contain only lowercase letters and underscores')
        return v


class RoleCreate(RoleBase):
    """Schema for creating a role"""
    parent_id: Optional[UUID] = None
    permission_ids: Optional[List[UUID]] = None


class RoleUpdate(BaseModel):
    """Schema for updating a role"""
    name: Optional[str] = Field(None, min_length=1, max_length=50)
    description: Optional[str] = None
    level: Optional[int] = Field(None, ge=0)
    parent_id: Optional[UUID] = None
    is_active: Optional[bool] = None
    permission_ids: Optional[List[UUID]] = None


class RoleResponse(RoleBase):
    """Schema for role response"""
    id: UUID
    is_system: bool
    is_active: bool
    parent_id: Optional[UUID]
    permissions: List[PermissionResponse] = []
    created_at: datetime
    updated_at: Optional[datetime]
    
    model_config = {"from_attributes": True}


class RoleBrief(BaseModel):
    """Brief role info for nested responses"""
    id: UUID
    name: str
    code: str
    
    model_config = {"from_attributes": True}


# ==================== Department Schemas ====================

class DepartmentBase(BaseModel):
    """Base department schema"""
    name: str = Field(..., min_length=1, max_length=100)
    code: Optional[str] = Field(None, max_length=20)
    description: Optional[str] = None
    
    @field_validator('code')
    @classmethod
    def validate_code(cls, v):
        if v and not re.match(r'^[A-Z_]+$', v):
            raise ValueError('Code must contain only uppercase letters and underscores')
        return v


class DepartmentCreate(DepartmentBase):
    """Schema for creating a department"""
    parent_id: Optional[UUID] = None
    manager_id: Optional[UUID] = None


class DepartmentUpdate(BaseModel):
    """Schema for updating a department"""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    code: Optional[str] = Field(None, max_length=20)
    description: Optional[str] = None
    parent_id: Optional[UUID] = None
    manager_id: Optional[UUID] = None
    is_active: Optional[bool] = None


class DepartmentResponse(DepartmentBase):
    """Schema for department response"""
    id: UUID
    parent_id: Optional[UUID]
    manager_id: Optional[UUID]
    is_active: bool
    created_at: datetime
    
    model_config = {"from_attributes": True}


# ==================== User Schemas ====================

class UserBase(BaseModel):
    """Base user schema"""
    email: EmailStr
    full_name: str = Field(..., min_length=1, max_length=150)
    phone: Optional[str] = Field(None, max_length=30)
    role: str = Field(default="employee")


class UserCreate(UserBase):
    """Schema for creating a user"""
    password: str = Field(..., min_length=8, max_length=100)
    department_id: Optional[UUID] = None
    team_id: Optional[UUID] = None
    role_ids: Optional[List[UUID]] = None
    
    @field_validator('password')
    @classmethod
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one digit')
        return v


class UserUpdate(BaseModel):
    """Schema for updating a user"""
    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, min_length=1, max_length=150)
    phone: Optional[str] = Field(None, max_length=30)
    avatar: Optional[str] = None
    role: Optional[str] = None
    department_id: Optional[UUID] = None
    team_id: Optional[UUID] = None
    is_active: Optional[bool] = None
    role_ids: Optional[List[UUID]] = None


class UserResponse(UserBase):
    """Schema for user response"""
    id: UUID
    avatar: Optional[str]
    is_active: bool
    email_verified: Optional[bool] = False
    department_id: Optional[UUID]
    team_id: Optional[UUID]
    roles: List[RoleBrief] = []
    created_at: datetime
    updated_at: Optional[datetime]
    last_login: Optional[datetime]
    
    model_config = {"from_attributes": True}


class UserBrief(BaseModel):
    """Brief user info for nested responses"""
    id: UUID
    email: EmailStr
    full_name: str
    avatar: Optional[str]
    
    model_config = {"from_attributes": True}


# ==================== Authentication Schemas ====================

class LoginRequest(BaseModel):
    """Login request schema"""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Token response schema"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse


class RefreshTokenRequest(BaseModel):
    """Refresh token request schema"""
    refresh_token: str


class PasswordChange(BaseModel):
    """Password change request"""
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=100)
    
    @field_validator('new_password')
    @classmethod
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one digit')
        return v


class PasswordReset(BaseModel):
    """Password reset request"""
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    """Password reset confirmation"""
    token: str
    new_password: str = Field(..., min_length=8, max_length=100)


# ==================== List/Pagination Schemas ====================

class UserListResponse(BaseModel):
    """Paginated user list response"""
    items: List[UserResponse]
    total: int
    page: int
    page_size: int
    pages: int


class RoleListResponse(BaseModel):
    """Paginated role list response"""
    items: List[RoleResponse]
    total: int
    page: int
    page_size: int
    pages: int


class PermissionListResponse(BaseModel):
    """Paginated permission list response"""
    items: List[PermissionResponse]
    total: int
    page: int
    page_size: int
    pages: int