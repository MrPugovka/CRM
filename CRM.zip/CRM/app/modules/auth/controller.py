"""
Authentication Controller
With rate limiting for security
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request, Response
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rate_limiter import limiter, RateLimits
from app.modules.auth.services import AuthService
from app.modules.users.schemas import TokenResponse, LoginRequest

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/login", response_model=TokenResponse)
@limiter.limit(RateLimits.LOGIN)  # 5/minute, 20/hour
async def login(
    request: Request,  # Required for slowapi
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    """
    Login with username and password.
    Rate limited: 5 attempts per minute, 20 per hour.
    Sets secure httpOnly cookies for tokens.
    """
    from app.core.cookies import set_auth_cookie, set_refresh_cookie
    
    auth_service = AuthService(db)
    
    user = await auth_service.authenticate(
        email=form_data.username,
        password=form_data.password
    )
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is disabled"
        )
    
    # Generate tokens
    access_token = auth_service.create_access_token(user.id)
    refresh_token = auth_service.create_refresh_token(user.id)
    
    # Set secure httpOnly cookies
    set_auth_cookie(response, access_token)
    set_refresh_cookie(response, refresh_token)
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": 1800  # 30 minutes
    }


@router.post("/refresh", response_model=TokenResponse)
@limiter.limit(RateLimits.REFRESH_TOKEN)  # 10/minute
async def refresh_token(
    request: Request,
    response: Response,
    db: AsyncSession = Depends(get_db)
):
    """
    Refresh access token using refresh token from secure cookie.
    Rate limited: 10 attempts per minute.
    """
    from app.core.cookies import get_refresh_token, set_refresh_cookie, set_auth_cookie
    
    # Get refresh token from secure httpOnly cookie
    refresh_token = get_refresh_token(request)
    if not refresh_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token missing. Please login again."
        )
    
    auth_service = AuthService(db)
    
    # Validate refresh token
    user_id = await auth_service.validate_refresh_token(refresh_token)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token"
        )
    
    # Generate new tokens
    new_access_token = auth_service.create_access_token(user_id)
    new_refresh_token = auth_service.create_refresh_token(user_id)
    
    # Set new tokens in secure cookies
    set_auth_cookie(response, new_access_token)
    set_refresh_cookie(response, new_refresh_token)
    
    return {
        "access_token": new_access_token,
        "refresh_token": new_refresh_token,
        "token_type": "bearer",
        "expires_in": 1800
    }


@router.post("/register", status_code=status.HTTP_201_CREATED)
@limiter.limit(RateLimits.REGISTER)  # 3/minute, 10/hour
async def register(
    request: Request,
    data: LoginRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Register new user account.
    Rate limited: 3 attempts per minute, 10 per hour.
    """
    auth_service = AuthService(db)
    
    # Check if email already exists
    existing_user = await auth_service.get_user_by_email(data.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Create new user
    user = await auth_service.create_user(
        email=data.email,
        password=data.password,
        full_name=data.full_name
    )
    
    return {
        "id": str(user.id),
        "email": user.email,
        "message": "User registered successfully"
    }
