"""
Authentication Service
Handles authentication-related business logic with brute force protection
"""
from typing import Optional
from uuid import UUID
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.config import settings
from app.core.security import (
    hash_password, verify_password,
    create_access_token, create_refresh_token
)
from app.modules.users.services import UserService
from app.modules.users.models import User


class AuthService:
    """Service for authentication operations with brute force protection"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        # Pass self as auth_service to UserService for centralized JWT generation
        self.user_service = UserService(db, auth_service=self)
    
    async def _check_account_lockout(self, user: User) -> bool:
        """
        Check if user account is locked due to failed login attempts.
        
        Args:
            user: User to check
            
        Returns:
            True if account is locked, False otherwise
        """
        # Check if account is permanently locked
        if not user.is_active:
            return True
        
        # Check if account is temporarily locked
        if user.locked_until:
            if user.locked_until > datetime.now(timezone.utc):
                return True
            else:
                # Lock expired, reset failed count
                user.locked_until = None
                user.failed_login_count = 0
                await self.db.commit()
                return False
        
        return False
    
    async def _record_failed_login(self, user: User) -> None:
        """
        Record a failed login attempt and lock account if threshold reached.
        
        Args:
            user: User with failed login
        """
        user.failed_login_count = (user.failed_login_count or 0) + 1
        
        # Lock account if threshold reached
        if user.failed_login_count >= settings.MAX_FAILED_LOGIN_ATTEMPTS:
            user.locked_until = datetime.now(timezone.utc) + timedelta(
                minutes=settings.LOGIN_LOCKOUT_MINUTES
            )
        
        await self.db.commit()
    
    async def _record_successful_login(self, user: User) -> None:
        """
        Reset failed login count after successful authentication.
        
        Args:
            user: User with successful login
        """
        user.failed_login_count = 0
        user.locked_until = None
        user.last_login = datetime.now(timezone.utc)
        await self.db.commit()
    
    async def authenticate(
        self, 
        email: str, 
        password: str,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> Optional[dict]:
        """
        Authenticate user with email and password with brute force protection.
        
        Args:
            email: User email
            password: Plain text password
            ip_address: Client IP address
            user_agent: Client user agent
            
        Returns:
            User dict if authentication successful, None otherwise
            
        Raises:
            HTTPException: If account is locked or credentials are invalid
        """
        # Get user by email
        user = await self.user_service.get_user_by_email(email)
        
        if not user:
            # Don't reveal if user exists
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        # Check if account is locked
        is_locked = await self._check_account_lockout(user)
        if is_locked:
            if user.locked_until:
                remaining = (user.locked_until - datetime.now(timezone.utc)).seconds // 60
                raise HTTPException(
                    status_code=status.HTTP_423_LOCKED,
                    detail=f"Account is locked due to multiple failed login attempts. "
                           f"Please try again in {remaining} minutes."
                )
            else:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Account is disabled"
                )
        
        # Verify password
        if not verify_password(password, user.password_hash):
            await self._record_failed_login(user)
            
            remaining_attempts = max(0, settings.MAX_FAILED_LOGIN_ATTEMPTS - user.failed_login_count)
            
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Invalid email or password. {remaining_attempts} attempts remaining."
            )
        
        # Reset failed count on successful login
        await self._record_successful_login(user)
        
        # Perform actual authentication
        try:
            result = await self.user_service.authenticate(email, password, ip_address, user_agent)
            return result
        except ValueError as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=str(e)
            )
    
    def create_access_token(self, user_id: UUID) -> str:
        """
        Create JWT access token for user
        
        Args:
            user_id: User ID
            
        Returns:
            JWT access token string
        """
        return create_access_token(subject=str(user_id))
    
    def create_refresh_token(self, user_id: UUID) -> str:
        """
        Create JWT refresh token for user
        
        Args:
            user_id: User ID
            
        Returns:
            JWT refresh token string
        """
        return create_refresh_token(subject=str(user_id))
    
    async def validate_refresh_token(self, token: str) -> Optional[UUID]:
        """
        Validate refresh token and return user ID
        
        Args:
            token: Refresh token string
            
        Returns:
            User ID if token is valid, None otherwise
        """
        try:
            result = await self.user_service.refresh_tokens(token)
            return result.user.id if result and result.user else None
        except ValueError:
            return None
    
    async def get_user_by_email(self, email: str) -> Optional[dict]:
        """
        Get user by email address
        
        Args:
            email: User email
            
        Returns:
            User object if found, None otherwise
        """
        user = await self.user_service.get_user_by_email(email)
        return user
    
    async def create_user(
        self,
        email: str,
        password: str,
        full_name: Optional[str] = None
    ) -> dict:
        """
        Create a new user account
        
        Args:
            email: User email
            password: Plain text password
            full_name: User full name
            
        Returns:
            Created User object
        """
        from app.modules.users.schemas import UserCreate
        
        user_data = UserCreate(
            email=email,
            password=password,
            full_name=full_name or ""
        )
        
        return await self.user_service.create_user(user_data)
