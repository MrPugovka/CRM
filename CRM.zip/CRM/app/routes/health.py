"""
Health Check Endpoint

Provides comprehensive health checks for the application including:
- Basic application status
- Database connectivity
- Redis connectivity
- System information

Usage:
    GET /health - Basic health check
    GET /health/ready - Readiness probe (checks dependencies)
    GET /health/live - Liveness probe
"""

import asyncio
import time
from datetime import datetime
from typing import Dict, Any, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import async_session_factory

try:
    import redis.asyncio as aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

router = APIRouter(prefix="/health", tags=["Health"])

# Application start time for uptime calculation
_START_TIME = time.time()


async def check_database() -> Dict[str, Any]:
    """Check database connectivity"""
    try:
        async with async_session_factory() as session:
            start_time = time.time()
            result = await session.execute(text("SELECT 1"))
            await result.scalar()
            response_time = (time.time() - start_time) * 1000  # ms
            
            return {
                "status": "connected",
                "response_time_ms": round(response_time, 2),
                "error": None
            }
    except Exception as e:
        return {
            "status": "disconnected",
            "response_time_ms": None,
            "error": str(e)
        }


async def check_redis() -> Dict[str, Any]:
    """Check Redis connectivity"""
    if not REDIS_AVAILABLE:
        return {
            "status": "not_configured",
            "response_time_ms": None,
            "error": "Redis client not installed"
        }
    
    try:
        # Parse Redis URL
        redis_url = settings.REDIS_URL
        
        # Create Redis client
        client = aioredis.from_url(
            redis_url,
            password=settings.REDIS_PASSWORD if hasattr(settings, 'REDIS_PASSWORD') else None,
            socket_connect_timeout=5,
            socket_timeout=5,
            decode_responses=True
        )
        
        start_time = time.time()
        await client.ping()
        response_time = (time.time() - start_time) * 1000  # ms
        
        await client.close()
        
        return {
            "status": "connected",
            "response_time_ms": round(response_time, 2),
            "error": None
        }
    except Exception as e:
        return {
            "status": "disconnected",
            "response_time_ms": None,
            "error": str(e)
        }


@router.get(
    "",
    summary="Basic Health Check",
    description="Returns basic health status of the application"
)
async def health_check() -> Dict[str, Any]:
    """
    Basic health check endpoint.
    
    Returns:
        Basic health status including version and uptime
    """
    uptime_seconds = time.time() - _START_TIME
    
    return {
        "status": "healthy",
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "timestamp": datetime.utcnow().isoformat(),
        "uptime_seconds": round(uptime_seconds, 2),
        "service": settings.APP_NAME
    }


@router.get(
    "/ready",
    summary="Readiness Probe",
    description="Comprehensive health check including database and Redis connectivity"
)
async def readiness_check() -> Dict[str, Any]:
    """
    Readiness probe for Kubernetes/Docker.
    Checks all critical dependencies.
    
    Returns:
        Detailed health status with dependency checks
    """
    # Run checks concurrently
    db_check, redis_check = await asyncio.gather(
        check_database(),
        check_redis()
    )
    
    # Determine overall status
    is_healthy = (
        db_check["status"] == "connected" and
        (redis_check["status"] in ["connected", "not_configured"])
    )
    
    status_code = "healthy" if is_healthy else "unhealthy"
    http_status = status.HTTP_200_OK if is_healthy else status.HTTP_503_SERVICE_UNAVAILABLE
    
    response = {
        "status": status_code,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "timestamp": datetime.utcnow().isoformat(),
        "checks": {
            "database": db_check,
            "redis": redis_check
        }
    }
    
    if not is_healthy:
        raise HTTPException(
            status_code=http_status,
            detail=response
        )
    
    return response


@router.get(
    "/live",
    summary="Liveness Probe",
    description="Simple liveness check to verify the application is running"
)
async def liveness_check() -> Dict[str, str]:
    """
    Liveness probe for Kubernetes/Docker.
    Simple check to verify the application process is alive.
    
    Returns:
        Simple alive status
    """
    return {
        "status": "alive",
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get(
    "/metrics",
    summary="Basic Metrics",
    description="Returns basic application metrics"
)
async def metrics_check() -> Dict[str, Any]:
    """
    Basic metrics endpoint.
    
    Returns:
        Application metrics including uptime and memory usage
    """
    import psutil
    import os
    
    process = psutil.Process(os.getpid())
    memory_info = process.memory_info()
    
    uptime_seconds = time.time() - _START_TIME
    
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "uptime_seconds": round(uptime_seconds, 2),
        "memory": {
            "rss_mb": round(memory_info.rss / 1024 / 1024, 2),
            "vms_mb": round(memory_info.vms / 1024 / 1024, 2),
            "percent": round(process.memory_percent(), 2)
        },
        "cpu_percent": round(process.cpu_percent(interval=0.1), 2),
        "threads": process.num_threads()
    }
