# app/routes package
# Modular routes for the CRM application
