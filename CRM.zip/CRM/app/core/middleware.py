"""
Custom Middleware
- Exception handling
- Logging with correlation ID
- Request timing
- Audit logging
- Security headers
"""
import time
import uuid
import traceback
from typing import Callable, Optional

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import structlog

from app.core.config import settings

logger = structlog.get_logger()


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """Add correlation ID to each request for tracing"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Get or generate correlation ID
        correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
        
        # Add to request state
        request.state.correlation_id = correlation_id
        
        # Add correlation ID to structlog context
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(
            correlation_id=correlation_id,
            request_path=request.url.path,
            request_method=request.method,
        )
        
        # Process request
        start_time = time.time()
        response = None
        
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            # Log exception before re-raising
            logger.error(
                "Request failed with exception",
                error_type=type(exc).__name__,
                error_message=str(exc),
            )
            raise
        finally:
            # Add correlation ID to response headers if response exists
            if response is not None:
                response.headers["X-Correlation-ID"] = correlation_id
            
            # Log request completion
            process_time = time.time() - start_time
            logger.info(
                "Request completed",
                status_code=response.status_code if response else 500,
                process_time=round(process_time, 4),
            )


class ExceptionHandlerMiddleware(BaseHTTPMiddleware):
    """Global exception handler with structured logging"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            return await call_next(request)
        except Exception as exc:
            # Get correlation ID
            correlation_id = getattr(request.state, 'correlation_id', 'unknown')
            
            # Log the error with full traceback
            logger.error(
                "Unhandled exception",
                error_type=type(exc).__name__,
                error_message=str(exc),
                traceback=traceback.format_exc(),
                correlation_id=correlation_id,
            )
            
            # Return structured error response
            # Use settings.DEBUG which is loaded from environment or .env file
            if settings.DEBUG:
                # In debug mode, log full details server-side but return safe info to client
                logger.error("Exception", traceback=traceback.format_exc())
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "Internal server error",
                        "correlation_id": correlation_id,
                    }
                )
            else:
                # Production - minimal information
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "Internal server error",
                        "message": "An unexpected error occurred. Please try again later.",
                        "correlation_id": correlation_id,
                    }
                )


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log all requests with timing"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        
        # Log request start
        logger.info(
            "Request started",
            path=request.url.path,
            method=request.method,
            client_ip=request.client.host if request.client else None,
            user_agent=request.headers.get("User-Agent"),
        )
        
        try:
            response = await call_next(request)
            
            # Calculate processing time
            process_time = time.time() - start_time
            
            # Log successful completion
            logger.info(
                "Request completed",
                status_code=response.status_code,
                process_time_ms=round(process_time * 1000, 2),
            )
            
            return response
            
        except Exception as exc:
            # Log failed request
            process_time = time.time() - start_time
            logger.error(
                "Request failed",
                error=str(exc),
                process_time_ms=round(process_time * 1000, 2),
            )
            raise


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add security headers to all responses for XSS/clickjacking protection"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        
        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        
        # Generate nonce for inline scripts (if needed)
        import secrets
        nonce = secrets.token_urlsafe(16)
        request.state.csp_nonce = nonce
        
        # Enhanced Content Security Policy
        # Using nonce for any necessary inline scripts instead of unsafe-inline
        csp_policy = (
            "default-src 'self'; "
            f"script-src 'self' 'nonce-{nonce}' unpkg.com cdn.jsdelivr.net cdn.tailwindcss.com; "
            "style-src 'self' 'unsafe-inline' cdn.tailwindcss.com; "
            "img-src 'self' data: https:; "
            "font-src 'self' fonts.gstatic.com cdn.jsdelivr.net; "
            "connect-src 'self'; "
            "media-src 'self'; "
            "object-src 'none'; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self';"
        )
        response.headers["Content-Security-Policy"] = csp_policy
        
        return response


class CharsetMiddleware(BaseHTTPMiddleware):
    """Ensure Content-Type has charset=utf-8 for text responses"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        
        content_type = response.headers.get("Content-Type", "")
        
        # Add charset=utf-8 to text content types
        if content_type and "text/" in content_type and "charset" not in content_type:
            response.headers["Content-Type"] = f"{content_type}; charset=utf-8"
        elif content_type == "application/json" and "charset" not in content_type:
            response.headers["Content-Type"] = "application/json; charset=utf-8"
        
        return response


class AuditLoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware for automatic audit logging of sensitive operations.
    Logs: login/logout, create/update/delete operations, role changes.
    """
    
    # Paths to audit log
    AUDIT_PATHS = [
        ("/auth/login", "login"),
        ("/auth/logout", "logout"),
        ("/auth/refresh", "token_refresh"),
        ("/users", "user_management"),
        ("/clients", "client_management"),
        ("/deals", "deal_management"),
        ("/tasks", "task_management"),
        ("/settings/roles", "role_management"),
    ]
    
    # HTTP methods that modify data
    MODIFICATION_METHODS = ["POST", "PUT", "PATCH", "DELETE"]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        from app.core.audit import AuditService, AuditAction
        from app.core.security import decode_token
        
        # Process request first
        response = await call_next(request)
        
        # Check if this is an auth endpoint
        path = request.url.path
        method = request.method
        
        # Get user info from token if available
        user_id = None
        user_email = None
        company_id = None
        
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header.replace("Bearer ", "")
            payload = decode_token(token)
            if payload:
                user_id = payload.get("sub")
                user_email = payload.get("email")
                company_id = payload.get("company_id")
        
        # Get request info
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get("User-Agent")
        request_id = getattr(request.state, 'correlation_id', None)
        
        # Log authentication events
        if "/auth/login" in path and method == "POST" and response.status_code == 200:
            try:
                audit = AuditService(request.state.db if hasattr(request.state, 'db') else None)
                if audit.db:
                    await audit.log_login(
                        user_id=user_id or "anonymous",
                        user_email=user_email or "unknown",
                        ip_address=ip_address,
                        user_agent=user_agent,
                        request_id=request_id
                    )
            except Exception:
                pass  # Don't fail request if audit logging fails
        
        # Log logout events
        if "/auth/logout" in path and method == "POST":
            try:
                audit = AuditService(request.state.db if hasattr(request.state, 'db') else None)
                if audit.db:
                    await audit.log_logout(
                        user_id=user_id or "anonymous",
                        user_email=user_email or "unknown",
                        ip_address=ip_address,
                        user_agent=user_agent,
                        request_id=request_id
                    )
            except Exception:
                pass
        
        # Log data modification operations
        if method in self.MODIFICATION_METHODS:
            action_map = {
                "POST": AuditAction.CREATE,
                "PUT": AuditAction.UPDATE,
                "PATCH": AuditAction.UPDATE,
                "DELETE": AuditAction.DELETE
            }
            
            # Determine entity type from path
            entity_type = self._get_entity_type_from_path(path)
            
            if entity_type and response.status_code in [200, 201, 204]:
                try:
                    audit = AuditService(request.state.db if hasattr(request.state, 'db') else None)
                    if audit.db:
                        action = action_map.get(method)
                        description = f"{method} {path} - Status: {response.status_code}"
                        
                        await audit.log(
                            action=action,
                            entity_type=entity_type,
                            company_id=company_id,
                            user_id=user_id,
                            user_email=user_email,
                            ip_address=ip_address,
                            user_agent=user_agent,
                            request_id=request_id,
                            description=description,
                            metadata={
                                "path": path,
                                "method": method,
                                "status_code": response.status_code
                            }
                        )
                except Exception:
                    pass
        
        return response
    
    def _get_entity_type_from_path(self, path: str) -> Optional[str]:
        """Extract entity type from URL path"""
        path_parts = path.strip("/").split("/")
        if len(path_parts) >= 2:
            entity_map = {
                "clients": "client",
                "deals": "deal",
                "tasks": "task",
                "users": "user",
                "roles": "role",
                "pipelines": "pipeline",
                "stages": "stage",
                "files": "file",
                "documents": "document",
                "emails": "email",
                "campaigns": "campaign",
                "integrations": "integration",
                "settings": "setting",
                "automations": "automation",
                "templates": "template",
            }
            return entity_map.get(path_parts[1])
        return None
