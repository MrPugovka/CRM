"""
Audit Logging System
Logs all entity changes for compliance and debugging
"""
from datetime import datetime, timezone
from typing import Optional, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, Text, DateTime, JSON

import uuid
import json
from enum import Enum

from app.core.database import Base


class AuditAction(str, Enum):
    """Audit log action types"""
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    SOFT_DELETE = "soft_delete"
    RESTORE = "restore"
    LOGIN = "login"
    LOGOUT = "logout"
    ACCESS = "access"
    EXPORT = "export"
    IMPORT = "import"


class AuditLog(Base):
    """
    Audit log table for tracking all entity changes
    Multi-tenant: Each audit log belongs to a company
    """
    __tablename__ = "audit_logs"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    
    # Multi-tenancy: Company association (REQUIRED for all audit logs)
    company_id = Column(String(36), nullable=False, index=True)  # Company context for the action
    
    # Action information
    action = Column(String(50), nullable=False)  # login, logout, create, update, delete, etc.
    entity_type = Column(String(50), nullable=False)  # clients, deals, users, etc.
    entity_id = Column(String(36), nullable=True)  # ID of affected entity
    
    # User information
    user_id = Column(String(36), nullable=True, index=True)  # User who performed action
    user_email = Column(String(120), nullable=True)
    
    # Request information
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    request_id = Column(String(36), nullable=True, index=True)
    
    # Change details
    old_values = Column(JSON, nullable=True)  # Previous values (for updates)
    new_values = Column(JSON, nullable=True)  # New values (for creates/updates)
    changes = Column(JSON, nullable=True)  # Diff of changes
    
    # Additional context
    description = Column(Text, nullable=True)
    meta_data = Column(JSON, nullable=True)  # Additional metadata (renamed from metadata)
    
    # Timestamp
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    
    # No updated_at or deleted_at for audit logs - they are immutable


class AuditLogCreate(BaseModel):
    """DTO for creating audit log entries"""
    action: AuditAction
    entity_type: str
    entity_id: Optional[str] = None
    company_id: str  # REQUIRED: All audit logs must have company_id
    user_id: Optional[str] = None
    user_email: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    request_id: Optional[str] = None
    old_values: Optional[dict[str, Any]] = None
    new_values: Optional[dict[str, Any]] = None
    changes: Optional[dict[str, Any]] = None
    description: Optional[str] = None
    meta_data: Optional[dict[str, Any]] = None  # Renamed from metadata


class AuditService:
    """
    Service for creating and querying audit logs
    """
    
    def __init__(self, db_session):
        self.db = db_session
    
    async def log(
        self,
        action: AuditAction,
        entity_type: str,
        entity_id: Optional[str] = None,
        company_id: str = None,  # REQUIRED: Must be provided
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        request_id: Optional[str] = None,
        old_values: Optional[dict] = None,
        new_values: Optional[dict] = None,
        changes: Optional[dict] = None,
        description: Optional[str] = None,
        meta_data: Optional[dict] = None
    ) -> AuditLog:
        """
        Create an audit log entry
        
        Args:
            action: Type of action performed
            entity_type: Type of entity affected
            entity_id: ID of entity affected
            company_id: Company ID for multi-tenancy (REQUIRED)
            user_id: ID of user who performed action
            user_email: Email of user who performed action
            ip_address: IP address of request
            user_agent: User agent string
            request_id: Unique request identifier
            old_values: Previous values (for updates)
            new_values: New values (for creates/updates)
            changes: Diff of changes
            description: Human-readable description
            meta_data: Additional metadata
        
        Returns:
            Created AuditLog instance
            
        Raises:
            ValueError: If company_id is not provided
        """
        if not company_id:
            raise ValueError("company_id is required for all audit log entries")
        
        log_entry = AuditLog(
            action=action.value,
            entity_type=entity_type,
            entity_id=entity_id,
            company_id=company_id,
            user_id=user_id,
            user_email=user_email,
            ip_address=ip_address,
            user_agent=user_agent,
            request_id=request_id,
            old_values=old_values,
            new_values=new_values,
            changes=changes,
            description=description,
            meta_data=meta_data
        )
        
        self.db.add(log_entry)
        await self.db.flush()
        
        return log_entry
    
    async def log_create(
        self,
        entity_type: str,
        entity_id: str,
        new_values: dict,
        company_id: str,  # REQUIRED
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        **kwargs
    ) -> AuditLog:
        """Log entity creation - company_id is required"""
        return await self.log(
            action=AuditAction.CREATE,
            entity_type=entity_type,
            entity_id=entity_id,
            company_id=company_id,
            new_values=new_values,
            user_id=user_id,
            user_email=user_email,
            description=f"Created {entity_type} with ID {entity_id}",
            **kwargs
        )
    
    async def log_update(
        self,
        entity_type: str,
        entity_id: str,
        old_values: dict,
        new_values: dict,
        changes: dict,
        company_id: str,  # REQUIRED
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        **kwargs
    ) -> AuditLog:
        """Log entity update - company_id is required"""
        return await self.log(
            action=AuditAction.UPDATE,
            entity_type=entity_type,
            entity_id=entity_id,
            company_id=company_id,
            old_values=old_values,
            new_values=new_values,
            changes=changes,
            user_id=user_id,
            user_email=user_email,
            description=f"Updated {entity_type} with ID {entity_id}",
            **kwargs
        )
    
    async def log_delete(
        self,
        entity_type: str,
        entity_id: str,
        old_values: dict,
        company_id: str,  # REQUIRED
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        soft: bool = False,
        **kwargs
    ) -> AuditLog:
        """Log entity deletion - company_id is required"""
        action = AuditAction.SOFT_DELETE if soft else AuditAction.DELETE
        return await self.log(
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            company_id=company_id,
            old_values=old_values,
            user_id=user_id,
            user_email=user_email,
            description=f"{'Soft ' if soft else ''}Deleted {entity_type} with ID {entity_id}",
            **kwargs
        )
    
    async def log_login(
        self,
        user_id: str,
        user_email: str,
        company_id: str,  # REQUIRED
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        **kwargs
    ) -> AuditLog:
        """Log user login - company_id is required"""
        return await self.log(
            action=AuditAction.LOGIN,
            entity_type="user",
            entity_id=user_id,
            company_id=company_id,
            user_id=user_id,
            user_email=user_email,
            ip_address=ip_address,
            user_agent=user_agent,
            description=f"User {user_email} logged in",
            **kwargs
        )
    
    async def log_logout(
        self,
        user_id: str,
        user_email: str,
        company_id: str,  # REQUIRED
        **kwargs
    ) -> AuditLog:
        """Log user logout - company_id is required"""
        return await self.log(
            action=AuditAction.LOGOUT,
            entity_type="user",
            entity_id=user_id,
            company_id=company_id,
            user_id=user_id,
            user_email=user_email,
            description=f"User {user_email} logged out",
            **kwargs
        )


def compute_changes(old: dict, new: dict) -> dict:
    """
    Compute the difference between old and new values
    
    Args:
        old: Old values dictionary
        new: New values dictionary
    
    Returns:
        Dictionary of changed fields with old and new values
    """
    changes = {}
    
    all_keys = set(old.keys()) | set(new.keys())
    
    for key in all_keys:
        old_val = old.get(key)
        new_val = new.get(key)
        
        if old_val != new_val:
            changes[key] = {
                "old": old_val,
                "new": new_val
            }
    
    return changes