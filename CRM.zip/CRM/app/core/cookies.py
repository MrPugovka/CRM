"""
Secure Cookie Utilities
Provides secure cookie settings with proper flags
"""
from fastapi import Response, Request
from typing import Optional, Any
import json
from datetime import datetime, timedelta
from app.core.config import settings

# Cookie security settings
COOKIE_SECURE = not settings.DEBUG  # HTTPS only in production
COOKIE_HTTPONLY = True  # Not accessible via JavaScript
COOKIE_SAMESITE = "Strict"  # Strict SameSite policy
COOKIE_PATH = "/"  # Available for all paths


def set_secure_cookie(
    response: Response,
    key: str,
    value: str,
    max_age: Optional[int] = None,
    expires: Optional[datetime] = None,
    path: str = COOKIE_PATH,
    domain: Optional[str] = None,
    secure: bool = COOKIE_SECURE,
    httponly: bool = COOKIE_HTTPONLY,
    samesite: str = COOKIE_SAMESITE
) -> None:
    """
    Set a secure cookie with all security flags
    
    Args:
        response: FastAPI response object
        key: Cookie name
        value: Cookie value
        max_age: Cookie lifetime in seconds
        expires: Expiration datetime
        path: Cookie path
        domain: Cookie domain
        secure: HTTPS only flag
        httponly: HTTP only flag (not accessible via JavaScript)
        samesite: SameSite policy (Strict, Lax, None)
    """
    response.set_cookie(
        key=key,
        value=value,
        max_age=max_age,
        expires=expires.strftime("%a, %d-%b-%Y %H:%M:%S GMT") if expires else None,
        path=path,
        domain=domain,
        secure=secure,
        httponly=httponly,
        samesite=samesite
    )


def set_auth_cookie(
    response: Response,
    token: str,
    cookie_name: str = "access_token",
    max_age: int = 3600,  # 1 hour default
    secure: Optional[bool] = None,
    httponly: bool = True,
    samesite: str = "Strict"
) -> None:
    """
    Set authentication cookie with secure settings
    
    Args:
        response: FastAPI response object
        token: JWT or session token
        cookie_name: Name of the cookie
        max_age: Cookie lifetime in seconds
        secure: HTTPS only (defaults to production setting)
        httponly: HTTP only flag
        samesite: SameSite policy
    """
    if secure is None:
        secure = COOKIE_SECURE
    
    set_secure_cookie(
        response=response,
        key=cookie_name,
        value=token,
        max_age=max_age,
        secure=secure,
        httponly=httponly,
        samesite=samesite
    )


def set_refresh_cookie(
    response: Response,
    token: str,
    max_age: int = 604800  # 7 days
) -> None:
    """
    Set refresh token cookie with extended lifetime
    
    Args:
        response: FastAPI response object
        token: Refresh token
        max_age: Cookie lifetime in seconds (default 7 days)
    """
    set_secure_cookie(
        response=response,
        key="refresh_token",
        value=token,
        max_age=max_age,
        httponly=True,  # Refresh token should never be accessible via JS
        secure=COOKIE_SECURE,
        samesite="Strict"
    )


def set_session_cookie(
    response: Response,
    session_id: str,
    max_age: int = 86400  # 1 day
) -> None:
    """
    Set session cookie
    
    Args:
        response: FastAPI response object
        session_id: Session identifier
        max_age: Cookie lifetime in seconds
    """
    set_secure_cookie(
        response=response,
        key="session_id",
        value=session_id,
        max_age=max_age,
        httponly=True,
        secure=COOKIE_SECURE,
        samesite="Strict"
    )


def clear_cookie(
    response: Response,
    key: str,
    path: str = COOKIE_PATH,
    domain: Optional[str] = None
) -> None:
    """
    Clear a cookie by setting it to expire immediately
    
    Args:
        response: FastAPI response object
        key: Cookie name to clear
        path: Cookie path
        domain: Cookie domain
    """
    response.delete_cookie(
        key=key,
        path=path,
        domain=domain
    )


def clear_auth_cookies(response: Response) -> None:
    """Clear all authentication cookies"""
    clear_cookie(response, "access_token")
    clear_cookie(response, "refresh_token")
    clear_cookie(response, "session_id")


def get_cookie(request: Request, key: str) -> Optional[str]:
    """
    Get cookie value from request
    
    Args:
        request: FastAPI request object
        key: Cookie name
        
    Returns:
        Cookie value or None if not found
    """
    return request.cookies.get(key)


def get_auth_token(request: Request) -> Optional[str]:
    """
    Get authentication token from cookie or header
    
    Args:
        request: FastAPI request object
        
    Returns:
        Token string or None
    """
    # Try cookie first
    token = request.cookies.get("access_token")
    if token:
        return token
    
    # Try Authorization header
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return auth_header.replace("Bearer ", "")
    
    return None


def get_refresh_token(request: Request) -> Optional[str]:
    """Get refresh token from cookie"""
    return request.cookies.get("refresh_token")


def get_session_id(request: Request) -> Optional[str]:
    """Get session ID from cookie"""
    return request.cookies.get("session_id")


class CookieSettings:
    """Cookie settings for different environments"""
    
    @staticmethod
    def development():
        """Settings for development environment"""
        return {
            "secure": False,  # Allow HTTP in development
            "httponly": True,
            "samesite": "Lax",  # Lax for easier development
        }
    
    @staticmethod
    def production():
        """Settings for production environment"""
        return {
            "secure": True,  # HTTPS only
            "httponly": True,
            "samesite": "Strict",  # Strict for security
        }
    
    @staticmethod
    def current():
        """Get current environment settings"""
        if settings.DEBUG:
            return CookieSettings.development()
        return CookieSettings.production()


# Helper function to get current environment settings
def get_cookie_settings():
    """Get cookie settings for current environment"""
    return CookieSettings.current()
