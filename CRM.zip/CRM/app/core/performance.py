"""
Performance Module
Pagination, sorting, filtering, and database indexes
"""
from sqlalchemy import Index, Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Query
from typing import Optional, List, Dict, Any, Type, TypeVar, Generic
from pydantic import BaseModel
from datetime import datetime
import uuid
import re

T = TypeVar('T')


# ==================== Pagination ====================

class PaginationParams(BaseModel):
    """Pagination parameters"""
    page: int = 1
    page_size: int = 50
    
    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size
    
    @property
    def limit(self) -> int:
        return self.page_size


class PaginatedResult(BaseModel, Generic[T]):
    """Paginated result wrapper"""
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int
    has_next: bool
    has_prev: bool
    
    @classmethod
    def create(cls, items: List[Any], total: int, page: int, page_size: int):
        total_pages = (total + page_size - 1) // page_size if page_size > 0 else 0
        
        return cls(
            items=items,
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            has_next=page < total_pages,
            has_prev=page > 1
        )


class PaginationHelper:
    """
    Helper for paginated queries
    
    All list endpoints should use this for consistent pagination.
    """
    
    @staticmethod
    def apply_pagination(query: Query, page: int = 1, page_size: int = 50) -> Query:
        """
        Apply pagination to a query
        
        Usage:
            query = select(Model).where(...)
            query = PaginationHelper.apply_pagination(query, page=1, page_size=50)
        """
        offset = (page - 1) * page_size
        return query.offset(offset).limit(page_size)
    
    @staticmethod
    async def paginate(
        session: AsyncSession,
        query: Query,
        count_query: Query = None,
        page: int = 1,
        page_size: int = 50
    ) -> PaginatedResult:
        """
        Execute paginated query and return wrapped result
        
        Usage:
            result = await PaginationHelper.paginate(
                session=db,
                query=select(Model).where(...),
                page=1,
                page_size=50
            )
        """
        # Get total count
        from sqlalchemy import func, select
        
        if count_query is None:
            # Try to create count query from main query
            count_query = select(func.count()).select_from(query.column_descriptions[0]['entity'])
        
        total_result = await session.execute(count_query)
        total = total_result.scalar() or 0
        
        # Apply pagination
        paginated_query = PaginationHelper.apply_pagination(query, page, page_size)
        
        # Execute
        result = await session.execute(paginated_query)
        items = result.scalars().all()
        
        return PaginatedResult.create(
            items=items,
            total=total,
            page=page,
            page_size=page_size
        )


# ==================== Sorting ====================

class SortParams(BaseModel):
    """Sorting parameters"""
    sort_by: str = "created_at"
    sort_order: str = "desc"  # asc or desc


class SortingHelper:
    """
    Helper for sorting queries
    
    All list endpoints should support sorting.
    """
    
    @staticmethod
    def apply_sorting(
        query: Query,
        model: Type,
        sort_by: str = "created_at",
        sort_order: str = "desc"
    ) -> Query:
        """
        Apply sorting to a query
        
        Usage:
            query = SortingHelper.apply_sorting(
                query, Model, sort_by="created_at", sort_order="desc"
            )
        """
        # Validate sort column exists
        if hasattr(model, sort_by):
            column = getattr(model, sort_by)
            
            if sort_order.lower() == "asc":
                query = query.order_by(column.asc())
            else:
                query = query.order_by(column.desc())
        
        return query
    
    @staticmethod
    def parse_sort_string(sort_string: str) -> SortParams:
        """
        Parse sort string like "created_at:desc" or "amount:asc"
        
        Usage:
            params = SortingHelper.parse_sort_string("amount:desc")
        """
        if not sort_string:
            return SortParams()
        
        parts = sort_string.split(":")
        sort_by = parts[0] if parts else "created_at"
        sort_order = parts[1] if len(parts) > 1 else "desc"
        
        return SortParams(sort_by=sort_by, sort_order=sort_order)


# ==================== Filtering ====================

class FilterOperator:
    """Filter operators"""
    EQ = "eq"           # equals
    NE = "ne"           # not equals
    GT = "gt"           # greater than
    GTE = "gte"         # greater than or equal
    LT = "lt"           # less than
    LTE = "lte"         # less than or equal
    LIKE = "like"       # LIKE pattern
    ILIKE = "ilike"     # case-insensitive LIKE
    IN = "in"           # in list
    NOT_IN = "not_in"   # not in list
    IS_NULL = "is_null"
    IS_NOT_NULL = "is_not_null"
    BETWEEN = "between"


class FilterParams(BaseModel):
    """Filter parameters"""
    field: str
    operator: str = FilterOperator.EQ
    value: Any = None


class FilteringHelper:
    """
    Helper for filtering queries
    
    All list endpoints should support filtering.
    """
    
    OPERATOR_MAP = {
        FilterOperator.EQ: lambda col, val: col == val,
        FilterOperator.NE: lambda col, val: col != val,
        FilterOperator.GT: lambda col, val: col > val,
        FilterOperator.GTE: lambda col, val: col >= val,
        FilterOperator.LT: lambda col, val: col < val,
        FilterOperator.LTE: lambda col, val: col <= val,
        FilterOperator.LIKE: lambda col, val: col.like(val),
        FilterOperator.ILIKE: lambda col, val: col.ilike(f"%{val}%"),
        FilterOperator.IN: lambda col, val: col.in_(val if isinstance(val, list) else [val]),
        FilterOperator.NOT_IN: lambda col, val: col.not_in(val if isinstance(val, list) else [val]),
        FilterOperator.IS_NULL: lambda col, val: col.is_(None),
        FilterOperator.IS_NOT_NULL: lambda col, val: col.is_not(None),
    }
    
    @staticmethod
    def apply_filter(
        query: Query,
        model: Type,
        field: str,
        operator: str,
        value: Any
    ) -> Query:
        """
        Apply a single filter to a query
        
        Usage:
            query = FilteringHelper.apply_filter(
                query, Model, "field_name", "gte", value
            )
        """
        if not hasattr(model, field):
            return query
        
        column = getattr(model, field)
        
        if operator in FilteringHelper.OPERATOR_MAP:
            filter_func = FilteringHelper.OPERATOR_MAP[operator]
            query = query.where(filter_func(column, value))
        
        return query
    
    @staticmethod
    def apply_filters(
        query: Query,
        model: Type,
        filters: List[FilterParams]
    ) -> Query:
        """
        Apply multiple filters to a query
        
        Usage:
            filters = [
                FilterParams(field="status", operator="eq", value="active"),
                FilterParams(field="created_at", operator="gte", value=datetime.now())
            ]
            query = FilteringHelper.apply_filters(query, Model, filters)
        """
        for f in filters:
            query = FilteringHelper.apply_filter(
                query, model, f.field, f.operator, f.value
            )
        
        return query
    
    @staticmethod
    def parse_filter_string(filter_string: str) -> List[FilterParams]:
        """
        Parse filter string like "status:active,amount:gte:10000"
        
        Format: field:operator:value or field:value (defaults to eq)
        Multiple filters separated by comma
        """
        if not filter_string:
            return []
        
        filters = []
        
        for part in filter_string.split(","):
            segments = part.split(":")
            
            if len(segments) == 2:
                # field:value (default eq)
                filters.append(FilterParams(
                    field=segments[0],
                    operator=FilterOperator.ILIKE if segments[0] in ["name", "title", "email"] else FilterOperator.EQ,
                    value=segments[1]
                ))
            elif len(segments) >= 3:
                # field:operator:value
                operator = segments[1]
                value = ":".join(segments[2:])  # Handle values with colons
                
                # Parse value type
                if operator in [FilterOperator.IN, FilterOperator.NOT_IN]:
                    value = value.split("|")  # Pipe-separated list
                elif operator == FilterOperator.BETWEEN:
                    value = value.split("|")  # Two values
                    if len(value) == 2:
                        value = [FilteringHelper._parse_value(value[0]), FilteringHelper._parse_value(value[1])]
                
                filters.append(FilterParams(
                    field=segments[0],
                    operator=operator,
                    value=FilteringHelper._parse_value(value) if not isinstance(value, list) else value
                ))
        
        return filters
    
    @staticmethod
    def _parse_value(value: str) -> Any:
        """Parse string value to appropriate type"""
        # Try to parse as number
        try:
            if "." in value:
                return float(value)
            return int(value)
        except ValueError:
            pass
        
        # Try to parse as boolean
        if value.lower() in ["true", "yes", "1"]:
            return True
        if value.lower() in ["false", "no", "0"]:
            return False
        
        # Try to parse as UUID
        try:
            return uuid.UUID(value)
        except ValueError:
            pass
        
        # Return as string
        return value


# ==================== Query Builder ====================

class QueryBuilder:
    """
    Unified query builder with pagination, sorting, and filtering
    
    Usage:
        builder = QueryBuilder(Model)
        query = builder.build(
            base_query=select(Model),
            page=1,
            page_size=50,
            sort_by="created_at",
            sort_order="desc",
            filters=[{"field": "status", "operator": "eq", "value": "active"}]
        )
    """
    
    def __init__(self, model: Type):
        self.model = model
    
    def build(
        self,
        base_query: Query,
        page: int = 1,
        page_size: int = 50,
        sort_by: str = "created_at",
        sort_order: str = "desc",
        filters: List[Dict[str, Any]] = None,
        search: str = None,
        search_fields: List[str] = None
    ) -> Query:
        """
        Build a complete query with all features
        """
        query = base_query
        
        # Apply filters
        if filters:
            for f in filters:
                query = FilteringHelper.apply_filter(
                    query, self.model, f["field"], f.get("operator", "eq"), f["value"]
                )
        
        # Apply search
        if search and search_fields:
            from sqlalchemy import or_
            
            search_conditions = []
            for field in search_fields:
                if hasattr(self.model, field):
                    column = getattr(self.model, field)
                    search_conditions.append(column.ilike(f"%{search}%"))
            
            if search_conditions:
                query = query.where(or_(*search_conditions))
        
        # Apply sorting
        query = SortingHelper.apply_sorting(query, self.model, sort_by, sort_order)
        
        # Apply pagination
        query = PaginationHelper.apply_pagination(query, page, page_size)
        
        return query


# ==================== Database Indexes ====================

def get_common_indexes(table_name: str) -> List[Index]:
    """
    Get common indexes for a table
    
    Indexes on:
    - foreign keys
    - email
    - phone
    - created_at
    """
    return [
        # Created at index (for sorting by date)
        Index(f'ix_{table_name}_created_at', 'created_at'),
    ]


def get_client_indexes() -> List[Index]:
    """Indexes for clients table"""
    return [
        Index('ix_clients_email', 'email'),
        Index('ix_clients_phone', 'phone'),
        Index('ix_clients_created_at', 'created_at'),
        Index('ix_clients_responsible_id', 'responsible_id'),
        Index('ix_clients_client_type', 'client_type'),
        Index('ix_clients_status', 'status'),
    ]


def get_deal_indexes() -> List[Index]:
    """Indexes for deals table"""
    return [
        Index('ix_deals_stage_id', 'stage_id'),
        Index('ix_deals_pipeline_id', 'pipeline_id'),
        Index('ix_deals_responsible_id', 'responsible_id'),
        Index('ix_deals_client_id', 'client_id'),
        Index('ix_deals_status', 'status'),
        Index('ix_deals_created_at', 'created_at'),
        Index('ix_deals_closed_at', 'closed_at'),
    ]


def get_task_indexes() -> List[Index]:
    """Indexes for tasks table"""
    return [
        Index('ix_tasks_responsible_id', 'responsible_id'),
        Index('ix_tasks_deal_id', 'deal_id'),
        Index('ix_tasks_client_id', 'client_id'),
        Index('ix_tasks_status', 'status'),
        Index('ix_tasks_priority', 'priority'),
        Index('ix_tasks_due_date', 'due_date'),
        Index('ix_tasks_created_at', 'created_at'),
    ]


def get_user_indexes() -> List[Index]:
    """Indexes for users table"""
    return [
        Index('ix_users_email', 'email', unique=True),
        Index('ix_users_phone', 'phone'),
        Index('ix_users_status', 'status'),
        Index('ix_users_created_at', 'created_at'),
    ]


def get_message_indexes() -> List[Index]:
    """Indexes for messages table"""
    return [
        Index('ix_messages_client_id', 'client_id'),
        Index('ix_messages_deal_id', 'deal_id'),
        Index('ix_messages_sender_id', 'sender_id'),
        Index('ix_messages_created_at', 'created_at'),
    ]


def get_event_indexes() -> List[Index]:
    """Indexes for events table"""
    return [
        Index('ix_events_client_id', 'client_id'),
        Index('ix_events_deal_id', 'deal_id'),
        Index('ix_events_organizer_id', 'organizer_id'),
        Index('ix_events_start_at', 'start_at'),
        Index('ix_events_end_at', 'end_at'),
        Index('ix_events_created_at', 'created_at'),
    ]


# ==================== Performance Monitoring ====================

class PerformanceMonitor:
    """
    Monitor query performance
    
    Usage:
        async with PerformanceMonitor("get_deals") as monitor:
            result = await session.execute(query)
            monitor.record_count(len(result.scalars().all()))
    """
    
    _metrics: Dict[str, List[Dict]] = {}
    
    def __init__(self, operation: str):
        self.operation = operation
        self.start_time = None
        self.end_time = None
        self.record_count = 0
    
    async def __aenter__(self):
        self.start_time = datetime.now(timezone.utc)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.end_time = datetime.now(timezone.utc)
        self._record_metric()
        return False
    
    def record_count(self, count: int):
        self.record_count = count
    
    def _record_metric(self):
        duration_ms = (self.end_time - self.start_time).total_seconds() * 1000
        
        if self.operation not in self._metrics:
            self._metrics[self.operation] = []
        
        self._metrics[self.operation].append({
            "timestamp": self.start_time.isoformat(),
            "duration_ms": duration_ms,
            "record_count": self.record_count
        })
    
    @classmethod
    def get_metrics(cls) -> Dict[str, Dict]:
        """Get performance metrics summary"""
        summary = {}
        
        for operation, metrics in cls._metrics.items():
            if not metrics:
                continue
            
            durations = [m["duration_ms"] for m in metrics]
            
            summary[operation] = {
                "count": len(metrics),
                "avg_duration_ms": sum(durations) / len(durations),
                "min_duration_ms": min(durations),
                "max_duration_ms": max(durations),
                "last_24h_count": len([m for m in metrics if datetime.fromisoformat(m["timestamp"]) > datetime.now(timezone.utc) - timedelta(days=1)])
            }
        
        return summary


# ==================== Connection Pooling ====================

class ConnectionPoolConfig:
    """
    Connection pool configuration for handling 200+ concurrent users
    
    For PostgreSQL:
        pool_size = 20
        max_overflow = 30
        pool_timeout = 30
        pool_recycle = 1800
    """
    
    # Pool size (number of permanent connections)
    POOL_SIZE = 20
    
    # Max overflow (additional connections during peak)
    MAX_OVERFLOW = 30
    
    # Timeout for getting connection from pool
    POOL_TIMEOUT = 30
    
    # Recycle connections after N seconds (prevent stale connections)
    POOL_RECYCLE = 1800  # 30 minutes
    
    # Echo SQL for debugging (set to False in production)
    ECHO = False
    
    @classmethod
    def get_engine_kwargs(cls) -> Dict[str, Any]:
        """Get kwargs for SQLAlchemy engine"""
        return {
            "pool_size": cls.POOL_SIZE,
            "max_overflow": cls.MAX_OVERFLOW,
            "pool_timeout": cls.POOL_TIMEOUT,
            "pool_recycle": cls.POOL_RECYCLE,
            "echo": cls.ECHO
        }


# ==================== Cache Helper ====================

class CacheHelper:
    """
    Simple caching helper for frequently accessed data
    
    For production, use Redis instead.
    """
    
    _cache: Dict[str, Dict] = {}
    
    @classmethod
    async def get(cls, key: str) -> Optional[Any]:
        """Get cached value"""
        if key in cls._cache:
            entry = cls._cache[key]
            if entry["expires_at"] > datetime.now(timezone.utc):
                return entry["value"]
            else:
                del cls._cache[key]
        return None
    
    @classmethod
    async def set(cls, key: str, value: Any, ttl_seconds: int = 300):
        """Set cached value"""
        cls._cache[key] = {
            "value": value,
            "expires_at": datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
        }
    
    @classmethod
    async def delete(cls, key: str):
        """Delete cached value"""
        if key in cls._cache:
            del cls._cache[key]
    
    @classmethod
    async def clear(cls):
        """Clear all cached values"""
        cls._cache.clear()
