"""
Permission Middleware and Utilities
Server-side enforcement of RBAC permissions and multi-tenancy
"""
from typing import Optional, List, Dict, Any, Callable, TypeVar
from uuid import UUID
from functools import wraps
from enum import Enum

from fastapi import HTTPException, status, Depends, Request
from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.security import get_current_user, decode_token
from app.modules.users.models import User, Role, Permission, DataScope


F = TypeVar("F", bound=Callable[..., Any])


def require_company_access(entity_company_id_field: str = "company_id"):
    """
    Decorator to enforce company access control on routes.
    
    Usage:
        @router.get("/items/{item_id}")
        @require_company_access("company_id")
        async def get_item(item_id: UUID, current_user: User = Depends(get_current_user)):
            # item.company_id will be checked against current_user.company_id
            pass
    
    For use in service layer, pass the company_id explicitly.
    """
    def decorator(func: F) -> F:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Get current_user from kwargs
            current_user = kwargs.get('current_user')
            if not current_user:
                for arg in args:
                    if isinstance(arg, User):
                        current_user = arg
                        break
            
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication required"
                )
            
            # Superusers bypass company checks
            if getattr(current_user, 'is_superuser', False):
                return await func(*args, **kwargs)
            
            # User must have a company assigned
            if not current_user.company_id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: User not associated with any company"
                )
            
            # Check company_id in kwargs (for service layer)
            company_id = kwargs.get('company_id') or kwargs.get(entity_company_id_field)
            
            # If company_id is specified, verify it matches user's company
            if company_id and str(company_id) != str(current_user.company_id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: Invalid company context"
                )
            
            # Add company_id to kwargs if not present
            if 'company_id' not in kwargs and current_user.company_id:
                kwargs['company_id'] = current_user.company_id
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


async def check_company_access(
    current_user: User,
    resource_company_id: Optional[UUID] = None
) -> bool:
    """
    Check if user has access to resources in a specific company.
    Always validates company_id for non-superusers.
    
    Args:
        current_user: The authenticated user
        resource_company_id: The company ID of the resource being accessed
        
    Returns:
        True if access is allowed, False otherwise
    """
    # Superusers have access to all companies
    if current_user.is_superuser:
        return True
    
    # User must have a company assigned
    if not current_user.company_id:
        return False
    
    # If resource company is specified, it must match user's company
    if resource_company_id:
        return str(resource_company_id) == str(current_user.company_id)
    
    # For operations without explicit resource (like create), check user has company
    return True


def enforce_company_filter(query, model_class, user: User):
    """
    Enforce company filter on SQLAlchemy query.
    
    Args:
        query: SQLAlchemy query object
        model_class: The model class being queried
        user: Current user
        
    Returns:
        Filtered query
    """
    if user.is_superuser:
        return query
    
    if hasattr(model_class, 'company_id'):
        return query.where(model_class.company_id == user.company_id)
    
    return query


class PermissionResult:
    """Result of permission check"""
    
    def __init__(
        self,
        allowed: bool,
        message: str = "",
        restricted_fields: List[str] = None,
        data_scope: DataScope = DataScope.ALL
    ):
        self.allowed = allowed
        self.message = message
        self.restricted_fields = restricted_fields or []
        self.data_scope = data_scope
    
    def __bool__(self) -> bool:
        return self.allowed


class PermissionChecker:
    """
    Advanced permission checker with data scope and field restrictions
    
    Usage:
        @router.get("/deals")
        async def list_deals(
            checker: PermissionResult = Depends(PermissionChecker("deals.read"))
        ):
            # checker.data_scope contains the scope for filtering
            # checker.restricted_fields contains fields to exclude
            pass
    """
    
    def __init__(self, permission_code: str, raise_exception: bool = True):
        """
        Initialize permission checker
        
        Args:
            permission_code: Permission code (e.g., "deals.read")
            raise_exception: If True, raises HTTPException on denial
        """
        self.permission_code = permission_code
        self.raise_exception = raise_exception
        self._entity = permission_code.split('.')[0] if '.' in permission_code else permission_code
        self._action = permission_code.split('.')[1] if '.' in permission_code else 'read'
    
    async def __call__(
        self,
        request: Request,
        current_user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
    ) -> PermissionResult:
        """
        Check if user has the required permission
        
        Args:
            request: FastAPI request
            current_user: Authenticated user
            db: Database session
        
        Returns:
            PermissionResult with access details
        """
        # Superuser has all permissions
        if current_user.is_superuser:
            return PermissionResult(
                allowed=True,
                data_scope=DataScope.ALL
            )
        
        # User must have a company assigned for non-superuser access
        if not current_user.company_id:
            if self.raise_exception:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: User not associated with any company"
                )
            return PermissionResult(
                allowed=False,
                message="User not associated with any company"
            )
        
        # Get user's permissions through roles
        permissions = await self._get_user_permissions(db, current_user.id)
        
        # Find matching permission
        matching_perm = None
        for perm in permissions:
            if perm.code == self.permission_code:
                matching_perm = perm
                break
            
            # Check for wildcard permissions (e.g., "deals.*")
            if perm.code.endswith('.*') and perm.code.startswith(self._entity + '.'):
                matching_perm = perm
                break
        
        if not matching_perm:
            if self.raise_exception:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permission denied: {self.permission_code}"
                )
            return PermissionResult(
                allowed=False,
                message=f"Missing permission: {self.permission_code}"
            )
        
        # Get data scope and restricted fields
        data_scope = DataScope(matching_perm.data_scope or DataScope.ALL.value)
        restricted_fields = matching_perm.restricted_fields or []
        
        return PermissionResult(
            allowed=True,
            data_scope=data_scope,
            restricted_fields=restricted_fields
        )
    
    async def _get_user_permissions(
        self,
        db: AsyncSession,
        user_id: UUID
    ) -> List[Permission]:
        """Get all active permissions for a user through their roles"""
        query = (
            select(Permission)
            .join(Permission.roles)
            .join(Role.users)
            .where(
                User.id == user_id,
                User.is_active == True,
                User.deleted_at.is_(None),
                Role.is_active == True,
                Role.deleted_at.is_(None),
                Permission.is_active == True
            )
            .distinct()
        )
        
        result = await db.execute(query)
        return list(result.scalars().all())


class DataScopeFilter:
    """
    Utility to apply data scope filters to queries
    
    Usage:
        query = select(Model)
        filter = DataScopeFilter(user, Model, DataScope.DEPARTMENT)
        query = filter.apply(query)
    """
    
    def __init__(
        self,
        user: User,
        model_class: Any,
        scope: DataScope,
        owner_field: str = "responsible_id",
        department_field: str = "department_id",
        team_field: str = "team_id"
    ):
        """
        Initialize data scope filter
        
        Args:
            user: Current user
            model_class: SQLAlchemy model class
            scope: Data scope to apply
            owner_field: Field name for owner ID
            department_field: Field name for department ID
            team_field: Field name for team ID
        """
        self.user = user
        self.model_class = model_class
        self.scope = scope
        self.owner_field = owner_field
        self.department_field = department_field
        self.team_field = team_field
    
    def apply(self, query):
        """
        Apply data scope filter to query
        
        Args:
            query: SQLAlchemy query
        
        Returns:
            Filtered query
        """
        model = self.model_class
        
        if self.scope == DataScope.ALL:
            return query
        
        if self.scope == DataScope.OWN:
            return query.where(
                getattr(model, self.owner_field) == self.user.id
            )
        
        if self.scope == DataScope.DEPARTMENT:
            # Get entities from user's department
            # Either owned by user or by someone in same department
            return query.where(
                or_(
                    getattr(model, self.owner_field) == self.user.id,
                    getattr(model, self.department_field) == self.user.department_id
                )
            )
        
        if self.scope == DataScope.TEAM:
            # Get entities from user's team
            return query.where(
                or_(
                    getattr(model, self.owner_field) == self.user.id,
                    getattr(model, self.team_field) == self.user.team_id
                )
            )
        
        return query


class FieldRestrictionFilter:
    """
    Utility to filter out restricted fields from response data
    
    Usage:
        data = deal.to_dict()
        filtered = FieldRestrictionFilter.apply(data, restricted_fields)
    """
    
    @staticmethod
    def apply(data: Dict[str, Any], restricted_fields: List[str]) -> Dict[str, Any]:
        """
        Remove restricted fields from data dictionary
        
        Args:
            data: Data dictionary
            restricted_fields: List of field names to remove
        
        Returns:
            Filtered data dictionary
        """
        if not restricted_fields:
            return data
        
        return {
            k: v for k, v in data.items()
            if k not in restricted_fields
        }
    
    @staticmethod
    def apply_to_list(
        data_list: List[Dict[str, Any]],
        restricted_fields: List[str]
    ) -> List[Dict[str, Any]]:
        """
        Remove restricted fields from list of data dictionaries
        
        Args:
            data_list: List of data dictionaries
            restricted_fields: List of field names to remove
        
        Returns:
            Filtered list of data dictionaries
        """
        return [
            FieldRestrictionFilter.apply(item, restricted_fields)
            for item in data_list
        ]


async def check_entity_access(
    entity_type: str,
    action: str,
    user: User,
    db: AsyncSession,
    entity_owner_id: UUID = None,
    entity_department_id: UUID = None,
    entity_team_id: UUID = None
) -> PermissionResult:
    """
    Check if user can access a specific entity
    
    Args:
        entity_type: Entity type (deals, clients, tasks)
        action: Action (read, update, delete)
        user: Current user
        db: Database session
        entity_owner_id: ID of entity owner
        entity_department_id: ID of entity department
        entity_team_id: ID of entity team
    
    Returns:
        PermissionResult with access details
    """
    permission_code = f"{entity_type}.{action}"
    
    # Superuser has all access
    if user.is_superuser:
        return PermissionResult(allowed=True, data_scope=DataScope.ALL)
    
    # Get user's permissions
    checker = PermissionChecker(permission_code, raise_exception=False)
    # Note: This function should be called from async context
    # Using db.execute directly since we have async session
    result = await checker._get_user_permissions(db, user.id)
    
    # Find matching permission
    for perm in result:
        if perm.code == permission_code or perm.code == f"{entity_type}.*":
            # Check data scope
            has_access = perm.check_data_access(
                user=user,
                entity_owner_id=entity_owner_id,
                entity_department_id=entity_department_id,
                entity_team_id=entity_team_id
            )
            
            if has_access:
                return PermissionResult(
                    allowed=True,
                    data_scope=DataScope(perm.data_scope or DataScope.ALL.value),
                    restricted_fields=perm.restricted_fields or []
                )
    
    return PermissionResult(
        allowed=False,
        message=f"Access denied to {entity_type}.{action}"
    )


async def validate_field_modification(
    entity_type: str,
    user: User,
    db: AsyncSession,
    fields_to_modify: List[str]
) -> tuple[bool, List[str]]:
    """
    Validate if user can modify specific fields
    
    Args:
        entity_type: Entity type (deals, clients, tasks)
        user: Current user
        db: Database session
        fields_to_modify: List of field names to modify
    
    Returns:
        Tuple of (is_valid, forbidden_fields)
    """
    if user.is_superuser:
        return (True, [])
    
    if not fields_to_modify:
        return (True, [])
    
    permission_code = f"{entity_type}.update"
    checker = PermissionChecker(permission_code, raise_exception=False)
    
    # Get user's permissions
    permissions = await checker._get_user_permissions(db, user.id)
    
    # Collect all restricted fields from matching permissions
    restricted_fields = set()
    has_matching_permission = False
    
    for perm in permissions:
        if perm.code == permission_code or perm.code == f"{entity_type}.*":
            has_matching_permission = True
            if perm.restricted_fields:
                restricted_fields.update(perm.restricted_fields)
    
    # If no matching permission found, user can't modify anything
    if not has_matching_permission:
        return (False, fields_to_modify)
    
    # Check which fields are forbidden
    fields_set = set(fields_to_modify)
    forbidden = fields_set.intersection(restricted_fields)
    
    return (len(forbidden) == 0, list(forbidden))


# Decorator for protecting routes with permission check
def require_permission(permission_code: str):
    """
    Decorator to require permission for a route
    
    Usage:
        @router.get("/deals")
        @require_permission("deals.read")
        async def list_deals():
            pass
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Permission check is handled by PermissionChecker dependency
            return await func(*args, **kwargs)
        return wrapper
    return decorator