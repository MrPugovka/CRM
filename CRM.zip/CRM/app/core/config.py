"""
Application Configuration
"""
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional, List
from functools import lru_cache
from pathlib import Path
import os


def _validate_jwt_secret(secret: str) -> str:
    """
    Validate JWT_SECRET for production security requirements.
    - Minimum 32 bytes (256 bits)
    - Cannot use common default/test values
    """
    if not secret:
        raise ValueError(
            "JWT_SECRET must be set in environment variables. "
            "Generate a secure key with: openssl rand -hex 32"
        )
    
    # Check length (minimum 32 characters for hex, or 32 bytes for base64)
    if len(secret) < 32:
        raise ValueError(
            f"JWT_SECRET must be at least 32 characters long. "
            f"Current length: {len(secret)}. "
            "Generate a secure key with: openssl rand -hex 32"
        )
    
    # Check for common insecure defaults
    insecure_defaults = [
        "secret", "test", "123", "password", "admin", "default",
        "changeme", "qwerty", "letmein", "welcome", "abc123",
        "jwt_secret", "mysecret", "supersecret", "verysecret"
    ]
    
    secret_lower = secret.lower()
    for insecure in insecure_defaults:
        if insecure in secret_lower:
            raise ValueError(
                f"JWT_SECRET contains insecure pattern: '{insecure}'. "
                "Please use a cryptographically secure random string. "
                "Generate with: openssl rand -hex 32"
            )
    
    return secret


def _get_debug_from_env() -> bool:
    """Check DEBUG setting from environment or .env file at module load time"""
    # First check actual environment variable
    env_debug = os.getenv("DEBUG")
    if env_debug is not None:
        return env_debug.lower() in ("true", "1", "yes")
    
    # Fallback to reading .env file directly
    # Look for .env file in current directory and parent directories
    current_dir = Path(__file__).parent.parent.parent  # app/core/config.py -> project root
    env_paths = [current_dir / ".env", Path(".env").resolve()]
    
    for env_path in env_paths:
        if env_path.exists():
            try:
                with open(env_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("DEBUG="):
                            value = line.split("=", 1)[1].strip().strip('"\'')
                            return value.lower() in ("true", "1", "yes")
            except (IOError, OSError):
                continue
    
    return False  # Default to strict mode (production)


def parse_cors_origins(v: str) -> List[str]:
    """Parse CORS origins from comma-separated string"""
    if isinstance(v, str):
        return [origin.strip() for origin in v.split(",") if origin.strip()]
    return v


def validate_debug_in_production(environment: str, debug: bool) -> None:
    """
    Validate that DEBUG cannot be True in production environment.
    This is a security requirement to prevent accidental debug mode in production.
    """
    if environment.lower() == "production" and debug:
        raise ValueError(
            "DEBUG cannot be True in production environment. "
            "Set DEBUG=False in your .env file or environment variables."
        )


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    APP_NAME: str = "CRM System"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "development"
    # Additional app settings (from .env)
    APP_ENV: str = "development"
    APP_PORT: int = 8000
    APP_HOST: str = "0.0.0.0"
    
    # Database - SQLite for development, PostgreSQL for production
    DATABASE_URL: str = "sqlite+aiosqlite:///./crm.db"
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_PASSWORD: Optional[str] = None
    
    # RabbitMQ - Optional with sensible default for development
    RABBITMQ_URL: str = "amqp://guest:guest@localhost:5672/"  # Default for local development
    
    # S3 Storage - MUST be configured explicitly
    S3_ENDPOINT: Optional[str] = None
    S3_ACCESS_KEY: Optional[str] = None
    S3_SECRET_KEY: Optional[str] = None
    S3_BUCKET: str = "crm-files"  # Bucket name can keep default
    S3_BUCKET_NAME: Optional[str] = None  # Alias for compatibility
    S3_REGION: str = "us-east-1"
    
    # JWT Authentication - No fallback for security
    JWT_SECRET: str
    SECRET_KEY: Optional[str] = None  # Alias for session signing
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 15  # OWASP ASVS Level 2: 10-15 minutes max
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15  # Alias for compatibility
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7  # Alias for compatibility
    
    # Brute Force Protection
    MAX_FAILED_LOGIN_ATTEMPTS: int = 5
    LOGIN_LOCKOUT_MINUTES: int = 15
    
    # Allowed Origins for CSRF
    ALLOWED_ORIGINS: str = "http://localhost:3000,http://localhost:8000"
    
    def model_post_init(self, __context) -> None:
        """Validate security settings after initialization"""
        # Validate JWT_SECRET meets security requirements
        _validate_jwt_secret(self.JWT_SECRET)
        
        # Validate DEBUG is not True in production
        validate_debug_in_production(self.ENVIRONMENT, self.DEBUG)
        
        # Set SECRET_KEY from JWT_SECRET if not provided
        if not self.SECRET_KEY:
            object.__setattr__(self, 'SECRET_KEY', self.JWT_SECRET)
    
    # Password hashing
    PASSWORD_BCRYPT_ROUNDS: int = 12
    
    # CORS - Parse from comma-separated string in .env
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:8000"
    
    # File uploads
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    MAX_UPLOAD_SIZE: int = 50 * 1024 * 1024  # Alias for compatibility
    UPLOAD_DIR: str = "./uploads"
    ALLOWED_EXTENSIONS: list[str] = [
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
        "jpg", "jpeg", "png", "gif", "svg",
        "txt", "csv", "json", "xml"
    ]
    
    # Email
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    SMTP_FROM_EMAIL: Optional[str] = None
    SMTP_TLS: bool = True
    
    # Telegram Bot
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_WEBHOOK_SECRET: Optional[str] = None
    
    # WhatsApp Business API (Meta)
    WHATSAPP_VERIFY_TOKEN: Optional[str] = None
    WHATSAPP_ACCESS_TOKEN: Optional[str] = None
    WHATSAPP_PHONE_NUMBER_ID: Optional[str] = None

    # Webhook Security - Production Enforcement
    ALLOW_UNSIGNED_WEBHOOKS: bool = False  # Must be explicitly True to allow unsigned webhooks

    # Google OAuth - Drive Integration
    GOOGLE_CLIENT_ID: Optional[str] = None
    GOOGLE_CLIENT_SECRET: Optional[str] = None
    GOOGLE_REDIRECT_URI: Optional[str] = "http://localhost:8000/api/v1/integrations/google/callback"
    GOOGLE_CREDENTIALS_PATH: Optional[str] = None
    GOOGLE_TOKEN_ENCRYPTION_KEY: Optional[str] = None

    # Pagination
    DEFAULT_PAGE_SIZE: int = 20
    MAX_PAGE_SIZE: int = 100
    
    # Rate Limiting
    RATE_LIMIT_LOGIN: str = "5/minute"
    RATE_LIMIT_API: str = "100/minute"
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    
    # Database connection details (for building DATABASE_URL dynamically)
    DB_HOST: Optional[str] = None
    DB_PORT: Optional[str] = None
    DB_USER: Optional[str] = None
    DB_PASSWORD: Optional[str] = None
    DB_NAME: Optional[str] = None
    
    # Redis connection details
    REDIS_HOST: Optional[str] = None
    REDIS_PORT: Optional[str] = None
    
    # Sentry integration
    SENTRY_DSN: Optional[str] = None
    
    # Nginx configuration (for Docker deployments)
    NGINX_PORT: Optional[str] = None
    NGINX_SSL_PORT: Optional[str] = None
    
    # Testing
    TEST_DATABASE_URL: Optional[str] = None
    PYTEST_CURRENT_TEST: Optional[str] = None
    
    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True,
        # Always forbid extra fields to catch typos in configuration
        # This applies to both development and production for consistency
        extra="forbid"
    )


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()


settings = get_settings()
