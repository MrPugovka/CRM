"""
Shared Template Utilities
Provides a centralized Jinja2 template environment with custom filters
"""
from datetime import datetime
from fastapi.templating import Jinja2Templates


def format_currency(value):
    """Format number as currency (Russian Ruble)"""
    if value is None:
        return "0 ₽"
    try:
        value = float(value)
        return f"{value:,.0f} ₽".replace(",", " ")
    except (ValueError, TypeError):
        return "0 ₽"


def format_datetime(value):
    """Format datetime to Russian locale string"""
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except:
            return value
    if isinstance(value, datetime):
        return value.strftime("%d.%m.%Y %H:%M")
    return str(value)


def format_date(value):
    """Format date to Russian locale string"""
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except:
            return value
    if isinstance(value, datetime):
        return value.strftime("%d.%m.%Y")
    return str(value)


# Create shared templates instance with filters
templates = Jinja2Templates(directory="templates")
templates.env.filters['currency'] = format_currency
templates.env.filters['datetime'] = format_datetime
templates.env.filters['date'] = format_date


# Re-export for convenience
__all__ = ['templates', 'format_currency', 'format_datetime', 'format_date']
