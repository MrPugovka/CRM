"""
Encryption utilities for sensitive data
Uses Fernet symmetric encryption
"""
import os
import logging
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)


class TokenEncryptionError(Exception):
    """Encryption/decryption error"""
    pass


class TokenEncryptor:
    """
    Encryptor for sensitive tokens (OAuth tokens, API keys, etc.)
    Uses Fernet symmetric encryption
    """

    def __init__(self, key: Optional[str] = None):
        """
        Initialize encryptor with encryption key
        
        Args:
            key: Fernet key (base64-encoded 32-byte key)
                 If not provided, reads from GOOGLE_TOKEN_ENCRYPTION_KEY env var
        """
        encryption_key = key or os.getenv("GOOGLE_TOKEN_ENCRYPTION_KEY")
        
        if not encryption_key:
            raise RuntimeError(
                "GOOGLE_TOKEN_ENCRYPTION_KEY is not configured. "
                "Token encryption is mandatory. "
                "Generate key with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
            )
        
        try:
            self._fernet = Fernet(encryption_key.encode())
        except Exception as e:
            logger.error(f"Failed to initialize Fernet: {e}")
            raise TokenEncryptionError(f"Invalid encryption key: {e}")

    def encrypt(self, value: Optional[str]) -> Optional[str]:
        """
        Encrypt a string value
        
        Args:
            value: String to encrypt
            
        Returns:
            Encrypted string or None if input is None
            
        Raises:
            TokenEncryptionError: If encryption fails
        """
        if value is None:
            return None
        
        try:
            encrypted = self._fernet.encrypt(value.encode())
            return encrypted.decode()
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise TokenEncryptionError(f"Failed to encrypt value: {e}")

    def decrypt(self, value: Optional[str]) -> Optional[str]:
        """
        Decrypt an encrypted string
        
        Args:
            value: Encrypted string
            
        Returns:
            Decrypted string or None if input is None
            
        Raises:
            TokenEncryptionError: If decryption fails
        """
        if value is None:
            return None
        
        try:
            decrypted = self._fernet.decrypt(value.encode())
            return decrypted.decode()
        except InvalidToken:
            logger.error("Decryption failed: Invalid token (possible key mismatch)")
            raise TokenEncryptionError("Failed to decrypt: Invalid token")
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise TokenEncryptionError(f"Failed to decrypt value: {e}")

    def rotate_key(self, old_key: str, new_key: str, encrypted_value: str) -> str:
        """
        Re-encrypt a value with a new key
        
        Args:
            old_key: Current encryption key
            new_key: New encryption key
            encrypted_value: Value encrypted with old key
            
        Returns:
            Value re-encrypted with new key
        """
        old_encryptor = TokenEncryptor(old_key)
        new_encryptor = TokenEncryptor(new_key)
        
        decrypted = old_encryptor.decrypt(encrypted_value)
        return new_encryptor.encrypt(decrypted)


# Global encryptor instance
_encryptor_instance: Optional[TokenEncryptor] = None


def get_token_encryptor() -> TokenEncryptor:
    """Get or create global token encryptor instance"""
    global _encryptor_instance
    if _encryptor_instance is None:
        _encryptor_instance = TokenEncryptor()
    return _encryptor_instance


def generate_encryption_key() -> str:
    """Generate a new Fernet encryption key"""
    return Fernet.generate_key().decode()


# Convenience functions for direct usage
def encrypt_token(value: Optional[str]) -> Optional[str]:
    """Encrypt a token using global encryptor"""
    return get_token_encryptor().encrypt(value)


def decrypt_token(value: Optional[str]) -> Optional[str]:
    """Decrypt a token using global encryptor"""
    return get_token_encryptor().decrypt(value)
