"""
Multi-tenancy utilities for data isolation
Ensures all queries are filtered by company_id
"""
from typing import Optional, TypeVar, Type, Any
from uuid import UUID
from contextvars import ContextVar
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Query
from fastapi import Depends, HTTPException, status

from app.core.security import get_current_user
from app.modules.users.models import User

# Context variable for current company_id (for background tasks or service layer)
current_company_id: ContextVar[Optional[UUID]] = ContextVar('current_company_id', default=None)


T = TypeVar('T')


def get_company_filter_clause(model_class: Type[T], company_id: UUID) -> Any:
    """
    Generate a filter clause for company_id
    
    Args:
        model_class: SQLAlchemy model class
        company_id: Company ID to filter by
        
    Returns:
        Filter clause for query
    """
    return model_class.company_id == company_id


def apply_company_filter(
    query: Any,
    model_class: Type[T],
    company_id: UUID
) -> Any:
    """
    Apply company filter to a query
    
    Args:
        query: SQLAlchemy query object
        model_class: Model class with company_id
        company_id: Company ID to filter by
        
    Returns:
        Filtered query
    """
    return query.where(model_class.company_id == company_id)


def filter_by_company(
    stmt: Any,
    model_class: Type[T],
    user: User
) -> Any:
    """
    Filter a select statement by user's company
    Superusers bypass the filter
    
    Args:
        stmt: SQLAlchemy select statement
        model_class: Model class with company_id
        user: Current user
        
    Returns:
        Filtered statement
    """
    if user.is_superuser:
        return stmt
    
    if not user.company_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is not associated with any company"
        )
    
    return stmt.where(model_class.company_id == user.company_id)


async def get_current_company_id(
    current_user: User = Depends(get_current_user)
) -> UUID:
    """
    Dependency to get current company_id from authenticated user
    
    Args:
        current_user: Current authenticated user
        
    Returns:
        Company ID
        
    Raises:
        HTTPException: If user has no company
    """
    if current_user.is_superuser:
        # Superusers can specify company_id in header or use their own
        # For now, return their company_id if set
        if current_user.company_id:
            return current_user.company_id
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Superuser must be associated with a company"
        )
    
    if not current_user.company_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is not associated with any company"
        )
    
    return current_user.company_id


class CompanyFilter:
    """
    Helper class for applying company filters in service layer
    
    Usage:
        filter = CompanyFilter(current_user)
        stmt = filter.apply(select(Model), Model)
        results = await db.execute(stmt)
    """
    
    def __init__(self, user: User):
        self.user = user
        self.company_id = user.company_id
        self.is_superuser = user.is_superuser
    
    def apply(self, stmt: Any, model_class: Type[T]) -> Any:
        """Apply company filter to statement"""
        if self.is_superuser:
            return stmt
        
        if not self.company_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User is not associated with any company"
            )
        
        return stmt.where(model_class.company_id == self.company_id)
    
    def filter_query(self, query: Query, model_class: Type[T]) -> Query:
        """Apply company filter to ORM query"""
        if self.is_superuser:
            return query
        
        if not self.company_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User is not associated with any company"
            )
        
        return query.filter(model_class.company_id == self.company_id)
    
    def check_ownership(self, obj: Any) -> bool:
        """Check if user owns the object (same company)"""
        if self.is_superuser:
            return True
        
        if not hasattr(obj, 'company_id'):
            return True  # No company_id means no restriction
        
        return str(obj.company_id) == str(self.company_id)
    
    def enforce_ownership(self, obj: Any) -> None:
        """Enforce ownership - raise if user doesn't own the object"""
        if not self.check_ownership(obj):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You don't have access to this resource"
            )


def require_company_access(user: User, company_id: UUID) -> None:
    """
    Require that user has access to specific company
    
    Args:
        user: User to check
        company_id: Company ID to check access for
        
    Raises:
        HTTPException: If user doesn't have access
    """
    if user.is_superuser:
        return
    
    if str(user.company_id) != str(company_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You don't have access to this company"
        )


# Decorator for service methods to enforce company filter
def with_company_filter(func):
    """
    Decorator that automatically applies company filter to queries
    Note: This is a placeholder - actual implementation depends on your service structure
    """
    async def wrapper(self, *args, **kwargs):
        # Get company_id from service instance
        company_id = getattr(self, 'company_id', None)
        if company_id:
            # Apply filter logic here
            pass
        return await func(self, *args, **kwargs)
    return wrapper