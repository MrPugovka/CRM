"""
CSRF Protection Module
Provides CSRF token generation and validation for HTML forms
"""
import secrets
import hashlib
import hmac
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import Request, HTTPException, status, Depends
from fastapi.responses import Response
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from app.core.config import settings

# Secret key for CSRF tokens (must be kept secret)
# Use JWT_SECRET for CSRF token signing - MUST be set, no fallback for security
CSRF_TOKEN_SALT = "csrf-token"
CSRF_COOKIE_NAME = "csrf_token"
CSRF_HEADER_NAME = "X-CSRF-Token"
CSRF_FORM_FIELD = "csrf_token"
SESSION_COOKIE_NAME = "session_id"

# Token lifetime
CSRF_TOKEN_MAX_AGE = 3600  # 1 hour
SESSION_MAX_AGE = 86400  # 24 hours

# Serializer will be initialized lazily
_serializer = None


def _get_csrf_secret():
    """Get CSRF secret with runtime validation"""
    if not settings.JWT_SECRET:
        raise ValueError(
            "JWT_SECRET must be set in environment variables for CSRF protection. "
            "Generate a secure key with: openssl rand -hex 32"
        )
    return settings.JWT_SECRET


def get_serializer():
    """Get or create URLSafeTimedSerializer instance (lazy initialization)"""
    global _serializer
    if _serializer is None:
        _serializer = URLSafeTimedSerializer(_get_csrf_secret(), salt=CSRF_TOKEN_SALT)
    return _serializer


class CSRFProtection:
    """CSRF protection handler"""
    
    def generate_token(self, session_id: str) -> str:
        """Generate CSRF token for session"""
        timestamp = datetime.now(timezone.utc).isoformat()
        data = f"{session_id}:{timestamp}"
        return get_serializer().dumps(data)
    
    def validate_token(self, token: str, session_id: str, max_age: int = CSRF_TOKEN_MAX_AGE) -> bool:
        """Validate CSRF token"""
        try:
            data = get_serializer().loads(token, max_age=max_age)
            stored_session_id, _ = data.split(":", 1)
            return hmac.compare_digest(stored_session_id, session_id)
        except (SignatureExpired, BadSignature, ValueError):
            return False


csrf_protection = CSRFProtection()


def get_csrf_token(request: Request) -> Optional[str]:
    """Get CSRF token from cookie"""
    return request.cookies.get(CSRF_COOKIE_NAME)


def set_csrf_cookie(response: Response, token: str) -> None:
    """Set CSRF token in HTTP-only cookie with secure settings"""
    from app.core.cookies import set_secure_cookie, COOKIE_SECURE
    set_secure_cookie(
        response=response,
        key=CSRF_COOKIE_NAME,
        value=token,
        max_age=CSRF_TOKEN_MAX_AGE,
        httponly=True,  # Not accessible via JavaScript
        secure=COOKIE_SECURE,  # HTTPS only in production
        samesite="Strict",
        path="/"
    )


def clear_csrf_cookie(response: Response) -> None:
    """Clear CSRF cookie"""
    response.delete_cookie(
        key=CSRF_COOKIE_NAME,
        path="/"
    )


async def get_csrf_from_request(request: Request) -> Optional[str]:
    """Get CSRF token from request (form data or header)"""
    # Try header first
    token = request.headers.get(CSRF_HEADER_NAME)
    if token:
        return token
    
    # Try form data
    try:
        form_data = await request.form()
        if hasattr(form_data, 'get'):
            return form_data.get(CSRF_FORM_FIELD)
    except Exception:
        pass
    
    return None


def get_or_create_session_id(request: Request, response: Optional[Response] = None) -> str:
    """
    Get existing session ID from cookie or generate a new cryptographically secure one.
    Uses secrets.token_urlsafe for secure random generation.
    """
    # Try to get existing session ID from cookie
    session_id = request.cookies.get(SESSION_COOKIE_NAME)
    if session_id:
        return session_id
    
    # Generate new secure session ID (32 bytes = 256 bits of entropy)
    session_id = secrets.token_urlsafe(32)
    
    # Set session cookie if response is provided
    if response:
        from app.core.cookies import set_secure_cookie, COOKIE_SECURE
        set_secure_cookie(
            response=response,
            key=SESSION_COOKIE_NAME,
            value=session_id,
            max_age=SESSION_MAX_AGE,
            httponly=True,
            secure=COOKIE_SECURE,
            samesite="Strict",
            path="/"
        )
    
    return session_id


def get_allowed_origins() -> list[str]:
    """Get list of allowed origins from settings"""
    from app.core.config import settings
    origins = settings.ALLOWED_ORIGINS or settings.CORS_ORIGINS
    if isinstance(origins, str):
        return [o.strip() for o in origins.split(",") if o.strip()]
    return origins


def validate_origin(request: Request) -> bool:
    """
    Validate Origin/Referer header against allowed origins.
    
    This provides additional CSRF protection by ensuring requests
    come from trusted origins.
    """
    origin = request.headers.get("Origin")
    referer = request.headers.get("Referer")
    
    allowed_origins = get_allowed_origins()
    
    # If no origin/referer, check if it's a same-origin request (has CSRF cookie)
    if not origin and not referer:
        # For requests without Origin (e.g., same-origin), rely on CSRF token validation
        return True
    
    # Check Origin header
    if origin:
        origin_lower = origin.lower().rstrip("/")
        for allowed in allowed_origins:
            allowed_lower = allowed.lower().rstrip("/")
            if origin_lower == allowed_lower or origin_lower.startswith(allowed_lower + "/"):
                return True
        return False
    
    # Check Referer header as fallback
    if referer:
        from urllib.parse import urlparse
        parsed = urlparse(referer)
        referer_origin = f"{parsed.scheme}://{parsed.netloc}".lower()
        
        for allowed in allowed_origins:
            allowed_lower = allowed.lower().rstrip("/")
            if referer_origin == allowed_lower or referer_origin.startswith(allowed_lower + "/"):
                return True
        return False
    
    return True


async def require_csrf_token(request: Request) -> None:
    """
    Dependency to require valid CSRF token for POST/PUT/DELETE requests
    with origin validation.
    """
    # Skip CSRF for safe methods
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    
    # Validate Origin/Referer for state-changing requests
    if not validate_origin(request):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid origin. Request must come from an allowed origin."
        )
    
    # Get session identifier from secure session cookie
    session_identifier = request.cookies.get(SESSION_COOKIE_NAME)
    if not session_identifier:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Session cookie missing. Please enable cookies."
        )
    
    # Get token from request
    request_token = get_csrf_from_request(request)
    if not request_token:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token missing. Please include X-CSRF-Token header or csrf_token form field."
        )
    
    # Get token from cookie
    cookie_token = get_csrf_token(request)
    if not cookie_token:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF cookie missing. Please enable cookies."
        )
    
    # Validate that request token matches cookie token
    if not hmac.compare_digest(request_token, cookie_token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token mismatch."
        )
    
    # Validate token signature and expiration
    if not csrf_protection.validate_token(request_token, session_identifier):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token invalid or expired."
        )


def generate_csrf_for_response(response: Response, request: Request) -> str:
    """Generate and set CSRF token for response"""
    session_identifier = get_or_create_session_id(request, response)
    token = csrf_protection.generate_token(session_identifier)
    set_csrf_cookie(response, token)
    return token
