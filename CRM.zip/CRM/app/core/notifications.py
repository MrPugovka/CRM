"""
Core Notification Service
Handles notifications for overdue tasks, mentions, and system events
"""
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
import uuid
import json
import logging
import asyncio

from app.core.database import Base, async_session_maker
from sqlalchemy import Column, String, Text, Boolean, DateTime, ForeignKey, JSON

logger = logging.getLogger(__name__)


class Notification(Base):
    """
    User notifications
    """
    __tablename__ = "notifications"
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    user_id = Column(String(36), ForeignKey('users.id'), nullable=False)
    
    # Notification content
    notification_type = Column(String(50), nullable=False)  # task_overdue, mention, system, etc.
    title = Column(String(200), nullable=False)
    message = Column(Text)
    
    # Additional data
    data = Column(JSON)  # Additional context data
    
    # Status
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime)
    
    # Delivery
    sent_via = Column(JSON)  # ["in_app", "email", "push"]
    sent_at = Column(DateTime)
    
    # Related entity
    entity_type = Column(String(50))  # task, deal, client
    entity_id = Column(String(36))
    
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    
    def __repr__(self):
        return f"<Notification {self.notification_type}: {self.title}>"


class NotificationPreference(Base):
    """
    User notification preferences
    """
    __tablename__ = "notification_preferences"
    
    id = Column(String(36), primary_key=True, default=uuid.uuid4)
    
    user_id = Column(String(36), ForeignKey('users.id'), nullable=False, unique=True)
    
    # Channel preferences
    in_app_enabled = Column(Boolean, default=True)
    email_enabled = Column(Boolean, default=True)
    push_enabled = Column(Boolean, default=False)
    
    # Type preferences
    task_overdue_enabled = Column(Boolean, default=True)
    task_reminder_enabled = Column(Boolean, default=True)
    mention_enabled = Column(Boolean, default=True)
    deal_status_enabled = Column(Boolean, default=True)
    system_enabled = Column(Boolean, default=True)
    
    # Timing
    quiet_hours_start = Column(String(5))  # "22:00"
    quiet_hours_end = Column(String(5))  # "08:00"
    quiet_hours_timezone = Column(String(50), default="UTC")
    
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class NotificationService:
    """
    Service for sending and managing notifications
    """
    
    def __init__(self, session: AsyncSession = None):
        self.session = session or async_session_maker()
    
    async def send_notification(
        self,
        user_id: uuid.UUID,
        notification_type: str,
        title: str,
        message: str = None,
        data: Dict[str, Any] = None,
        entity_type: str = None,
        entity_id: uuid.UUID = None,
        channels: List[str] = None
    ) -> Notification:
        """
        Send a notification to a user
        """
        # Check user preferences
        preferences = await self._get_user_preferences(user_id)
        
        # Determine channels
        if channels is None:
            channels = ["in_app"]
            if preferences and preferences.email_enabled:
                channels.append("email")
        
        # Check if notification type is enabled
        if preferences:
            type_enabled = getattr(preferences, f"{notification_type}_enabled", True)
            if not type_enabled:
                logger.info(f"Notification type {notification_type} disabled for user {user_id}")
                return None
        
        # Create notification
        notification = Notification(
            user_id=user_id,
            notification_type=notification_type,
            title=title,
            message=message,
            data=data,
            entity_type=entity_type,
            entity_id=entity_id,
            sent_via=channels,
            sent_at=datetime.now(timezone.utc)
        )
        
        self.session.add(notification)
        await self.session.commit()
        await self.session.refresh(notification)
        
        # Send via channels
        for channel in channels:
            try:
                if channel == "in_app":
                    # In-app notification is already created
                    pass
                elif channel == "email":
                    await self._send_email_notification(notification)
                elif channel == "push":
                    await self._send_push_notification(notification)
            except Exception as e:
                logger.error(f"Failed to send notification via {channel}: {e}")
        
        logger.info(f"Sent notification {notification.id} to user {user_id}")
        return notification
    
    async def send_bulk_notifications(
        self,
        user_ids: List[uuid.UUID],
        notification_type: str,
        title: str,
        message: str = None,
        data: Dict[str, Any] = None
    ) -> List[Notification]:
        """
        Send notification to multiple users
        """
        notifications = []
        
        for user_id in user_ids:
            notification = await self.send_notification(
                user_id=user_id,
                notification_type=notification_type,
                title=title,
                message=message,
                data=data
            )
            if notification:
                notifications.append(notification)
        
        return notifications
    
    async def get_user_notifications(
        self,
        user_id: uuid.UUID,
        unread_only: bool = False,
        notification_type: str = None,
        page: int = 1,
        page_size: int = 20
    ) -> List[Notification]:
        """
        Get notifications for a user
        """
        query = select(Notification).where(
            Notification.user_id == user_id
        )
        
        if unread_only:
            query = query.where(Notification.is_read == False)
        
        if notification_type:
            query = query.where(Notification.notification_type == notification_type)
        
        query = query.order_by(Notification.created_at.desc())
        query = query.offset((page - 1) * page_size).limit(page_size)
        
        result = await self.session.execute(query)
        return result.scalars().all()
    
    async def mark_as_read(self, notification_id: uuid.UUID) -> Notification:
        """Mark notification as read"""
        query = select(Notification).where(Notification.id == notification_id)
        result = await self.session.execute(query)
        notification = result.scalar_one_or_none()
        
        if notification:
            notification.is_read = True
            notification.read_at = datetime.now(timezone.utc)
            await self.session.commit()
            await self.session.refresh(notification)
        
        return notification
    
    async def mark_all_as_read(self, user_id: uuid.UUID) -> int:
        """Mark all notifications as read for a user"""
        query = select(Notification).where(
            Notification.user_id == user_id,
            Notification.is_read == False
        )
        
        result = await self.session.execute(query)
        notifications = result.scalars().all()
        
        now = datetime.now(timezone.utc)
        count = 0
        
        for notification in notifications:
            notification.is_read = True
            notification.read_at = now
            count += 1
        
        await self.session.commit()
        return count
    
    async def get_unread_count(self, user_id: uuid.UUID) -> int:
        """Get unread notification count"""
        from sqlalchemy import func
        
        query = select(func.count(Notification.id)).where(
            Notification.user_id == user_id,
            Notification.is_read == False
        )
        
        result = await self.session.execute(query)
        return result.scalar() or 0
    
    async def _get_user_preferences(self, user_id: uuid.UUID) -> Optional[NotificationPreference]:
        """Get user notification preferences"""
        query = select(NotificationPreference).where(
            NotificationPreference.user_id == user_id
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def _send_email_notification(self, notification: Notification) -> bool:
        """
        Send notification via email
        This is a placeholder - integrate with actual email service
        """
        # TODO: Integrate with email service (SendGrid, AWS SES, etc.)
        logger.info(f"Email notification would be sent: {notification.title}")
        return True
    
    async def _send_push_notification(self, notification: Notification) -> bool:
        """
        Send push notification
        This is a placeholder - integrate with push service
        """
        # TODO: Integrate with push service (Firebase, Pusher, etc.)
        logger.info(f"Push notification would be sent: {notification.title}")
        return True


class TaskOverdueNotifier:
    """
    Specialized notifier for task overdue events
    """
    
    def __init__(self, session: AsyncSession = None):
        self.notification_service = NotificationService(session)
    
    async def notify_overdue(self, task) -> bool:
        """
        Send overdue notification for a task
        """
        return await self.notification_service.send_notification(
            user_id=task.responsible_id,
            notification_type="task_overdue",
            title="Просрочена задача",
            message=f"Задача '{task.title}' просрочена. Дедлайн: {task.due_date.strftime('%d.%m.%Y %H:%M')}",
            data={
                "task_id": str(task.id),
                "due_date": task.due_date.isoformat(),
                "priority": task.priority
            },
            entity_type="task",
            entity_id=task.id,
            channels=["in_app", "email"]
        )
    
    async def notify_upcoming_deadline(self, task, hours_remaining: int) -> bool:
        """
        Send reminder about upcoming deadline
        """
        return await self.notification_service.send_notification(
            user_id=task.responsible_id,
            notification_type="task_reminder",
            title="Приближается дедлайн",
            message=f"До дедлайна задачи '{task.title}' осталось {hours_remaining} ч.",
            data={
                "task_id": str(task.id),
                "due_date": task.due_date.isoformat(),
                "hours_remaining": hours_remaining
            },
            entity_type="task",
            entity_id=task.id,
            channels=["in_app"]
        )
    
    async def notify_manager_about_overdue(self, manager_id: uuid.UUID, task, overdue_hours: int) -> bool:
        """
        Notify manager about overdue task in their team
        """
        return await self.notification_service.send_notification(
            user_id=manager_id,
            notification_type="team_overdue",
            title="Просрочена задача в команде",
            message=f"Задача '{task.title}' просрочена на {overdue_hours} ч. (ответственный: {task.responsible.full_name if task.responsible else 'N/A'})",
            data={
                "task_id": str(task.id),
                "responsible_id": str(task.responsible_id),
                "overdue_hours": overdue_hours
            },
            entity_type="task",
            entity_id=task.id,
            channels=["in_app"]
        )
