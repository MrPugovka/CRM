"""
Redis client module for secure password reset token storage and rate limiting.
"""
import hashlib
import json
import structlog
from datetime import datetime, timezone, timedelta
from typing import Optional

import redis
from app.core.config import settings

logger = structlog.get_logger(__name__)

# Redis connection instance
_redis_client: Optional[redis.Redis] = None

# Constants for password reset
MAX_RESET_ATTEMPTS = 3  # Максимум 3 попытки в час
RESET_WINDOW_SECONDS = 3600  # 1 час
TOKEN_EXPIRY_SECONDS = 1800  # 30 минут


def get_redis_client() -> Optional[redis.Redis]:
    """
    Get or create Redis client instance.
    Returns None if connection fails.
    """
    global _redis_client
    
    if _redis_client is not None:
        try:
            # Ping to check connection health
            _redis_client.ping()
            return _redis_client
        except redis.ConnectionError:
            logger.warning("Redis connection lost, attempting to reconnect")
            _redis_client = None
    
    try:
        _redis_client = redis.from_url(
            settings.REDIS_URL,
            password=settings.REDIS_PASSWORD,
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=5,
            health_check_interval=30
        )
        _redis_client.ping()
        logger.info("Redis connection established")
        return _redis_client
    except redis.ConnectionError as e:
        logger.error("Failed to connect to Redis", error=str(e))
        return None
    except Exception as e:
        logger.error("Unexpected error connecting to Redis", error=str(e))
        return None


def _hash_token(token: str) -> str:
    """Hash token using SHA-256 for secure storage."""
    return hashlib.sha256(token.encode()).hexdigest()


def _get_token_key(token_hash: str) -> str:
    """Generate Redis key for password reset token."""
    return f"password_reset:{token_hash}"


def _get_attempts_key(email: str, ip: str) -> str:
    """Generate Redis key for rate limiting attempts."""
    return f"password_reset_attempts:{email}:{ip}"


# ==================== Password Reset Token Functions ====================

def store_reset_token(token: str, user_id: int, company_id: Optional[int] = None) -> bool:
    """
    Store password reset token in Redis.
    
    Args:
        token: The raw token string
        user_id: User ID associated with the token
        company_id: Optional company ID for multi-tenant support
        
    Returns:
        True if stored successfully, False otherwise
    """
    redis_client = get_redis_client()
    if redis_client is None:
        logger.error("Cannot store reset token: Redis unavailable")
        return False
    
    try:
        token_hash = _hash_token(token)
        key = _get_token_key(token_hash)
        
        # Clean up any existing tokens for this user
        cleanup_user_tokens(user_id)
        
        token_data = {
            "user_id": user_id,
            "company_id": company_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "used": False
        }
        
        redis_client.setex(
            key,
            TOKEN_EXPIRY_SECONDS,
            json.dumps(token_data)
        )
        
        logger.debug("Reset token stored", user_id=user_id)
        return True
    except redis.RedisError as e:
        logger.error("Failed to store reset token", error=str(e))
        return False
    except Exception as e:
        logger.error("Unexpected error storing reset token", error=str(e))
        return False


def validate_reset_token(token: str) -> Optional[int]:
    """
    Validate a password reset token from Redis.
    
    Args:
        token: The raw token string
        
    Returns:
        User ID if valid, None otherwise
    """
    redis_client = get_redis_client()
    if redis_client is None:
        logger.error("Cannot validate reset token: Redis unavailable")
        return None
    
    try:
        token_hash = _hash_token(token)
        key = _get_token_key(token_hash)
        
        token_data_json = redis_client.get(key)
        if not token_data_json:
            logger.debug("Reset token not found or expired")
            return None
        
        token_data = json.loads(token_data_json)
        
        # Check if already used
        if token_data.get("used", False):
            logger.debug("Reset token already used")
            return None
        
        return token_data.get("user_id")
    except redis.RedisError as e:
        logger.error("Failed to validate reset token", error=str(e))
        return None
    except json.JSONDecodeError as e:
        logger.error("Failed to decode reset token data", error=str(e))
        return None
    except Exception as e:
        logger.error("Unexpected error validating reset token", error=str(e))
        return None


def mark_token_used(token: str) -> bool:
    """
    Mark a password reset token as used.
    
    Args:
        token: The raw token string
        
    Returns:
        True if marked successfully, False otherwise
    """
    redis_client = get_redis_client()
    if redis_client is None:
        logger.error("Cannot mark token as used: Redis unavailable")
        return False
    
    try:
        token_hash = _hash_token(token)
        key = _get_token_key(token_hash)
        
        token_data_json = redis_client.get(key)
        if not token_data_json:
            logger.debug("Token not found when marking as used")
            return False
        
        token_data = json.loads(token_data_json)
        token_data["used"] = True
        token_data["used_at"] = datetime.now(timezone.utc).isoformat()
        
        # Get remaining TTL to preserve expiration
        ttl = redis_client.ttl(key)
        if ttl > 0:
            redis_client.setex(key, ttl, json.dumps(token_data))
        else:
            redis_client.setex(key, TOKEN_EXPIRY_SECONDS, json.dumps(token_data))
        
        logger.debug("Reset token marked as used")
        return True
    except redis.RedisError as e:
        logger.error("Failed to mark token as used", error=str(e))
        return False
    except Exception as e:
        logger.error("Unexpected error marking token as used", error=str(e))
        return False


def cleanup_user_tokens(user_id: int) -> int:
    """
    Clean up all existing tokens for a specific user.
    
    Args:
        user_id: The user ID to clean up tokens for
        
    Returns:
        Number of tokens removed
    """
    redis_client = get_redis_client()
    if redis_client is None:
        return 0
    
    try:
        # Find and delete all tokens for this user
        removed = 0
        cursor = 0
        pattern = "password_reset:*"
        
        while True:
            cursor, keys = redis_client.scan(cursor=cursor, match=pattern, count=100)
            if keys:
                for key in keys:
                    token_data_json = redis_client.get(key)
                    if token_data_json:
                        try:
                            token_data = json.loads(token_data_json)
                            if token_data.get("user_id") == user_id:
                                redis_client.delete(key)
                                removed += 1
                        except json.JSONDecodeError:
                            continue
            
            if cursor == 0:
                break
        
        if removed > 0:
            logger.debug("Cleaned up existing tokens", user_id=user_id, removed=removed)
        return removed
    except redis.RedisError as e:
        logger.error("Failed to cleanup user tokens", error=str(e))
        return 0
    except Exception as e:
        logger.error("Unexpected error cleaning up tokens", error=str(e))
        return 0


# ==================== Rate Limiting Functions ====================

def check_rate_limit(email: str, client_ip: str) -> bool:
    """
    Check if rate limit has been exceeded for password reset attempts.
    Uses Redis sorted sets with timestamps as scores.
    
    Args:
        email: The email address attempting password reset
        client_ip: The client IP address
        
    Returns:
        True if rate limit not exceeded (allow attempt), False otherwise
    """
    redis_client = get_redis_client()
    if redis_client is None:
        logger.error("Cannot check rate limit: Redis unavailable - denying request")
        return False  # Fail-safe: deny if Redis unavailable
    
    try:
        key = _get_attempts_key(email, client_ip)
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(seconds=RESET_WINDOW_SECONDS)
        
        # Convert timestamps to float scores (epoch seconds)
        now_ts = now.timestamp()
        window_start_ts = window_start.timestamp()
        
        # Clean old entries outside the window
        redis_client.zremrangebyscore(key, 0, window_start_ts)
        
        # Count attempts within the window
        attempts = redis_client.zcount(key, window_start_ts, now_ts)
        
        if attempts >= MAX_RESET_ATTEMPTS:
            logger.warning(
                "Rate limit exceeded",
                email=email,
                client_ip=client_ip,
                attempts=attempts
            )
            return False
        
        # Add current attempt
        redis_client.zadd(key, {str(now_ts): now_ts})
        
        # Set/refresh TTL on the sorted set
        redis_client.expire(key, RESET_WINDOW_SECONDS)
        
        return True
    except redis.RedisError as e:
        logger.error("Failed to check rate limit", error=str(e))
        return False  # Fail-safe: deny if Redis error
    except Exception as e:
        logger.error("Unexpected error checking rate limit", error=str(e))
        return False


def get_remaining_attempts(email: str, client_ip: str) -> int:
    """
    Get number of remaining password reset attempts.
    
    Args:
        email: The email address
        client_ip: The client IP address
        
    Returns:
        Number of remaining attempts (0 if at limit or error)
    """
    redis_client = get_redis_client()
    if redis_client is None:
        return 0
    
    try:
        key = _get_attempts_key(email, client_ip)
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(seconds=RESET_WINDOW_SECONDS)
        
        window_start_ts = window_start.timestamp()
        now_ts = now.timestamp()
        
        # Clean old entries
        redis_client.zremrangebyscore(key, 0, window_start_ts)
        
        # Count current attempts
        attempts = redis_client.zcount(key, window_start_ts, now_ts)
        remaining = max(0, MAX_RESET_ATTEMPTS - attempts)
        
        return remaining
    except redis.RedisError as e:
        logger.error("Failed to get remaining attempts", error=str(e))
        return 0
    except Exception as e:
        logger.error("Unexpected error getting remaining attempts", error=str(e))
        return 0


def clear_rate_limit(email: str, client_ip: str) -> bool:
    """
    Clear rate limit data for a specific email/IP combination.
    Useful for administrative purposes.
    
    Args:
        email: The email address
        client_ip: The client IP address
        
    Returns:
        True if cleared successfully, False otherwise
    """
    redis_client = get_redis_client()
    if redis_client is None:
        return False
    
    try:
        key = _get_attempts_key(email, client_ip)
        redis_client.delete(key)
        logger.info("Rate limit cleared", email=email, client_ip=client_ip)
        return True
    except redis.RedisError as e:
        logger.error("Failed to clear rate limit", error=str(e))
        return False
    except Exception as e:
        logger.error("Unexpected error clearing rate limit", error=str(e))
        return False
