"""
Rate Limiting Configuration
Using slowapi for rate limiting
"""
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi import Request, Response

# Create limiter instance
# Uses Redis if REDIS_URL is set, otherwise in-memory storage
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["100/minute"]  # Global default
)


# Custom rate limit exceeded handler
def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    """Custom handler for rate limit exceeded"""
    from fastapi.responses import JSONResponse
    
    return JSONResponse(
        status_code=429,
        content={
            "error": "Rate limit exceeded",
            "detail": str(exc.detail),
            "retry_after": exc.headers.get("Retry-After", "60") if hasattr(exc, 'headers') else "60"
        },
        headers={"Retry-After": exc.headers.get("Retry-After", "60")} if hasattr(exc, 'headers') else {"Retry-After": "60"}
    )


# Specific rate limits for different endpoints
class RateLimits:
    """Rate limit configurations"""
    
    # Authentication endpoints - strict limits
    LOGIN = ["5/minute", "20/hour"]  # 5 per minute, 20 per hour
    REGISTER = ["3/minute", "10/hour"]
    REFRESH_TOKEN = ["10/minute"]
    
    # Resource creation - moderate limits
    CREATE_CLIENT = ["10/minute", "100/hour"]
    CREATE_DEAL = ["10/minute", "100/hour"]
    CREATE_TASK = ["20/minute", "200/hour"]
    
    # Comments and messages - higher limits
    CREATE_COMMENT = ["30/minute"]
    CREATE_MESSAGE = ["30/minute"]
    
    # Read operations - generous limits
    LIST = ["60/minute"]
    GET = ["100/minute"]
    
    # Search - moderate limits
    SEARCH = ["30/minute"]
