"""
Database Configuration and Session Management
"""
from datetime import datetime, timezone
from typing import AsyncGenerator
import uuid

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import Column, DateTime, func, String
from sqlalchemy.dialects.postgresql import UUID as PGUUID

from app.core.config import settings


def get_uuid_column():
    """
    Returns appropriate UUID column type based on database dialect.
    Uses native PostgreSQL UUID when available, String(36) for SQLite compatibility.
    """
    if "postgresql" in settings.DATABASE_URL.lower():
        return Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    else:
        # SQLite compatibility - store as string
        return Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))


# Create async engine with SQLite-specific configuration
# SQLite doesn't support connection pooling parameters
_is_sqlite = "sqlite" in settings.DATABASE_URL.lower()

_engine_kwargs = {"echo": settings.DEBUG}
if not _is_sqlite:
    _engine_kwargs["pool_size"] = settings.DATABASE_POOL_SIZE
    _engine_kwargs["max_overflow"] = settings.DATABASE_MAX_OVERFLOW

engine = create_async_engine(
    settings.DATABASE_URL,
    **_engine_kwargs
)

# Create async session factory
async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)

# Alias for backward compatibility
async_session_maker = async_session_factory


class Base(DeclarativeBase):
    """Base class for all models with common fields"""
    
    # Common fields for all entities
    # Using String(36) for UUID compatibility across SQLite and PostgreSQL
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)
    deleted_at = Column(DateTime, nullable=True)
    
    @property
    def is_deleted(self) -> bool:
        """Check if entity is soft deleted"""
        return self.deleted_at is not None
    
    def soft_delete(self):
        """Mark entity as deleted"""
        self.deleted_at = datetime.now(timezone.utc)
    
    def restore(self):
        """Restore soft deleted entity"""
        self.deleted_at = None


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency that provides a database session.
    Commit should happen in service layer only - NOT here.
    Ensures proper cleanup after request completion.
    """
    async with async_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db():
    """
    Initialize database connections.
    
    WARNING: For production, use Alembic migrations instead of create_all.
    Tables should be created via: alembic upgrade head
    
    create_all() is only used in development/testing environments
    when DATABASE_AUTO_CREATE is enabled.
    """
    # Only auto-create tables in development/testing
    if settings.DEBUG and getattr(settings, 'DATABASE_AUTO_CREATE', False):
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)


async def close_db():
    """Close database connections"""
    await engine.dispose()


async def create_all_tables():
    """
    Create all tables - for development/testing only.
    DO NOT USE IN PRODUCTION - use Alembic migrations instead.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def drop_all_tables():
    """
    Drop all tables - for testing only.
    DO NOT USE IN PRODUCTION.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
