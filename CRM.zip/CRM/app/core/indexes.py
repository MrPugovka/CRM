"""
Database Index Definitions
All required indexes for performance optimization

Indexes on:
- foreign keys
- email
- phone
- deal_stage
- created_at
"""
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
import logging

logger = logging.getLogger(__name__)


# All indexes to create
INDEXES = [
    # ==================== Clients ====================
    "CREATE INDEX IF NOT EXISTS ix_clients_email ON clients(email)",
    "CREATE INDEX IF NOT EXISTS ix_clients_phone ON clients(phone)",
    "CREATE INDEX IF NOT EXISTS ix_clients_full_name ON clients(full_name)",
    "CREATE INDEX IF NOT EXISTS ix_clients_client_type ON clients(client_type)",
    "CREATE INDEX IF NOT EXISTS ix_clients_status ON clients(status)",
    "CREATE INDEX IF NOT EXISTS ix_clients_responsible_id ON clients(responsible_id)",
    "CREATE INDEX IF NOT EXISTS ix_clients_company_id ON clients(company_id)",
    "CREATE INDEX IF NOT EXISTS ix_clients_created_at ON clients(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_clients_deleted_at ON clients(deleted_at)",
    
    # ==================== Pipelines ====================
    "CREATE INDEX IF NOT EXISTS ix_pipelines_is_default ON pipelines(is_default)",

    # ==================== Stages ====================
    "CREATE INDEX IF NOT EXISTS ix_stages_pipeline_id ON stages(pipeline_id)",
    "CREATE INDEX IF NOT EXISTS ix_stages_order ON stages(\"order\")",

    # ==================== Deals ====================
    "CREATE INDEX IF NOT EXISTS ix_deals_pipeline_id ON deals(pipeline_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_stage_id ON deals(stage_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_company_id ON deals(company_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_contact_id ON deals(contact_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_responsible_id ON deals(responsible_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_status ON deals(status)",
    "CREATE INDEX IF NOT EXISTS ix_deals_created_at ON deals(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_deals_deleted_at ON deals(deleted_at)",

    # ==================== Deal Stage History ====================
    "CREATE INDEX IF NOT EXISTS ix_deal_stage_history_deal_id ON deal_stage_history(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_deal_stage_history_changed_at ON deal_stage_history(changed_at)",
    
    # ==================== Tasks ====================
    "CREATE INDEX IF NOT EXISTS ix_tasks_responsible_id ON tasks(responsible_id)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_deal_id ON tasks(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_client_id ON tasks(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_status ON tasks(status)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_priority ON tasks(priority)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_due_date ON tasks(due_date)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_created_at ON tasks(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_tasks_deleted_at ON tasks(deleted_at)",
    
    # ==================== Users ====================
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_users_email ON users(email)",
    "CREATE INDEX IF NOT EXISTS ix_users_phone ON users(phone)",
    "CREATE INDEX IF NOT EXISTS ix_users_status ON users(status)",
    "CREATE INDEX IF NOT EXISTS ix_users_role_id ON users(role_id)",
    "CREATE INDEX IF NOT EXISTS ix_users_team_id ON users(team_id)",
    "CREATE INDEX IF NOT EXISTS ix_users_created_at ON users(created_at)",
    
    
    # ==================== Messages ====================
    "CREATE INDEX IF NOT EXISTS ix_messages_client_id ON messages(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_messages_deal_id ON messages(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_messages_sender_id ON messages(sender_id)",
    "CREATE INDEX IF NOT EXISTS ix_messages_channel ON messages(channel)",
    "CREATE INDEX IF NOT EXISTS ix_messages_created_at ON messages(created_at)",
    
    # ==================== Emails ====================
    "CREATE INDEX IF NOT EXISTS ix_emails_account_id ON emails(account_id)",
    "CREATE INDEX IF NOT EXISTS ix_emails_client_id ON emails(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_emails_deal_id ON emails(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_emails_status ON emails(status)",
    "CREATE INDEX IF NOT EXISTS ix_emails_received_at ON emails(received_at)",
    "CREATE INDEX IF NOT EXISTS ix_emails_created_at ON emails(created_at)",
    
    # ==================== Documents ====================
    "CREATE INDEX IF NOT EXISTS ix_documents_client_id ON documents(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_documents_deal_id ON documents(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_documents_template_id ON documents(template_id)",
    "CREATE INDEX IF NOT EXISTS ix_documents_status ON documents(status)",
    "CREATE INDEX IF NOT EXISTS ix_documents_created_at ON documents(created_at)",
    
    # ==================== Files ====================
    "CREATE INDEX IF NOT EXISTS ix_files_client_id ON files(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_files_deal_id ON files(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_files_task_id ON files(task_id)",
    "CREATE INDEX IF NOT EXISTS ix_files_uploaded_by ON files(uploaded_by)",
    "CREATE INDEX IF NOT EXISTS ix_files_created_at ON files(created_at)",
    
    # ==================== Events (Calendar) ====================
    "CREATE INDEX IF NOT EXISTS ix_events_client_id ON events(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_events_deal_id ON events(deal_id)",
    "CREATE INDEX IF NOT EXISTS ix_events_organizer_id ON events(organizer_id)",
    "CREATE INDEX IF NOT EXISTS ix_events_start_at ON events(start_at)",
    "CREATE INDEX IF NOT EXISTS ix_events_end_at ON events(end_at)",
    "CREATE INDEX IF NOT EXISTS ix_events_created_at ON events(created_at)",
    
    # ==================== Audit Logs ====================
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_user_id ON audit_logs(user_id)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_entity ON audit_logs(entity_type, entity_id)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_action ON audit_logs(action)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_created_at ON audit_logs(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_ip ON audit_logs(ip_address)",
    
    # ==================== Automation Rules ====================
    "CREATE INDEX IF NOT EXISTS ix_automation_rules_event ON automation_rules(event_type, is_active)",
    "CREATE INDEX IF NOT EXISTS ix_automation_rules_pipeline ON automation_rules(pipeline_id)",
    
    # ==================== API Keys ====================
    "CREATE INDEX IF NOT EXISTS ix_api_keys_prefix ON api_keys(key_prefix)",
    "CREATE INDEX IF NOT EXISTS ix_api_keys_user ON api_keys(user_id)",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_api_keys_hash ON api_keys(key_hash)",
    
    # ==================== Webhooks ====================
    "CREATE INDEX IF NOT EXISTS ix_webhooks_user ON webhooks(user_id)",
    "CREATE INDEX IF NOT EXISTS ix_webhooks_status ON webhooks(status, is_active)",
    
    # ==================== Login Attempts ====================
    "CREATE INDEX IF NOT EXISTS ix_login_attempts_email ON login_attempts(email)",
    "CREATE INDEX IF NOT EXISTS ix_login_attempts_ip ON login_attempts(ip_address)",
    "CREATE INDEX IF NOT EXISTS ix_login_attempts_at ON login_attempts(attempted_at)",
]


async def create_all_indexes(session: AsyncSession):
    """
    Create all database indexes
    
    Called during application startup.
    """
    created = 0
    errors = 0
    
    for index_sql in INDEXES:
        try:
            await session.execute(text(index_sql))
            created += 1
        except Exception as e:
            # Index might already exist or table might not exist yet
            errors += 1
            logger.debug(f"Index creation skipped: {e}")
    
    await session.commit()
    
    logger.info(f"Database indexes: {created} created, {errors} skipped")
    
    return {"created": created, "errors": errors}


async def drop_all_indexes(session: AsyncSession):
    """Drop all custom indexes (for testing)"""
    for index_sql in INDEXES:
        # Extract index name from CREATE INDEX statement
        import re
        match = re.search(r'INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)', index_sql)
        if match:
            index_name = match.group(1)
            try:
                await session.execute(text(f"DROP INDEX IF EXISTS {index_name}"))
            except Exception:
                pass
    
    await session.commit()
