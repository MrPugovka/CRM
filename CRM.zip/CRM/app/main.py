"""
CRM Modular Monolith Application
Main FastAPI application with OpenAPI documentation
"""
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from typing import Optional
from urllib.parse import urlparse

from fastapi import FastAPI, Request, Form, Depends, status, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from slowapi.errors import RateLimitExceeded
from sqlalchemy import select
from starlette.middleware.sessions import SessionMiddleware
import structlog
import os

from app.core.config import settings
from app.core.database import init_db, close_db, async_session_maker as async_session
from app.core.rate_limiter import limiter, rate_limit_handler, RateLimits
from app.core.middleware import (
    CorrelationIdMiddleware,
    ExceptionHandlerMiddleware,
    RequestLoggingMiddleware,
    SecurityHeadersMiddleware,
    CharsetMiddleware,
    AuditLoggingMiddleware,
)
from app.core.security import require_auth_cookie
from app.core.cookies import set_auth_cookie, set_refresh_cookie, clear_auth_cookies
from app.modules.auth.services import AuthService
from app.modules.users.models import User

# Import API routers
from app.modules.users.controller import router as users_router
from app.modules.auth.controller import router as auth_router
from app.routes.health import router as health_router


# Configure structured logging with correlation ID support
structlog.configure(
    processors=[
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer() if not settings.DEBUG else structlog.dev.ConsoleRenderer()
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()


# Templates configuration for main app routes
templates = Jinja2Templates(directory="templates")

# Add custom Jinja2 filters
from datetime import datetime

def format_currency(value):
    """Format number as currency"""
    if value is None:
        return "0 ₽"
    try:
        value = float(value)
        return f"{value:,.0f} ₽".replace(",", " ")
    except (ValueError, TypeError):
        return "0 ₽"

def format_datetime(value):
    """Format datetime"""
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except:
            return value
    if isinstance(value, datetime):
        return value.strftime("%d.%m.%Y %H:%M")
    return str(value)

def format_date(value):
    """Format date"""
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except:
            return value
    if isinstance(value, datetime):
        return value.strftime("%d.%m.%Y")
    return str(value)

templates.env.filters['currency'] = format_currency
templates.env.filters['datetime'] = format_datetime
templates.env.filters['date'] = format_date


def is_safe_url(url: Optional[str]) -> bool:
    """
    Проверяет, что URL безопасен для редиректа.
    Разрешает только относительные пути (начинающиеся с /).
    Запрещает абсолютные URL и протоколы (http://, https://, //).
    """
    if not url:
        return False
    
    # Проверяем на null bytes
    if '\x00' in url:
        return False
    
    # Проверяем на протоколы и scheme-relative URLs
    url_lower = url.lower().strip()
    dangerous_prefixes = ('http://', 'https://', '//', 'javascript:', 'data:', 'vbscript:', 'file:')
    if any(url_lower.startswith(prefix) for prefix in dangerous_prefixes):
        return False
    
    # Парсим URL и проверяем, что нет netloc (хоста)
    try:
        parsed = urlparse(url)
        # Безопасный URL: путь начинается с / и нет netloc
        if parsed.netloc:
            return False
        if not parsed.path.startswith('/'):
            return False
        return True
    except Exception:
        return False


def get_safe_redirect_url(url: Optional[str], default: str = "/dashboard") -> str:
    """Возвращает безопасный URL для редиректа."""
    if url and is_safe_url(url):
        return url
    return default


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.
    Handles startup and shutdown events.
    """
    # Startup
    logger.info("Starting CRM application", version=settings.APP_VERSION)
    await init_db()
    logger.info("Database initialized")
    
    yield
    
    # Shutdown
    logger.info("Shutting down CRM application")
    await close_db()
    logger.info("Database connections closed")


# Create FastAPI application
app = FastAPI(
    title=settings.APP_NAME,
    description="""
# CRM System API

A comprehensive CRM (Customer Relationship Management) system with modular architecture.

## Features

- **Users & Roles**: Full RBAC (Role Based Access Control) with entity-level and field-level permissions

## Authentication

This API uses JWT (JSON Web Token) authentication with refresh tokens.

1. Obtain tokens via `/api/v1/auth/login`
2. Use the `access_token` in the `Authorization: Bearer <token>` header
3. Refresh tokens via `/api/v1/auth/refresh`

## Authorization

API endpoints are protected by permissions. Each permission follows the format `entity.action`:
- `users.read` - View users
- `users.write` - Create/edit users
- `users.manage_roles` - Manage user roles

## Pagination

List endpoints support pagination with the following query parameters:
- `page` - Page number (default: 1)
- `page_size` - Items per page (default: 20, max: 100)

Response includes pagination metadata:
- `total` - Total number of items
- `page` - Current page
- `page_size` - Items per page
- `pages` - Total number of pages

## Rate Limiting

API endpoints have rate limits to prevent abuse:
- Authentication: 5 requests per minute
- Resource creation: 10 requests per minute
- List operations: 60 requests per minute
    """,
    version=settings.APP_VERSION,
    docs_url=None,
    redoc_url=None,
    openapi_url="/api/openapi.json",
    lifespan=lifespan
)

# Add rate limiter to app
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, rate_limit_handler)

# Add SessionMiddleware (must be early for request.session access)
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.SECRET_KEY or settings.JWT_SECRET,
    max_age=86400,  # 24 hours
    same_site="strict",
    https_only=not settings.DEBUG,
)

# Add custom middleware (order matters!)
app.add_middleware(CorrelationIdMiddleware)
app.add_middleware(ExceptionHandlerMiddleware)
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(AuditLoggingMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(CharsetMiddleware)


# Parse CORS origins from comma-separated string
def parse_cors_origins(origins_str: str) -> list:
    """Parse comma-separated CORS origins into list"""
    return [origin.strip() for origin in origins_str.split(",") if origin.strip()]

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=parse_cors_origins(settings.CORS_ORIGINS),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=[
        "Authorization",
        "Content-Type",
        "X-CSRF-Token",
        "X-Requested-With",
        "Accept",
        "Origin",
        "X-Correlation-ID",
    ],
    expose_headers=["X-Correlation-ID"],
    max_age=600,
)


# Exception handlers
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler"""
    logger.error(
        "Unhandled exception",
        error=str(exc),
        path=request.url.path,
        method=request.method
    )
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "error": str(exc) if settings.DEBUG else "An unexpected error occurred"
        }
    )


# Custom OpenAPI documentation endpoints - now require authentication
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui(request: Request):
    """Custom Swagger UI documentation - requires authentication"""
    # Check if user is authenticated
    auth_token = request.cookies.get("access_token")
    if auth_token:
        from app.core.security import decode_token
        payload = decode_token(auth_token)
        if payload and payload.get("type") == "access":
            return get_swagger_ui_html(
                openapi_url="/api/openapi.json",
                title=f"{settings.APP_NAME} - API Documentation",
                swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
                swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
            )
    # Redirect to login if not authenticated
    return RedirectResponse(url="/login?next=/docs", status_code=302)


@app.get("/redoc", include_in_schema=False)
async def custom_redoc(request: Request):
    """Custom ReDoc documentation - requires authentication"""
    # Check if user is authenticated
    auth_token = request.cookies.get("access_token")
    if auth_token:
        from app.core.security import decode_token
        payload = decode_token(auth_token)
        if payload and payload.get("type") == "access":
            return get_redoc_html(
                openapi_url="/api/openapi.json",
                title=f"{settings.APP_NAME} - API Documentation",
                redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@latest/bundles/redoc.standalone.js",
            )
    # Redirect to login if not authenticated
    return RedirectResponse(url="/login?next=/redoc", status_code=302)


# Health check endpoints
@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint"""
    from app.core.database import async_session
    from sqlalchemy import text
    
    health_status = {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "services": {}
    }
    
    # Check Database
    try:
        async with async_session() as session:
            await session.execute(text("SELECT 1"))
            health_status["services"]["database"] = {"status": "connected", "type": "postgresql"}
    except Exception as e:
        health_status["services"]["database"] = {"status": "disconnected", "error": str(e)}
        health_status["status"] = "degraded"
    
    return JSONResponse(
        content=health_status,
        status_code=200 if health_status["status"] == "healthy" else 503
    )


@app.get("/health/live", tags=["Health"])
async def liveness_probe():
    """Kubernetes liveness probe"""
    return {"status": "alive"}


@app.get("/health/ready", tags=["Health"])
async def readiness_probe():
    """Kubernetes readiness probe"""
    from app.core.database import async_session
    from sqlalchemy import text
    
    try:
        async with async_session() as session:
            await session.execute(text("SELECT 1"))
        return {"status": "ready"}
    except Exception as e:
        return JSONResponse(
            content={"status": "not_ready", "error": str(e)},
            status_code=503
        )


@app.get("/api", tags=["API Info"])
async def api_info():
    """API information endpoint"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "documentation": {
            "swagger": "/docs",
            "redoc": "/redoc",
            "openapi": "/api/openapi.json"
        }
    }


# ==================== HTML ROUTES ====================

# Login routes for web interface
@app.get("/login", response_class=HTMLResponse, include_in_schema=False)
async def login_page(request: Request, next: Optional[str] = None, error: Optional[str] = None, message: Optional[str] = None):
    """Login page for web interface"""
    # If already logged in, redirect to dashboard
    auth_token = request.cookies.get("access_token")
    if auth_token:
        from app.core.security import decode_token
        payload = decode_token(auth_token)
        if payload and payload.get("type") == "access":
            safe_next = get_safe_redirect_url(next, "/dashboard")
            return RedirectResponse(url=safe_next, status_code=302)
    
    return templates.TemplateResponse("login.html", {
        "request": request,
        "next": next or "/dashboard",
        "error": error,
        "message": message
    })


@app.post("/login", include_in_schema=False)
async def login_post(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    next: str = Form("/dashboard")
):
    """Process login form submission"""
    async with async_session() as session:
        # Use UserService directly since AuthService.authenticate returns TokenResponse
        from app.modules.users.services import UserService
        user_service = UserService(session)
        
        try:
            result = await user_service.authenticate(email=username, password=password)
        except ValueError as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"[LOGIN ERROR] ValueError during auth: {e}")
            return templates.TemplateResponse("login.html", {
                "request": request,
                "error": "Invalid email or password",
                "next": next
            }, status_code=401)
        except Exception as e:
            import logging
            import traceback
            logger = logging.getLogger(__name__)
            logger.error(f"[LOGIN ERROR] Unexpected error during auth: {type(e).__name__}: {e}")
            logger.error(f"[LOGIN ERROR] Traceback: {traceback.format_exc()}")
            return templates.TemplateResponse("login.html", {
                "request": request,
                "error": f"An error occurred during login: {type(e).__name__}: {str(e)[:100]}",
                "next": next
            }, status_code=500)
        
        # result is a TokenResponse with user and tokens already generated
        user = result.user
        
        if not user.is_active:
            return templates.TemplateResponse("login.html", {
                "request": request,
                "error": "User account is disabled",
                "next": next
            }, status_code=403)
        
        # Use tokens already generated by authenticate
        access_token = result.access_token
        refresh_token = result.refresh_token
        
        # Set cookies with safe URL validation
        safe_next = get_safe_redirect_url(next, "/dashboard")
        response = RedirectResponse(url=safe_next, status_code=302)
        set_auth_cookie(response, access_token)
        set_refresh_cookie(response, refresh_token)
        
        return response


@app.get("/logout", include_in_schema=False)
async def logout():
    """Logout and clear cookies"""
    response = RedirectResponse(url="/login", status_code=302)
    clear_auth_cookies(response)
    return response


@app.get("/forgot-password", response_class=HTMLResponse, include_in_schema=False)
async def forgot_password_page(request: Request, error: Optional[str] = None, message: Optional[str] = None, new_password: Optional[str] = None):
    """Forgot password page"""
    return templates.TemplateResponse("forgot_password.html", {
        "request": request,
        "error": error,
        "message": message,
        "new_password": new_password
    })


# Import Redis client for secure token storage and rate limiting
from app.core.redis_client import (
    store_reset_token,
    validate_reset_token,
    mark_token_used,
    check_rate_limit,
    TOKEN_EXPIRY_SECONDS
)


def _generate_reset_token(user_id: int) -> str:
    """Генерирует криптографически стойкий токен для сброса пароля."""
    import secrets
    token = secrets.token_urlsafe(32)
    
    # Store token in Redis with hash
    store_reset_token(token, user_id)
    
    return token


def _check_rate_limit_ip_email(client_ip: str, email: str) -> bool:
    """Проверяет rate limit для сброса пароля. Возвращает True если лимит не превышен."""
    return check_rate_limit(email, client_ip)


@app.post("/forgot-password", include_in_schema=False)
async def forgot_password_post(
    request: Request,
    email: str = Form(...)
):
    """
    Process password reset request with rate limiting and secure tokens.
    Вместо показа пароля - создаёт одноразовый токен с ограниченным сроком жизни.
    """
    from app.modules.users.models import User
    from sqlalchemy import select
    
    # Rate limiting по IP + email
    client_ip = request.client.host if request.client else "unknown"
    if not _check_rate_limit_ip_email(client_ip, email.lower()):
        return templates.TemplateResponse("forgot_password.html", {
            "request": request,
            "error": "Too many password reset attempts. Please try again in 1 hour."
        }, status_code=429)
    
    async with async_session() as session:
        # Find user by email (всегда одинаковый ответ для безопасности)
        result = await session.execute(
            select(User).where(User.email == email.lower(), User.deleted_at.is_(None))
        )
        user = result.scalar_one_or_none()
        
        if not user:
            # Не раскрываем, существует ли пользователь (security best practice)
            return templates.TemplateResponse("forgot_password.html", {
                "request": request,
                "message": "If an account with that email exists, password reset instructions have been sent."
            })
        
        # Генерируем токен для сброса пароля
        token = _generate_reset_token(user.id)
        
        # В реальном приложении здесь отправка email
        # Для демонстрации показываем токен в интерфейсе ТОЛЬКО в DEBUG режиме!
        # В production: отправлять email с ссылкой /reset-password?token=...
        from app.core.config import settings
        
        # Only expose token in URL for DEBUG mode
        if settings.DEBUG:
            reset_url = f"/reset-password?token={token}"
        else:
            # In production, don't expose the token in the HTML
            reset_url = None
        
        logger.info(
            "Password reset requested",
            user_id=user.id,
            email=email.lower(),
            client_ip=client_ip
        )
        
        return templates.TemplateResponse("forgot_password.html", {
            "request": request,
            "message": "Password reset has been initiated. Please check your email or use the link below to set a new password.",
            "reset_url": reset_url,
            "token": token if settings.DEBUG else None,  # Only expose token in DEBUG
            "token_expiry": f"{TOKEN_EXPIRY_SECONDS // 60} minutes",
            "debug": settings.DEBUG  # Pass debug flag to template
        })


@app.get("/reset-password", response_class=HTMLResponse, include_in_schema=False)
async def reset_password_page(
    request: Request,
    token: Optional[str] = None,
    error: Optional[str] = None,
    message: Optional[str] = None
):
    """Page for entering new password using reset token."""
    # Валидируем токен
    user_id = validate_reset_token(token) if token else None
    
    if not token or not user_id:
        return templates.TemplateResponse("forgot_password.html", {
            "request": request,
            "error": "Invalid or expired password reset token. Please request a new one."
        }, status_code=400)
    
    return templates.TemplateResponse("reset_password.html", {
        "request": request,
        "token": token,
        "error": error,
        "message": message
    })


@app.post("/reset-password", include_in_schema=False)
async def reset_password_post(
    request: Request,
    token: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...)
):
    """Process password reset with new password."""
    from app.core.security import hash_password
    from app.modules.users.models import User
    from sqlalchemy import select
    
    # Валидируем токен
    user_id = validate_reset_token(token)
    if not user_id:
        return templates.TemplateResponse("forgot_password.html", {
            "request": request,
            "error": "Invalid or expired password reset token. Please request a new one."
        }, status_code=400)
    
    # Проверяем совпадение паролей
    if new_password != confirm_password:
        return templates.TemplateResponse("reset_password.html", {
            "request": request,
            "token": token,
            "error": "Passwords do not match."
        }, status_code=400)
    
    # Проверяем длину пароля
    if len(new_password) < 8:
        return templates.TemplateResponse("reset_password.html", {
            "request": request,
            "token": token,
            "error": "Password must be at least 8 characters long."
        }, status_code=400)
    
    async with async_session() as session:
        # Находим пользователя
        result = await session.execute(
            select(User).where(User.id == user_id)
        )
        user = result.scalar_one_or_none()
        
        if not user:
            return templates.TemplateResponse("forgot_password.html", {
                "request": request,
                "error": "User not found."
            }, status_code=404)
        
        # Обновляем пароль
        user.password_hash = hash_password(new_password)
        await session.commit()
        
        # Помечаем токен как использованный
        mark_token_used(token)
        
        logger.info(
            "Password reset successful",
            user_id=user.id,
            email=user.email
        )
        
        return templates.TemplateResponse("reset_password.html", {
            "request": request,
            "message": "Password has been reset successfully. You can now log in with your new password.",
            "success": True
        })


# Dashboard route
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root(request: Request):
    """Root endpoint redirects to dashboard if authenticated, otherwise to login"""
    auth_token = request.cookies.get("access_token")
    if auth_token:
        from app.core.security import decode_token
        payload = decode_token(auth_token)
        if payload and payload.get("type") == "access":
            return RedirectResponse(url="/dashboard", status_code=302)
    return RedirectResponse(url="/login", status_code=302)


@app.get("/dashboard", response_class=HTMLResponse, include_in_schema=False)
async def dashboard(request: Request, current_user: User = Depends(require_auth_cookie)):
    """Dashboard page - simplified"""
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    
    # Generate CSRF token for the dashboard
    from app.core.csrf import csrf_protection
    session_id = request.cookies.get("session_id")
    if not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    csrf_token = csrf_protection.generate_token(session_id)
    
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": current_user,
        "csrf_token": csrf_token,
        "stats": {
            "total_clients": 0,
            "total_deals": 0,
            "total_amount": 0,
            "overdue_tasks": 0
        },
        "pipelines": [],
        "deals_by_stage": {},
        "upcoming_tasks": [],
        "activities": [],
        "recent_comms": [],
        "now": now
    })


# Mount static files
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")


# Include health check router (no auth required)
app.include_router(health_router)

# Include API routers (JSON API)
app.include_router(auth_router, prefix="/api/v1")
app.include_router(users_router, prefix="/api/v1")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )
