# CRM Modular Monolith Application
