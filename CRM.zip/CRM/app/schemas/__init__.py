# Pydantic schemas for validation
# TODO: Create schema files when clients, deals, tasks modules are implemented
# from .clients import CreateClientSchema, UpdateClientSchema
# from .deals import CreateDealSchema, UpdateDealSchema
# from .tasks import CreateTaskSchema, UpdateTaskSchema

__all__ = [
    # "CreateClientSchema",
    # "UpdateClientSchema",
    # "CreateDealSchema",
    # "UpdateDealSchema",
    # "CreateTaskSchema",
    # "UpdateTaskSchema",
]