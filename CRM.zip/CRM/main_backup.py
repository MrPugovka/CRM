# main.py - Full CRM Application
from fastapi import FastAPI, Request, Form, HTTPException, status, Query, UploadFile, File as FastAPIFile
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select, func, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, joinedload
from datetime import datetime, date, timedelta
from decimal import Decimal
import json
import os
import uuid
from typing import Optional, List

from models import (
    Base, engine, async_session, init_db, seed_default_data,
    User, Team, Role,
    Client, ClientType, ClientStatus,
    Pipeline, PipelineStage, Deal, DealHistory, DealContact,
    Task, TaskType, TaskPriority,
    Communication, MessageTemplate, EmailAccount,
    Document, DocumentTemplate,
    File,
    CalendarEvent,
    Dashboard, Report, KPI,
    Activity,
    Integration, Webhook,
    CustomField, Setting,
    Notification,
    Automation, AutomationLog,
    SLARule, SLATracking,
    EmailCampaign, EmailCampaignRecipient, EmailTrackingEvent,
    TaskKPI,
    Office, LegalEntity, BusinessProcess, BusinessProcessInstance
)

app = FastAPI(title="CRM System")
templates = Jinja2Templates(directory="templates")

# Create uploads directory if not exists
os.makedirs("uploads", exist_ok=True)

# Mount static files
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


# ==================== STARTUP ====================

@app.on_event("startup")
async def startup():
    await init_db()
    await seed_default_data()


# ==================== CONTEXT PROCESSORS ====================

def get_nav_counts():
    """Get counts for navigation badges"""
    return {}  # Will be populated per request


# ==================== HELPERS ====================

def format_currency(amount, currency="RUB"):
    """Format currency for display"""
    if amount is None:
        return "0 ₽"
    symbols = {"RUB": "₽", "USD": "$", "EUR": "€"}
    return f"{float(amount):,.0f} {symbols.get(currency, currency)}"


def format_date(dt):
    """Format date for display"""
    if not dt:
        return ""
    if isinstance(dt, str):
        return dt
    return dt.strftime("%d.%m.%Y")


def format_datetime(dt):
    """Format datetime for display"""
    if not dt:
        return ""
    if isinstance(dt, str):
        return dt
    return dt.strftime("%d.%m.%Y %H:%M")


templates.env.filters["currency"] = format_currency
templates.env.filters["date"] = format_date
templates.env.filters["datetime"] = format_datetime

# Add globals for templates (use py_date to avoid conflict with date filter)
templates.env.globals["py_date"] = date
templates.env.globals["py_datetime"] = datetime
templates.env.globals["timedelta"] = timedelta


async def log_activity(session, user_id, entity_type, entity_id, action, description, old_values=None, new_values=None):
    """Log activity"""
    activity = Activity(
        user_id=user_id,
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        description=description,
        old_values=old_values,
        new_values=new_values
    )
    session.add(activity)


# ==================== DASHBOARD ====================

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    async with async_session() as session:
        # Get stats
        total_clients = await session.scalar(select(func.count(Client.id)))
        total_deals = await session.scalar(select(func.count(Deal.id)).where(Deal.status == "open"))
        total_amount = await session.scalar(
            select(func.coalesce(func.sum(Deal.amount), 0)).where(Deal.status == "open")
        )
        overdue_tasks = await session.scalar(
            select(func.count(Task.id)).where(
                Task.status != "completed",
                Task.due_date < datetime.now()
            )
        )
        
        # Get recent activities
        activities = (await session.execute(
            select(Activity).order_by(Activity.created_at.desc()).limit(10)
        )).scalars().all()
        
        # Get pipeline stats
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
        
        # Get deals by stage for kanban
        deals_by_stage = {}
        for pipeline in pipelines:
            for stage in pipeline.stages:
                deals = (await session.execute(
                    select(Deal).options(selectinload(Deal.client))
                    .where(Deal.stage_id == stage.id, Deal.status == "open")
                    .order_by(Deal.created_at.desc()).limit(10)
                )).scalars().all()
                deals_by_stage[stage.id] = deals
        
        # Get upcoming tasks
        upcoming_tasks = (await session.execute(
            select(Task).options(selectinload(Task.client), selectinload(Task.deal))
            .where(Task.status != "completed")
            .order_by(Task.due_date).limit(10)
        )).scalars().all()
        
        # Get recent communications
        recent_comms = (await session.execute(
            select(Communication).options(selectinload(Communication.client))
            .order_by(Communication.created_at.desc()).limit(10)
        )).scalars().all()
    
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "stats": {
            "total_clients": total_clients or 0,
            "total_deals": total_deals or 0,
            "total_amount": total_amount or 0,
            "overdue_tasks": overdue_tasks or 0
        },
        "activities": activities,
        "pipelines": pipelines,
        "deals_by_stage": deals_by_stage,
        "upcoming_tasks": upcoming_tasks,
        "recent_comms": recent_comms
    })


# ==================== CLIENTS ====================

@app.get("/clients", response_class=HTMLResponse)
async def clients_list(
    request: Request,
    client_type: str = Query(None),
    status: str = Query(None),
    search: str = Query(None),
    tag: str = Query(None)
):
    async with async_session() as session:
        query = select(Client).options(selectinload(Client.deals))
        
        if client_type:
            query = query.where(Client.client_type == client_type)
        if status:
            query = query.where(Client.status == status)
        if search:
            query = query.where(
                or_(
                    Client.full_name.ilike(f"%{search}%"),
                    Client.company_name.ilike(f"%{search}%"),
                    Client.phone.ilike(f"%{search}%"),
                    Client.email.ilike(f"%{search}%")
                )
            )
        if tag:
            query = query.where(Client.tags.ilike(f"%{tag}%"))
        
        query = query.order_by(Client.created_at.desc())
        clients = (await session.execute(query)).scalars().all()
        
        # Get all unique tags
        all_tags = []
        for client in clients:
            if client.tags:
                all_tags.extend([t.strip() for t in client.tags.split(",")])
        all_tags = list(set(all_tags))
    
    return templates.TemplateResponse("clients/list.html", {
        "request": request,
        "clients": clients,
        "filters": {"client_type": client_type, "status": status, "search": search, "tag": tag},
        "all_tags": all_tags
    })


@app.get("/clients/new", response_class=HTMLResponse)
async def new_client_form(request: Request, client_type: str = "lead"):
    return templates.TemplateResponse("clients/form.html", {
        "request": request,
        "client": None,
        "client_type": client_type
    })


@app.get("/clients/segments", response_class=HTMLResponse)
async def client_segments_page(request: Request):
    """Client segmentation page"""
    async with async_session() as session:
        # Get all unique tags
        clients = (await session.execute(select(Client))).scalars().all()
        
        tags_count = {}
        for client in clients:
            if client.tags:
                for tag in client.tags.split(","):
                    tag = tag.strip()
                    if tag:
                        tags_count[tag] = tags_count.get(tag, 0) + 1
        
        # Get status distribution
        status_counts = {}
        for client in clients:
            status_counts[client.status] = status_counts.get(client.status, 0) + 1
        
        # Get type distribution
        type_counts = {}
        for client in clients:
            type_counts[client.client_type] = type_counts.get(client.client_type, 0) + 1
        
        # Get source distribution
        source_counts = {}
        for client in clients:
            if client.source:
                source_counts[client.source] = source_counts.get(client.source, 0) + 1
    
    return templates.TemplateResponse("clients/segments.html", {
        "request": request,
        "tags_count": tags_count,
        "status_counts": status_counts,
        "type_counts": type_counts,
        "source_counts": source_counts
    })


@app.get("/clients/duplicates", response_class=HTMLResponse)
async def find_duplicates_page(request: Request):
    """Page for finding and managing duplicate clients"""
    async with async_session() as session:
        # Find potential duplicates by email
        email_duplicates = (await session.execute(
            select(Client.email, func.count(Client.id).label('count'))
            .where(Client.email != None, Client.email != '')
            .group_by(Client.email)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by phone
        phone_duplicates = (await session.execute(
            select(Client.phone, func.count(Client.id).label('count'))
            .where(Client.phone != None, Client.phone != '')
            .group_by(Client.phone)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by name
        name_duplicates = (await session.execute(
            select(Client.full_name, func.count(Client.id).label('count'))
            .where(Client.full_name != None, Client.full_name != '')
            .group_by(Client.full_name)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Get duplicate groups with details
        duplicate_groups = []
        
        for email, count in email_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.email == email)
            )).scalars().all()
            duplicate_groups.append({
                "type": "email",
                "value": email,
                "count": count,
                "clients": clients
            })
        
        for phone, count in phone_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.phone == phone)
            )).scalars().all()
            duplicate_groups.append({
                "type": "phone",
                "value": phone,
                "count": count,
                "clients": clients
            })
        
        for name, count in name_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.full_name == name)
            )).scalars().all()
            # Only add if not already in email/phone duplicates
            client_ids = [c.id for c in clients]
            if not any(c.id in client_ids for group in duplicate_groups for c in group['clients']):
                duplicate_groups.append({
                    "type": "name",
                    "value": name,
                    "count": count,
                    "clients": clients
                })
    
    return templates.TemplateResponse("clients/duplicates.html", {
        "request": request,
        "duplicate_groups": duplicate_groups
    })


@app.get("/clients/new", response_class=HTMLResponse)
async def new_client_form(request: Request, client_type: str = "lead"):
    return templates.TemplateResponse("clients/form.html", {
        "request": request,
        "client": None,
        "client_type": client_type
    })


@app.post("/clients", response_class=HTMLResponse)
async def create_client(
    request: Request,
    full_name: str = Form(...),
    client_type: str = Form("lead"),
    company_name: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    website: str = Form(None),
    address: str = Form(None),
    city: str = Form(None),
    country: str = Form(None),
    source: str = Form(None),
    source_detail: str = Form(None),
    comment: str = Form(None),
    tags: str = Form(None),
    inn: str = Form(None),
    company_id: str = Form(None)
):
    async with async_session() as session:
        client = Client(
            full_name=full_name,
            client_type=client_type,
            company_name=company_name,
            phone=phone,
            email=email,
            website=website,
            address=address,
            city=city,
            country=country,
            source=source,
            source_detail=source_detail,
            comment=comment,
            tags=tags,
            inn=inn,
            company_id=int(company_id) if company_id else None,
            status="new"
        )
        session.add(client)
        await session.commit()
        await session.refresh(client)
        
        await log_activity(session, 1, "client", client.id, "created", f"Создан клиент: {full_name}")
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{client.id}", status_code=303)


@app.get("/clients/segments", response_class=HTMLResponse)
async def client_segments_page(request: Request):
    """Client segmentation page"""
    async with async_session() as session:
        # Get all unique tags
        clients = (await session.execute(select(Client))).scalars().all()
        
        tags_count = {}
        for client in clients:
            if client.tags:
                for tag in client.tags.split(","):
                    tag = tag.strip()
                    if tag:
                        tags_count[tag] = tags_count.get(tag, 0) + 1
        
        # Get status distribution
        status_counts = {}
        for client in clients:
            status_counts[client.status] = status_counts.get(client.status, 0) + 1
        
        # Get type distribution
        type_counts = {}
        for client in clients:
            type_counts[client.client_type] = type_counts.get(client.client_type, 0) + 1
        
        # Get source distribution
        source_counts = {}
        for client in clients:
            if client.source:
                source_counts[client.source] = source_counts.get(client.source, 0) + 1
    
    return templates.TemplateResponse("clients/segments.html", {
        "request": request,
        "tags_count": tags_count,
        "status_counts": status_counts,
        "type_counts": type_counts,
        "source_counts": source_counts
    })


@app.get("/clients/duplicates", response_class=HTMLResponse)
async def find_duplicates_page(request: Request):
    """Page for finding and managing duplicate clients"""
    async with async_session() as session:
        # Find potential duplicates by email
        email_duplicates = (await session.execute(
            select(Client.email, func.count(Client.id).label('count'))
            .where(Client.email != None, Client.email != "")
            .group_by(Client.email)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by phone
        phone_duplicates = (await session.execute(
            select(Client.phone, func.count(Client.id).label('count'))
            .where(Client.phone != None, Client.phone != "")
            .group_by(Client.phone)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by name
        name_duplicates = (await session.execute(
            select(Client.full_name, func.count(Client.id).label('count'))
            .where(Client.full_name != None, Client.full_name != "")
            .group_by(Client.full_name)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Get duplicate groups with details
        duplicate_groups = []
        
        for email, count in email_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.email == email)
            )).scalars().all()
            duplicate_groups.append({
                "type": "email",
                "value": email,
                "count": count,
                "clients": clients
            })
        
        for phone, count in phone_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.phone == phone)
            )).scalars().all()
            duplicate_groups.append({
                "type": "phone",
                "value": phone,
                "count": count,
                "clients": clients
            })
        
        for name, count in name_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.full_name == name)
            )).scalars().all()
            # Only add if not already in email/phone duplicates
            client_ids = [c.id for c in clients]
            if not any(c.id in client_ids for group in duplicate_groups for c in group['clients']):
                duplicate_groups.append({
                    "type": "name",
                    "value": name,
                    "count": count,
                    "clients": clients
                })
    
    return templates.TemplateResponse("clients/duplicates.html", {
        "request": request,
        "duplicate_groups": duplicate_groups
    })


@app.post("/clients", response_class=HTMLResponse)
async def create_client(
    request: Request,
    full_name: str = Form(...),
    client_type: str = Form("lead"),
    company_name: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    website: str = Form(None),
    address: str = Form(None),
    city: str = Form(None),
    country: str = Form(None),
    source: str = Form(None),
    source_detail: str = Form(None),
    comment: str = Form(None),
    tags: str = Form(None),
    inn: str = Form(None),
    company_id: str = Form(None)
):
    async with async_session() as session:
        client = Client(
            full_name=full_name,
            client_type=client_type,
            company_name=company_name,
            phone=phone,
            email=email,
            website=website,
            address=address,
            city=city,
            country=country,
            source=source,
            source_detail=source_detail,
            comment=comment,
            tags=tags,
            inn=inn,
            company_id=int(company_id) if company_id else None,
            status="new"
        )
        session.add(client)
        await session.commit()
        await session.refresh(client)
        
        await log_activity(session, 1, "client", client.id, "created", f"Создан клиент: {full_name}")
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{client.id}", status_code=303)


@app.get("/clients/segments", response_class=HTMLResponse)
async def client_segments_page(request: Request):
    """Client segmentation page"""
    async with async_session() as session:
        # Get all unique tags
        clients = (await session.execute(select(Client))).scalars().all()
        
        tags_count = {}
        for client in clients:
            if client.tags:
                for tag in client.tags.split(","):
                    tag = tag.strip()
                    if tag:
                        tags_count[tag] = tags_count.get(tag, 0) + 1
        
        # Get status distribution
        status_counts = {}
        for client in clients:
            status_counts[client.status] = status_counts.get(client.status, 0) + 1
        
        # Get type distribution
        type_counts = {}
        for client in clients:
            type_counts[client.client_type] = type_counts.get(client.client_type, 0) + 1
        
        # Get source distribution
        source_counts = {}
        for client in clients:
            if client.source:
                source_counts[client.source] = source_counts.get(client.source, 0) + 1
    
    return templates.TemplateResponse("clients/segments.html", {
        "request": request,
        "tags_count": tags_count,
        "status_counts": status_counts,
        "type_counts": type_counts,
        "source_counts": source_counts
    })


@app.get("/clients/duplicates", response_class=HTMLResponse)
async def find_duplicates_page(request: Request):
    """Page for finding and managing duplicate clients"""
    async with async_session() as session:
        # Find potential duplicates by email
        email_duplicates = (await session.execute(
            select(Client.email, func.count(Client.id).label('count'))
            .where(Client.email != None, Client.email != "")
            .group_by(Client.email)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by phone
        phone_duplicates = (await session.execute(
            select(Client.phone, func.count(Client.id).label('count'))
            .where(Client.phone != None, Client.phone != "")
            .group_by(Client.phone)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by name
        name_duplicates = (await session.execute(
            select(Client.full_name, func.count(Client.id).label('count'))
            .where(Client.full_name != None, Client.full_name != "")
            .group_by(Client.full_name)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Get duplicate groups with details
        duplicate_groups = []
        
        for email, count in email_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.email == email)
            )).scalars().all()
            duplicate_groups.append({
                "type": "email",
                "value": email,
                "count": count,
                "clients": clients
            })
        
        for phone, count in phone_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.phone == phone)
            )).scalars().all()
            duplicate_groups.append({
                "type": "phone",
                "value": phone,
                "count": count,
                "clients": clients
            })
        
        for name, count in name_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.full_name == name)
            )).scalars().all()
            # Only add if not already in email/phone duplicates
            client_ids = [c.id for c in clients]
            if not any(c.id in client_ids for group in duplicate_groups for c in group['clients']):
                duplicate_groups.append({
                    "type": "name",
                    "value": name,
                    "count": count,
                    "clients": clients
                })
    
    return templates.TemplateResponse("clients/duplicates.html", {
        "request": request,
        "duplicate_groups": duplicate_groups
    })


@app.post("/clients", response_class=HTMLResponse)
async def create_client(
    request: Request,
    full_name: str = Form(...),
    client_type: str = Form("lead"),
    company_name: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    website: str = Form(None),
    address: str = Form(None),
    city: str = Form(None),
    country: str = Form(None),
    source: str = Form(None),
    source_detail: str = Form(None),
    comment: str = Form(None),
    tags: str = Form(None),
    inn: str = Form(None),
    company_id: str = Form(None)
):
    async with async_session() as session:
        client = Client(
            full_name=full_name,
            client_type=client_type,
            company_name=company_name,
            phone=phone,
            email=email,
            website=website,
            address=address,
            city=city,
            country=country,
            source=source,
            source_detail=source_detail,
            comment=comment,
            tags=tags,
            inn=inn,
            company_id=int(company_id) if company_id else None,
            status="new"
        )
        session.add(client)
        await session.commit()
        await session.refresh(client)
        
        await log_activity(session, 1, "client", client.id, "created", f"Создан клиент: {full_name}")
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{client.id}", status_code=303)


@app.get("/clients/segments", response_class=HTMLResponse)
async def client_segments_page(request: Request):
    """Client segmentation page"""
    async with async_session() as session:
        # Get all unique tags
        clients = (await session.execute(select(Client))).scalars().all()
        
        tags_count = {}
        for client in clients:
            if client.tags:
                for tag in client.tags.split(","):
                    tag = tag.strip()
                    if tag:
                        tags_count[tag] = tags_count.get(tag, 0) + 1
        
        # Get status distribution
        status_counts = {}
        for client in clients:
            status_counts[client.status] = status_counts.get(client.status, 0) + 1
        
        # Get type distribution
        type_counts = {}
        for client in clients:
            type_counts[client.client_type] = type_counts.get(client.client_type, 0) + 1
        
        # Get source distribution
        source_counts = {}
        for client in clients:
            if client.source:
                source_counts[client.source] = source_counts.get(client.source, 0) + 1
    
    return templates.TemplateResponse("clients/segments.html", {
        "request": request,
        "tags_count": tags_count,
        "status_counts": status_counts,
        "type_counts": type_counts,
        "source_counts": source_counts
    })


@app.get("/clients/duplicates", response_class=HTMLResponse)
async def find_duplicates_page(request: Request):
    """Page for finding and managing duplicate clients"""
    async with async_session() as session:
        # Find potential duplicates by email
        email_duplicates = (await session.execute(
            select(Client.email, func.count(Client.id).label('count'))
            .where(Client.email != None, Client.email != "")
            .group_by(Client.email)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by phone
        phone_duplicates = (await session.execute(
            select(Client.phone, func.count(Client.id).label('count'))
            .where(Client.phone != None, Client.phone != "")
            .group_by(Client.phone)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by name
        name_duplicates = (await session.execute(
            select(Client.full_name, func.count(Client.id).label('count'))
            .where(Client.full_name != None, Client.full_name != "")
            .group_by(Client.full_name)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Get duplicate groups with details
        duplicate_groups = []
        
        for email, count in email_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.email == email)
            )).scalars().all()
            duplicate_groups.append({
                "type": "email",
                "value": email,
                "count": count,
                "clients": clients
            })
        
        for phone, count in phone_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.phone == phone)
            )).scalars().all()
            duplicate_groups.append({
                "type": "phone",
                "value": phone,
                "count": count,
                "clients": clients
            })
        
        for name, count in name_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.full_name == name)
            )).scalars().all()
            # Only add if not already in email/phone duplicates
            client_ids = [c.id for c in clients]
            if not any(c.id in client_ids for group in duplicate_groups for c in group['clients']):
                duplicate_groups.append({
                    "type": "name",
                    "value": name,
                    "count": count,
                    "clients": clients
                })
    
    return templates.TemplateResponse("clients/duplicates.html", {
        "request": request,
        "duplicate_groups": duplicate_groups
    })


@app.post("/clients", response_class=HTMLResponse)
async def create_client(
    request: Request,
    full_name: str = Form(...),
    client_type: str = Form("lead"),
    company_name: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    website: str = Form(None),
    address: str = Form(None),
    city: str = Form(None),
    country: str = Form(None),
    source: str = Form(None),
    source_detail: str = Form(None),
    comment: str = Form(None),
    tags: str = Form(None),
    inn: str = Form(None),
    company_id: str = Form(None)
):
    async with async_session() as session:
        client = Client(
            full_name=full_name,
            client_type=client_type,
            company_name=company_name,
            phone=phone,
            email=email,
            website=website,
            address=address,
            city=city,
            country=country,
            source=source,
            source_detail=source_detail,
            comment=comment,
            tags=tags,
            inn=inn,
            company_id=int(company_id) if company_id else None,
            status="new"
        )
        session.add(client)
        await session.commit()
        await session.refresh(client)
        
        await log_activity(session, 1, "client", client.id, "created", f"Создан клиент: {full_name}")
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{client.id}", status_code=303)


@app.get("/clients/{client_id}", response_class=HTMLResponse)
async def client_card(request: Request, client_id: int):
    async with async_session() as session:
        client = (await session.execute(
            select(Client)
            .options(
                selectinload(Client.deals).selectinload(Deal.stage),
                selectinload(Client.tasks),
                selectinload(Client.communications),
                selectinload(Client.documents),
                selectinload(Client.files),
                selectinload(Client.events)
            )
            .where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
        
        # Get company if this is a contact
        company = None
        if client.company_id:
            company = (await session.execute(
                select(Client).where(Client.id == client.company_id)
            )).scalar_one_or_none()
        
        # Get contacts if this is a company
        contacts = []
        if client.client_type == "company":
            contacts = (await session.execute(
                select(Client).where(Client.company_id == client.id)
            )).scalars().all()
    
    return templates.TemplateResponse("clients/card.html", {
        "request": request,
        "client": client,
        "company": company,
        "contacts": contacts
    })


@app.get("/clients/{client_id}/edit", response_class=HTMLResponse)
async def edit_client_form(request: Request, client_id: int):
    async with async_session() as session:
        client = (await session.execute(
            select(Client).where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
    
    return templates.TemplateResponse("clients/form.html", {
        "request": request,
        "client": client,
        "client_type": client.client_type
    })


@app.post("/clients/{client_id}/edit", response_class=HTMLResponse)
async def update_client(
    request: Request,
    client_id: int,
    full_name: str = Form(...),
    client_type: str = Form("lead"),
    company_name: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    website: str = Form(None),
    address: str = Form(None),
    city: str = Form(None),
    country: str = Form(None),
    source: str = Form(None),
    comment: str = Form(None),
    tags: str = Form(None),
    status: str = Form(None),
    inn: str = Form(None),
    company_id: str = Form(None)
):
    async with async_session() as session:
        client = (await session.execute(
            select(Client).where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
        
        old_values = {
            "full_name": client.full_name,
            "status": client.status
        }
        
        client.full_name = full_name
        client.client_type = client_type
        client.company_name = company_name
        client.phone = phone
        client.email = email
        client.website = website
        client.address = address
        client.city = city
        client.country = country
        client.source = source
        client.comment = comment
        client.tags = tags
        client.status = status or client.status
        client.inn = inn
        client.company_id = int(company_id) if company_id else None
        client.updated_at = datetime.now()
        
        await log_activity(session, 1, "client", client.id, "updated", f"Обновлен клиент: {full_name}", old_values=old_values)
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{client_id}", status_code=303)


@app.post("/clients/{client_id}/delete", response_class=HTMLResponse)
async def delete_client(request: Request, client_id: int):
    async with async_session() as session:
        client = (await session.execute(
            select(Client).where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
        
        await session.delete(client)
        await session.commit()
    
    return RedirectResponse(url="/clients", status_code=303)


@app.post("/clients/{client_id}/convert", response_class=HTMLResponse)
async def convert_client(request: Request, client_id: int, to_type: str = Form("contact")):
    async with async_session() as session:
        client = (await session.execute(
            select(Client).where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
        
        client.client_type = to_type
        client.status = "active"
        client.updated_at = datetime.now()
        
        await log_activity(session, 1, "client", client.id, "converted", f"Конвертирован в {to_type}")
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{client_id}", status_code=303)


# ==================== DEALS ====================

@app.get("/deals", response_class=HTMLResponse)
async def deals_list(
    request: Request,
    pipeline_id: int = Query(None),
    stage_id: int = Query(None),
    status: str = Query("open"),
    search: str = Query(None)
):
    async with async_session() as session:
        # Get pipelines
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
        
        # Build query
        query = select(Deal).options(
            selectinload(Deal.client),
            selectinload(Deal.stage),
            selectinload(Deal.responsible)
        )
        
        if pipeline_id:
            query = query.where(Deal.pipeline_id == pipeline_id)
        if stage_id:
            query = query.where(Deal.stage_id == stage_id)
        if status:
            query = query.where(Deal.status == status)
        if search:
            query = query.where(Deal.title.ilike(f"%{search}%"))
        
        query = query.order_by(Deal.created_at.desc())
        deals = (await session.execute(query)).scalars().all()
        
        # Group by stage for kanban view
        deals_by_stage = {}
        for deal in deals:
            if deal.stage_id not in deals_by_stage:
                deals_by_stage[deal.stage_id] = []
            deals_by_stage[deal.stage_id].append(deal)
    
    return templates.TemplateResponse("deals/list.html", {
        "request": request,
        "deals": deals,
        "pipelines": pipelines,
        "deals_by_stage": deals_by_stage,
        "filters": {"pipeline_id": pipeline_id, "stage_id": stage_id, "status": status, "search": search}
    })


@app.get("/deals/new", response_class=HTMLResponse)
async def new_deal_form(request: Request, client_id: int = None):
    async with async_session() as session:
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
        
        client = None
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
    
    return templates.TemplateResponse("deals/form.html", {
        "request": request,
        "deal": None,
        "pipelines": pipelines,
        "client": client
    })


@app.post("/deals", response_class=HTMLResponse)
async def create_deal(
    request: Request,
    title: str = Form(...),
    pipeline_id: int = Form(...),
    stage_id: int = Form(None),
    client_id: int = Form(None),
    amount: float = Form(0),
    margin: float = Form(None),
    source: str = Form(None),
    description: str = Form(None),
    expected_close_date: str = Form(None)
):
    async with async_session() as session:
        # Get first stage if not specified
        if not stage_id:
            first_stage = (await session.execute(
                select(PipelineStage).where(PipelineStage.pipeline_id == pipeline_id)
                .order_by(PipelineStage.sort_order).limit(1)
            )).scalar_one_or_none()
            stage_id = first_stage.id if first_stage else None
        
        deal = Deal(
            title=title,
            pipeline_id=pipeline_id,
            stage_id=stage_id,
            client_id=client_id if client_id else None,
            amount=Decimal(str(amount)) if amount else Decimal("0"),
            margin=Decimal(str(margin)) if margin else None,
            source=source,
            description=description,
            expected_close_date=date.fromisoformat(expected_close_date) if expected_close_date else None,
            status="open"
        )
        session.add(deal)
        await session.commit()
        await session.refresh(deal)
        
        # Log history
        history = DealHistory(
            deal_id=deal.id,
            action="created",
            new_value=title
        )
        session.add(history)
        await log_activity(session, 1, "deal", deal.id, "created", f"Создана сделка: {title}")
        await session.commit()
    
    return RedirectResponse(url=f"/deals/{deal.id}", status_code=303)


@app.get("/deals/{deal_id}", response_class=HTMLResponse)
async def deal_card(request: Request, deal_id: int):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal)
            .options(
                selectinload(Deal.client),
                selectinload(Deal.stage),
                selectinload(Deal.pipeline),
                selectinload(Deal.responsible),
                selectinload(Deal.tasks),
                selectinload(Deal.documents),
                selectinload(Deal.files),
                selectinload(Deal.history)
            )
            .where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            raise HTTPException(404, "Сделка не найдена")
        
        # Get all stages for pipeline
        stages = (await session.execute(
            select(PipelineStage).where(PipelineStage.pipeline_id == deal.pipeline_id)
            .order_by(PipelineStage.sort_order)
        )).scalars().all()
    
    return templates.TemplateResponse("deals/card.html", {
        "request": request,
        "deal": deal,
        "stages": stages
    })


@app.post("/deals/{deal_id}/stage", response_class=HTMLResponse)
async def update_deal_stage(
    request: Request,
    deal_id: int,
    stage_id: int = Form(...)
):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal).options(selectinload(Deal.stage))
            .where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            raise HTTPException(404, "Сделка не найдена")
        
        new_stage = (await session.execute(
            select(PipelineStage).where(PipelineStage.id == stage_id)
        )).scalar_one_or_none()
        
        old_stage_name = deal.stage.name if deal.stage else "N/A"
        
        deal.stage_id = stage_id
        deal.updated_at = datetime.now()
        
        # Check if won/lost stage
        if new_stage:
            if new_stage.is_won:
                deal.status = "won"
                deal.actual_close_date = date.today()
            elif new_stage.is_lost:
                deal.status = "lost"
                deal.actual_close_date = date.today()
        
        # Log history
        history = DealHistory(
            deal_id=deal.id,
            action="stage_changed",
            old_value=old_stage_name,
            new_value=new_stage.name if new_stage else "N/A"
        )
        session.add(history)
        await session.commit()
    
    return RedirectResponse(url=f"/deals/{deal_id}", status_code=303)


@app.get("/deals/{deal_id}/edit", response_class=HTMLResponse)
async def edit_deal_form(request: Request, deal_id: int):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal).options(selectinload(Deal.client))
            .where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            raise HTTPException(404, "Сделка не найдена")
        
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
    
    return templates.TemplateResponse("deals/form.html", {
        "request": request,
        "deal": deal,
        "pipelines": pipelines
    })


@app.post("/deals/{deal_id}/edit", response_class=HTMLResponse)
async def update_deal(
    request: Request,
    deal_id: int,
    title: str = Form(...),
    pipeline_id: int = Form(...),
    stage_id: int = Form(...),
    client_id: int = Form(None),
    amount: float = Form(0),
    margin: float = Form(None),
    source: str = Form(None),
    description: str = Form(None),
    expected_close_date: str = Form(None)
):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal).where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            raise HTTPException(404, "Сделка не найдена")
        
        deal.title = title
        deal.pipeline_id = pipeline_id
        deal.stage_id = stage_id
        deal.client_id = client_id if client_id else None
        deal.amount = Decimal(str(amount)) if amount else Decimal("0")
        deal.margin = Decimal(str(margin)) if margin else None
        deal.source = source
        deal.description = description
        deal.expected_close_date = date.fromisoformat(expected_close_date) if expected_close_date else None
        deal.updated_at = datetime.now()
        
        await session.commit()
    
    return RedirectResponse(url=f"/deals/{deal_id}", status_code=303)


@app.post("/deals/{deal_id}/delete", response_class=HTMLResponse)
async def delete_deal(request: Request, deal_id: int):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal).where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            raise HTTPException(404, "Сделка не найдена")
        
        await session.delete(deal)
        await session.commit()
    
    return RedirectResponse(url="/deals", status_code=303)


# ==================== TASKS ====================

@app.get("/tasks", response_class=HTMLResponse)
async def tasks_list(
    request: Request,
    status: str = Query(None),
    task_type: str = Query(None),
    priority: str = Query(None),
    overdue: bool = Query(False)
):
    async with async_session() as session:
        query = select(Task).options(
            selectinload(Task.client),
            selectinload(Task.deal),
            selectinload(Task.assignee)
        )
        
        if status:
            query = query.where(Task.status == status)
        if task_type:
            query = query.where(Task.task_type == task_type)
        if priority:
            query = query.where(Task.priority == priority)
        if overdue:
            query = query.where(Task.status != "completed", Task.due_date < datetime.now())
        
        query = query.order_by(Task.due_date)
        tasks = (await session.execute(query)).scalars().all()
    
    return templates.TemplateResponse("tasks/list.html", {
        "request": request,
        "tasks": tasks,
        "filters": {"status": status, "task_type": task_type, "priority": priority, "overdue": overdue}
    })


@app.get("/tasks/dashboard", response_class=HTMLResponse)
async def tasks_dashboard(request: Request):
    """Task dashboard with KPI metrics and overdue tracking"""
    async with async_session() as session:
        now = datetime.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        today_end = today_start + timedelta(days=1)
        week_end = today_start + timedelta(days=7)
        
        # Get all tasks with relationships
        all_tasks = (await session.execute(
            select(Task).options(
                selectinload(Task.client),
                selectinload(Task.assignee)
            )
        )).scalars().all()
        
        # Calculate statistics
        total_tasks = len(all_tasks)
        new_tasks = len([t for t in all_tasks if t.status == "new"])
        in_progress_tasks = len([t for t in all_tasks if t.status == "in_progress"])
        completed_tasks = len([t for t in all_tasks if t.status == "completed"])
        cancelled_tasks = len([t for t in all_tasks if t.status == "cancelled"])
        
        # Overdue tasks (not completed/cancelled and past due date)
        overdue_tasks = [
            t for t in all_tasks 
            if t.status not in ["completed", "cancelled"] 
            and t.due_date 
            and t.due_date < now
        ]
        
        # Today's tasks
        today_tasks = [
            t for t in all_tasks 
            if t.due_date 
            and today_start <= t.due_date < today_end
            and t.status not in ["completed", "cancelled"]
        ]
        
        # Upcoming tasks (next 7 days)
        upcoming_tasks = [
            t for t in all_tasks 
            if t.due_date 
            and today_start <= t.due_date < week_end
            and t.status not in ["completed", "cancelled"]
        ]
        
        # By type
        by_type = {}
        for t in all_tasks:
            by_type[t.task_type] = by_type.get(t.task_type, 0) + 1
        
        # By priority
        by_priority = {}
        for t in all_tasks:
            by_priority[t.priority] = by_priority.get(t.priority, 0) + 1
        
        # By status
        by_status = {
            "new": new_tasks,
            "in_progress": in_progress_tasks,
            "completed": completed_tasks,
            "cancelled": cancelled_tasks
        }
        
        # Completion rate
        completion_rate = round(completed_tasks / total_tasks * 100, 1) if total_tasks > 0 else 0
        
        # Overdue rate
        active_tasks = total_tasks - cancelled_tasks
        overdue_rate = round(len(overdue_tasks) / active_tasks * 100, 1) if active_tasks > 0 else 0
        
        # On-time completion (completed tasks that were done before due date)
        on_time_completions = len([
            t for t in all_tasks 
            if t.status == "completed" 
            and t.completed_at 
            and t.due_date 
            and t.completed_at <= t.due_date
        ])
        on_time_rate = round(on_time_completions / completed_tasks * 100, 1) if completed_tasks > 0 else 0
        
        # Get users for assignee stats
        users = (await session.execute(select(User))).scalars().all()
        
        # By assignee
        by_assignee = {}
        for user in users:
            user_tasks = [t for t in all_tasks if t.assignee_id == user.id]
            completed = len([t for t in user_tasks if t.status == "completed"])
            overdue = len([t for t in user_tasks if t in overdue_tasks])
            by_assignee[user.id] = {
                "name": user.full_name,
                "total": len(user_tasks),
                "completed": completed,
                "overdue": overdue,
                "completion_rate": round(completed / len(user_tasks) * 100, 1) if user_tasks else 0
            }
    
    return templates.TemplateResponse("tasks/dashboard.html", {
        "request": request,
        "total_tasks": total_tasks,
        "new_tasks": new_tasks,
        "in_progress_tasks": in_progress_tasks,
        "completed_tasks": completed_tasks,
        "cancelled_tasks": cancelled_tasks,
        "overdue_tasks": overdue_tasks,
        "today_tasks": today_tasks,
        "upcoming_tasks": upcoming_tasks,
        "by_type": by_type,
        "by_priority": by_priority,
        "by_status": by_status,
        "by_assignee": by_assignee,
        "completion_rate": completion_rate,
        "overdue_rate": overdue_rate,
        "on_time_rate": on_time_rate
    })


@app.get("/tasks/new", response_class=HTMLResponse)
async def new_task_form(request: Request, client_id: int = None, deal_id: int = None):
    async with async_session() as session:
        client = None
        deal = None
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
        if deal_id:
            deal = (await session.execute(
                select(Deal).where(Deal.id == deal_id)
            )).scalar_one_or_none()
    
    return templates.TemplateResponse("tasks/form.html", {
        "request": request,
        "task": None,
        "client": client,
        "deal": deal
    })


@app.post("/tasks", response_class=HTMLResponse)
async def create_task(
    request: Request,
    title: str = Form(...),
    description: str = Form(None),
    task_type: str = Form("other"),
    priority: str = Form("medium"),
    client_id: int = Form(None),
    deal_id: int = Form(None),
    due_date: str = Form(None),
    due_time: str = Form(None),
    duration_minutes: int = Form(None)
):
    async with async_session() as session:
        dt = None
        if due_date:
            dt = datetime.fromisoformat(due_date)
            if due_time:
                t = datetime.strptime(due_time, "%H:%M").time()
                dt = datetime.combine(dt.date(), t)
        
        task = Task(
            title=title,
            description=description,
            task_type=task_type,
            priority=priority,
            client_id=client_id if client_id else None,
            deal_id=deal_id if deal_id else None,
            due_date=dt,
            duration_minutes=duration_minutes,
            status="new"
        )
        session.add(task)
        await session.commit()
        await session.refresh(task)
        
        await log_activity(session, 1, "task", task.id, "created", f"Создана задача: {title}")
        await session.commit()
    
    return RedirectResponse(url=f"/tasks/{task.id}", status_code=303)


@app.get("/tasks/{task_id}", response_class=HTMLResponse)
async def task_card(request: Request, task_id: int):
    async with async_session() as session:
        task = (await session.execute(
            select(Task)
            .options(
                selectinload(Task.client),
                selectinload(Task.deal),
                selectinload(Task.assignee)
            )
            .where(Task.id == task_id)
        )).scalar_one_or_none()
        
        if not task:
            raise HTTPException(404, "Задача не найдена")
    
    return templates.TemplateResponse("tasks/card.html", {
        "request": request,
        "task": task
    })


@app.post("/tasks/{task_id}/complete", response_class=HTMLResponse)
async def complete_task(request: Request, task_id: int, result: str = Form(None)):
    async with async_session() as session:
        task = (await session.execute(
            select(Task).where(Task.id == task_id)
        )).scalar_one_or_none()
        
        if not task:
            raise HTTPException(404, "Задача не найдена")
        
        task.status = "completed"
        task.completed_at = datetime.now()
        task.result = result
        
        await session.commit()
    
    return RedirectResponse(url="/tasks", status_code=303)


@app.post("/tasks/{task_id}/delete", response_class=HTMLResponse)
async def delete_task(request: Request, task_id: int):
    async with async_session() as session:
        task = (await session.execute(
            select(Task).where(Task.id == task_id)
        )).scalar_one_or_none()
        
        if not task:
            raise HTTPException(404, "Задача не найдена")
        
        await session.delete(task)
        await session.commit()
    
    return RedirectResponse(url="/tasks", status_code=303)


# ==================== COMMUNICATIONS ====================

@app.get("/messages", response_class=HTMLResponse)
async def messages_list(
    request: Request,
    channel: str = Query(None),
    client_id: int = Query(None)
):
    async with async_session() as session:
        query = select(Communication).options(selectinload(Communication.client))
        
        if channel:
            query = query.where(Communication.channel == channel)
        if client_id:
            query = query.where(Communication.client_id == client_id)
        
        query = query.order_by(Communication.created_at.desc())
        messages = (await session.execute(query)).scalars().all()
    
    return templates.TemplateResponse("messages/list.html", {
        "request": request,
        "messages": messages,
        "filters": {"channel": channel, "client_id": client_id}
    })


@app.get("/messages/new", response_class=HTMLResponse)
async def new_message_form(request: Request, client_id: int = None):
    async with async_session() as session:
        client = None
        templates_list = []
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
        
        templates_list = (await session.execute(
            select(MessageTemplate).where(MessageTemplate.is_global == True)
        )).scalars().all()
    
    return templates.TemplateResponse("messages/form.html", {
        "request": request,
        "client": client,
        "templates": templates_list
    })


@app.post("/messages", response_class=HTMLResponse)
async def send_message(
    request: Request,
    channel: str = Form(...),
    client_id: int = Form(None),
    deal_id: int = Form(None),
    to_contact: str = Form(...),
    subject: str = Form(None),
    body: str = Form(...)
):
    async with async_session() as session:
        comm = Communication(
            channel=channel,
            direction="outbound",
            client_id=client_id if client_id else None,
            deal_id=deal_id if deal_id else None,
            to_contact=to_contact,
            subject=subject,
            body=body,
            status="sent",
            sent_at=datetime.now()
        )
        session.add(comm)
        await session.commit()
        
        # Update client last contact
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
            if client:
                client.last_contact_at = datetime.now()
                await session.commit()
    
    return RedirectResponse(url="/messages", status_code=303)


# ==================== MAIL ====================

@app.get("/mail", response_class=HTMLResponse)
async def mail_list(request: Request, folder: str = "inbox"):
    async with async_session() as session:
        query = select(Communication).options(selectinload(Communication.client))
        query = query.where(Communication.channel == "email")
        
        if folder == "inbox":
            query = query.where(Communication.direction == "inbound")
        elif folder == "sent":
            query = query.where(Communication.direction == "outbound")
        
        query = query.order_by(Communication.created_at.desc())
        emails = (await session.execute(query)).scalars().all()
    
    return templates.TemplateResponse("mail/list.html", {
        "request": request,
        "emails": emails,
        "folder": folder
    })


@app.get("/mail/campaigns", response_class=HTMLResponse)
async def campaigns_list(request: Request):
    """List all email campaigns"""
    async with async_session() as session:
        campaigns = (await session.execute(
            select(EmailCampaign).order_by(EmailCampaign.created_at.desc())
        )).scalars().all()
    
    return templates.TemplateResponse("mail/campaigns.html", {
        "request": request,
        "campaigns": campaigns
    })


@app.get("/mail/campaigns/new", response_class=HTMLResponse)
async def new_campaign_form(request: Request):
    """Form to create new email campaign"""
    async with async_session() as session:
        # Get client count for targeting
        total_clients = (await session.execute(
            select(func.count()).select_from(Client)
            .where(Client.email != None)
            .where(Client.email != '')
        )).scalar()
    
    return templates.TemplateResponse("mail/campaign_form.html", {
        "request": request,
        "campaign": None,
        "total_clients": total_clients
    })


@app.post("/mail/campaigns", response_class=HTMLResponse)
async def create_campaign(
    request: Request,
    name: str = Form(...),
    subject: str = Form(...),
    body: str = Form(...),
    from_email: str = Form(None),
    from_name: str = Form(None),
    target_type: str = Form("all"),
    track_opens: bool = Form(False),
    track_clicks: bool = Form(False),
    scheduled_at: str = Form(None)
):
    """Create a new email campaign"""
    async with async_session() as session:
        campaign = EmailCampaign(
            name=name,
            subject=subject,
            body=body,
            from_email=from_email,
            from_name=from_name,
            target_type=target_type,
            track_opens=track_opens,
            track_clicks=track_clicks,
            status="draft"
        )
        
        if scheduled_at:
            try:
                campaign.scheduled_at = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
                campaign.status = "scheduled"
            except:
                pass
        
        session.add(campaign)
        await session.commit()
        await session.refresh(campaign)
    
    return RedirectResponse(url=f"/mail/campaigns/{campaign.id}", status_code=303)


@app.get("/mail/campaigns/{campaign_id}", response_class=HTMLResponse)
async def campaign_detail(request: Request, campaign_id: int):
    """View campaign details and stats"""
    async with async_session() as session:
        campaign = (await session.execute(
            select(EmailCampaign).where(EmailCampaign.id == campaign_id)
        )).scalar_one_or_none()
        
        if not campaign:
            raise HTTPException(404, "Кампания не найдена")
        
        # Get recipients
        recipients = (await session.execute(
            select(EmailCampaignRecipient)
            .where(EmailCampaignRecipient.campaign_id == campaign_id)
            .limit(100)
        )).scalars().all()
        
        # Calculate stats
        stats = {
            "open_rate": round(campaign.opened_count / campaign.sent_count * 100, 1) if campaign.sent_count > 0 else 0,
            "click_rate": round(campaign.clicked_count / campaign.sent_count * 100, 1) if campaign.sent_count > 0 else 0,
            "bounce_rate": round(campaign.bounced_count / campaign.sent_count * 100, 1) if campaign.sent_count > 0 else 0,
            "delivery_rate": round(campaign.delivered_count / campaign.sent_count * 100, 1) if campaign.sent_count > 0 else 0
        }
    
    return templates.TemplateResponse("mail/campaign_detail.html", {
        "request": request,
        "campaign": campaign,
        "recipients": recipients,
        "stats": stats
    })


@app.post("/mail/campaigns/{campaign_id}/send", response_class=HTMLResponse)
async def send_campaign(request: Request, campaign_id: int):
    """Send campaign to recipients (simulation)"""
    async with async_session() as session:
        campaign = (await session.execute(
            select(EmailCampaign).where(EmailCampaign.id == campaign_id)
        )).scalar_one_or_none()
        
        if not campaign:
            raise HTTPException(404, "Кампания не найдена")
        
        if campaign.status not in ["draft", "scheduled"]:
            raise HTTPException(400, "Кампания уже отправлена")
        
        # Get target clients
        query = select(Client).where(Client.email != None).where(Client.email != '')
        if campaign.target_type == "active":
            query = query.where(Client.status == "active")
        
        clients = (await session.execute(query)).scalars().all()
        
        # Create recipients
        import hashlib
        for client in clients:
            tracking_id = hashlib.sha256(f"{campaign_id}-{client.id}-{datetime.now().isoformat()}".encode()).hexdigest()[:32]
            recipient = EmailCampaignRecipient(
                campaign_id=campaign_id,
                client_id=client.id,
                email=client.email,
                name=client.full_name,
                tracking_id=tracking_id,
                status="pending"
            )
            session.add(recipient)
        
        campaign.total_recipients = len(clients)
        campaign.sent_count = len(clients)
        campaign.status = "sent"
        campaign.sent_at = datetime.now()
        
        await session.commit()
    
    return RedirectResponse(url=f"/mail/campaigns/{campaign_id}", status_code=303)


@app.get("/mail/accounts", response_class=HTMLResponse)
async def email_accounts_list(request: Request):
    """List email accounts"""
    async with async_session() as session:
        accounts = (await session.execute(
            select(EmailAccount).order_by(EmailAccount.email)
        )).scalars().all()
    
    return templates.TemplateResponse("mail/accounts.html", {
        "request": request,
        "accounts": accounts
    })


@app.post("/mail/accounts", response_class=HTMLResponse)
async def create_email_account(
    request: Request,
    email: str = Form(...),
    imap_server: str = Form(None),
    imap_port: int = Form(993),
    smtp_server: str = Form(None),
    smtp_port: int = Form(587),
    password: str = Form(None)
):
    """Add email account for sync"""
    async with async_session() as session:
        account = EmailAccount(
            email=email,
            imap_server=imap_server,
            imap_port=imap_port,
            smtp_server=smtp_server,
            smtp_port=smtp_port,
            password_encrypted=password  # Should be encrypted in production
        )
        session.add(account)
        await session.commit()
    
    return RedirectResponse(url="/mail/accounts", status_code=303)


@app.get("/mail/track/open/{tracking_id}", response_class=HTMLResponse)
async def track_open(tracking_id: str):
    """Track email open via tracking pixel"""
    async with async_session() as session:
        recipient = (await session.execute(
            select(EmailCampaignRecipient)
            .where(EmailCampaignRecipient.tracking_id == tracking_id)
        )).scalar_one_or_none()
        
        if recipient and recipient.opened_at is None:
            recipient.opened_at = datetime.now()
            recipient.open_count = 1
            recipient.status = "opened"
            
            # Update campaign stats
            campaign = (await session.execute(
                select(EmailCampaign).where(EmailCampaign.id == recipient.campaign_id)
            )).scalar_one_or_none()
            if campaign:
                campaign.opened_count += 1
            
            # Log event
            event = EmailTrackingEvent(
                campaign_id=recipient.campaign_id,
                recipient_id=recipient.id,
                client_id=recipient.client_id,
                event_type="opened"
            )
            session.add(event)
            await session.commit()
    
    # Return 1x1 transparent GIF
    from fastapi.responses import Response
    return Response(
        content=b'\x47\x49\x46\x38\x39\x61\x01\x00\x01\x00\x00\x00\x00\x21\xf9\x04\x01\x0a\x00\x01\x00\x2c\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x4c\x01\x00\x3b',
        media_type="image/gif"
    )


@app.post("/mail/sync", response_class=HTMLResponse)
async def sync_email(request: Request):
    """Sync email from all accounts (simulation)"""
    # In production, this would connect to IMAP and fetch new emails
    # For now, we'll just update the last_sync timestamp
    async with async_session() as session:
        accounts = (await session.execute(
            select(EmailAccount).where(EmailAccount.is_active == True)
        )).scalars().all()
        
        for account in accounts:
            account.last_sync = datetime.now()
        
        await session.commit()
    
    return RedirectResponse(url="/mail", status_code=303)


@app.get("/mail/{email_id}", response_class=HTMLResponse)
async def email_detail(request: Request, email_id: int):
    async with async_session() as session:
        email = (await session.execute(
            select(Communication).options(selectinload(Communication.client))
            .where(Communication.id == email_id)
        )).scalar_one_or_none()
        
        if not email:
            raise HTTPException(404, "Письмо не найдено")
        
        # Mark as read
        if not email.read_at:
            email.read_at = datetime.now()
            await session.commit()
    
    return templates.TemplateResponse("mail/detail.html", {
        "request": request,
        "email": email
    })


# ==================== DOCUMENTS ====================

@app.get("/documents", response_class=HTMLResponse)
async def documents_list(
    request: Request,
    document_type: str = Query(None),
    client_id: int = Query(None),
    deal_id: int = Query(None)
):
    async with async_session() as session:
        query = select(Document).options(
            selectinload(Document.client),
            selectinload(Document.deal)
        )
        
        if document_type:
            query = query.where(Document.document_type == document_type)
        if client_id:
            query = query.where(Document.client_id == client_id)
        if deal_id:
            query = query.where(Document.deal_id == deal_id)
        
        query = query.order_by(Document.created_at.desc())
        documents = (await session.execute(query)).scalars().all()
        
        doc_templates = (await session.execute(
            select(DocumentTemplate).where(DocumentTemplate.is_active == True)
        )).scalars().all()
    
    return templates.TemplateResponse("documents/list.html", {
        "request": request,
        "documents": documents,
        "templates": doc_templates,
        "filters": {"document_type": document_type, "client_id": client_id, "deal_id": deal_id}
    })


@app.get("/documents/new", response_class=HTMLResponse)
async def new_document_form(request: Request, client_id: int = None, deal_id: int = None):
    async with async_session() as session:
        doc_templates = (await session.execute(
            select(DocumentTemplate).where(DocumentTemplate.is_active == True)
        )).scalars().all()
        
        client = None
        deal = None
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
        if deal_id:
            deal = (await session.execute(
                select(Deal).where(Deal.id == deal_id)
            )).scalar_one_or_none()
    
    return templates.TemplateResponse("documents/form.html", {
        "request": request,
        "templates": doc_templates,
        "client": client,
        "deal": deal
    })


@app.post("/documents", response_class=HTMLResponse)
async def create_document(
    request: Request,
    name: str = Form(...),
    document_type: str = Form(...),
    template_id: int = Form(None),
    client_id: int = Form(None),
    deal_id: int = Form(None),
    file: Optional[UploadFile] = FastAPIFile(default=None)
):
    async with async_session() as session:
        file_path = None
        if file and file.filename:
            # Save file
            ext = file.filename.split(".")[-1] if "." in file.filename else ""
            filename = f"{uuid.uuid4()}.{ext}" if ext else str(uuid.uuid4())
            file_path = f"uploads/{filename}"
            
            content = await file.read()
            with open(file_path, "wb") as f:
                f.write(content)
        
        doc = Document(
            name=name,
            document_type=document_type,
            template_id=template_id if template_id else None,
            client_id=client_id if client_id else None,
            deal_id=deal_id if deal_id else None,
            file_path=file_path,
            status="draft"
        )
        session.add(doc)
        await session.commit()
        await session.refresh(doc)
    
    return RedirectResponse(url=f"/documents/{doc.id}", status_code=303)


# ==================== DOCUMENT TEMPLATES ====================
# Note: These routes must be defined BEFORE /documents/{document_id} to avoid route conflicts

@app.get("/documents/templates", response_class=HTMLResponse)
async def document_templates_list(request: Request):
    """List document templates"""
    async with async_session() as session:
        templates_list = (await session.execute(
            select(DocumentTemplate).order_by(DocumentTemplate.document_type, DocumentTemplate.name)
        )).scalars().all()
    
    return templates.TemplateResponse("documents/templates.html", {
        "request": request,
        "templates": templates_list,
        "template_type": "document"
    })


@app.get("/documents/templates/new", response_class=HTMLResponse)
async def new_document_template_form(request: Request, template_type: str = "contract"):
    """Form to create new document template"""
    return templates.TemplateResponse("documents/template_form.html", {
        "request": request,
        "template": None,
        "template_type": template_type
    })


@app.post("/documents/templates", response_class=HTMLResponse)
async def create_document_template(
    request: Request,
    name: str = Form(...),
    document_type: str = Form(...),
    content: str = Form(...),
    variables: str = Form(None)
):
    """Create document template"""
    async with async_session() as session:
        # Parse variables if provided
        vars_list = []
        if variables:
            vars_list = [v.strip() for v in variables.split(",") if v.strip()]
        
        template = DocumentTemplate(
            name=name,
            document_type=document_type,
            content=content,
            variables=vars_list,
            is_active=True
        )
        session.add(template)
        await session.commit()
        await session.refresh(template)
    
    return RedirectResponse(url=f"/documents/templates/{template.id}", status_code=303)


@app.get("/documents/templates/{template_id}", response_class=HTMLResponse)
async def document_template_detail(request: Request, template_id: int):
    """View document template"""
    async with async_session() as session:
        template = (await session.execute(
            select(DocumentTemplate).where(DocumentTemplate.id == template_id)
        )).scalar_one_or_none()
        
        if not template:
            raise HTTPException(404, "Шаблон не найден")
    
    return templates.TemplateResponse("documents/template_form.html", {
        "request": request,
        "template": template,
        "template_type": template.document_type
    })


@app.post("/documents/templates/{template_id}", response_class=HTMLResponse)
async def update_document_template(
    request: Request,
    template_id: int,
    name: str = Form(...),
    document_type: str = Form(...),
    content: str = Form(...),
    variables: str = Form(None),
    is_active: bool = Form(True)
):
    """Update document template"""
    async with async_session() as session:
        template = (await session.execute(
            select(DocumentTemplate).where(DocumentTemplate.id == template_id)
        )).scalar_one_or_none()
        
        if not template:
            raise HTTPException(404, "Шаблон не найден")
        
        # Parse variables
        vars_list = []
        if variables:
            vars_list = [v.strip() for v in variables.split(",") if v.strip()]
        
        template.name = name
        template.document_type = document_type
        template.content = content
        template.variables = vars_list
        template.is_active = is_active
        
        await session.commit()
    
    return RedirectResponse(url=f"/documents/templates/{template_id}", status_code=303)


# ==================== DOCUMENT DETAIL ====================

@app.get("/documents/{document_id}", response_class=HTMLResponse)
async def document_detail(request: Request, document_id: int):
    async with async_session() as session:
        doc = (await session.execute(
            select(Document)
            .options(
                selectinload(Document.client),
                selectinload(Document.deal),
                selectinload(Document.template)
            )
            .where(Document.id == document_id)
        )).scalar_one_or_none()
        
        if not doc:
            raise HTTPException(404, "Документ не найден")
    
    return templates.TemplateResponse("documents/detail.html", {
        "request": request,
        "document": doc
    })


@app.post("/documents/{document_id}/delete", response_class=HTMLResponse)
async def delete_document(request: Request, document_id: int):
    async with async_session() as session:
        doc = (await session.execute(
            select(Document).where(Document.id == document_id)
        )).scalar_one_or_none()
        
        if not doc:
            raise HTTPException(404, "Äîêóìåíò íå íàéäåí")
        
        await session.delete(doc)
        await session.commit()
    
    return RedirectResponse(url="/documents", status_code=303)


# ==================== DOCUMENT GENERATION ====================

@app.get("/documents/generate/{template_id}", response_class=HTMLResponse)
async def generate_document_form(request: Request, template_id: int, client_id: int = None, deal_id: int = None):
    """Form to generate document from template"""
    async with async_session() as session:
        template = (await session.execute(
            select(DocumentTemplate).where(DocumentTemplate.id == template_id)
        )).scalar_one_or_none()
        
        if not template:
            raise HTTPException(404, "Øàáëîí íå íàéäåí")
        
        client = None
        deal = None
        
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
        
        if deal_id:
            deal = (await session.execute(
                select(Deal).options(selectinload(Deal.client)).where(Deal.id == deal_id)
            )).scalar_one_or_none()
            if deal and not client:
                client = deal.client
    
    return templates.TemplateResponse("documents/form.html", {
        "request": request,
        "template": template,
        "client": client,
        "deal": deal,
        "templates": [template]
    })


@app.post("/documents/generate/{template_id}", response_class=HTMLResponse)
async def generate_document(
    request: Request,
    template_id: int,
    name: str = Form(...),
    client_id: int = Form(None),
    deal_id: int = Form(None)
):
    """Generate document from template with variable substitution"""
    async with async_session() as session:
        template = (await session.execute(
            select(DocumentTemplate).where(DocumentTemplate.id == template_id)
        )).scalar_one_or_none()
        
        if not template:
            raise HTTPException(404, "Øàáëîí íå íàéäåí")
        
        # Get client and deal for variable substitution
        client = None
        deal = None
        
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
        
        if deal_id:
            deal = (await session.execute(
                select(Deal).where(Deal.id == deal_id)
            )).scalar_one_or_none()
        
        # Substitute variables in template content
        content = template.content
        today = datetime.now()
        
        # Replace common variables
        if client:
            content = content.replace("{{client_name}}", client.full_name or "")
            content = content.replace("{{client_company}}", client.company_name or "")
            content = content.replace("{{client_email}}", client.email or "")
            content = content.replace("{{client_phone}}", client.phone or "")
            content = content.replace("{{client_address}}", client.address or "")
            content = content.replace("{{client_inn}}", client.inn or "")
        
        if deal:
            content = content.replace("{{deal_title}}", deal.title or "")
            content = content.replace("{{deal_amount}}", str(deal.amount or 0))
            content = content.replace("{{deal_amount_formatted}}", format_currency(deal.amount))
        
        content = content.replace("{{date}}", today.strftime("%d.%m.%Y"))
        content = content.replace("{{current_date}}", today.strftime("%d.%m.%Y"))
        content = content.replace("{{current_year}}", str(today.year))
        
        # Create document
        doc = Document(
            name=name,
            document_type=template.document_type,
            template_id=template.id,
            client_id=client_id,
            deal_id=deal_id,
            status="draft"
        )
        session.add(doc)
        await session.commit()
        await session.refresh(doc)
        
        # Save generated content as HTML file
        filename = f"doc_{doc.id}_{uuid.uuid4().hex[:8]}.html"
        file_path = f"uploads/{filename}"
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{name}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        h1 {{ color: #333; }}
        .document {{ max-width: 800px; margin: 0 auto; }}
    </style>
</head>
<body>
    <div class="document">
        {content}
    </div>
</body>
</html>""")
        
        doc.file_path = file_path
        await session.commit()
    
    return RedirectResponse(url=f"/documents/{doc.id}", status_code=303)


# ==================== DOCUMENT SIGNING ====================

@app.post("/documents/{document_id}/send", response_class=HTMLResponse)
async def send_document_for_signing(request: Request, document_id: int):
    """Send document for signing"""
    async with async_session() as session:
        doc = (await session.execute(
            select(Document).where(Document.id == document_id)
        )).scalar_one_or_none()
        
        if not doc:
            raise HTTPException(404, "Äîêóìåíò íå íàéäåí")
        
        doc.status = "sent"
        doc.sent_at = datetime.now()
        
        # In real implementation, this would integrate with EDO provider
        # For now, we just update the status
        doc.edo_status = "pending"
        
        await session.commit()
    
    return RedirectResponse(url=f"/documents/{document_id}", status_code=303)


@app.post("/documents/{document_id}/sign", response_class=HTMLResponse)
async def mark_document_signed(
    request: Request,
    document_id: int,
    signed_by: str = Form(...)
):
    """Mark document as signed"""
    async with async_session() as session:
        doc = (await session.execute(
            select(Document).where(Document.id == document_id)
        )).scalar_one_or_none()
        
        if not doc:
            raise HTTPException(404, "Äîêóìåíò íå íàéäåí")
        
        doc.status = "signed"
        doc.signed_at = datetime.now()
        doc.signed_by = signed_by
        doc.edo_status = "signed"
        
        await session.commit()
    
    return RedirectResponse(url=f"/documents/{document_id}", status_code=303)


@app.post("/documents/{document_id}/archive", response_class=HTMLResponse)
async def archive_document(request: Request, document_id: int):
    """Archive document"""
    async with async_session() as session:
        doc = (await session.execute(
            select(Document).where(Document.id == document_id)
        )).scalar_one_or_none()
        
        if not doc:
            raise HTTPException(404, "Äîêóìåíò íå íàéäåí")
        
        doc.status = "archived"
        await session.commit()
    
    return RedirectResponse(url=f"/documents/{document_id}", status_code=303)


# ==================== FILES ====================

@app.get("/files", response_class=HTMLResponse)
async def files_list(
    request: Request,
    client_id: int = Query(None),
    deal_id: int = Query(None)
):
    async with async_session() as session:
        query = select(File).options(
            selectinload(File.client),
            selectinload(File.deal)
        )
        
        if client_id:
            query = query.where(File.client_id == client_id)
        if deal_id:
            query = query.where(File.deal_id == deal_id)
        
        query = query.order_by(File.created_at.desc())
        files = (await session.execute(query)).scalars().all()
    
    return templates.TemplateResponse("files/list.html", {
        "request": request,
        "files": files,
        "filters": {"client_id": client_id, "deal_id": deal_id}
    })


@app.post("/files", response_class=HTMLResponse)
async def upload_file(
    request: Request,
    file: UploadFile = FastAPIFile(...),
    client_id: int = Form(None),
    deal_id: int = Form(None),
    is_private: bool = Form(False)
):
    async with async_session() as session:
        # Save file
        ext = file.filename.split(".")[-1] if "." in file.filename else ""
        filename = f"{uuid.uuid4()}.{ext}" if ext else str(uuid.uuid4())
        file_path = f"uploads/{filename}"
        
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        
        file_record = File(
            name=file.filename,
            original_name=file.filename,
            file_path=file_path,
            file_size=len(content),
            mime_type=file.content_type,
            client_id=client_id if client_id else None,
            deal_id=deal_id if deal_id else None,
            is_private=is_private
        )
        session.add(file_record)
        await session.commit()
    
    return RedirectResponse(url="/files", status_code=303)


@app.post("/files/{file_id}/delete", response_class=HTMLResponse)
async def delete_file(request: Request, file_id: int):
    async with async_session() as session:
        file = (await session.execute(
            select(File).where(File.id == file_id)
        )).scalar_one_or_none()
        
        if not file:
            raise HTTPException(404, "Файл не найден")
        
        # Delete from disk
        if os.path.exists(file.file_path):
            os.remove(file.file_path)
        
        await session.delete(file)
        await session.commit()
    
    return RedirectResponse(url="/files", status_code=303)


@app.get("/files/{file_id}", response_class=HTMLResponse)
async def file_detail(request: Request, file_id: int):
    """File detail with version history"""
    async with async_session() as session:
        file = (await session.execute(
            select(File).options(
                selectinload(File.client),
                selectinload(File.deal)
            ).where(File.id == file_id)
        )).scalar_one_or_none()
        
        if not file:
            raise HTTPException(404, "Файл не найден")
        
        # Get version history
        versions = []
        if file.parent_file_id:
            # This is a newer version, get parent chain
            parent_id = file.parent_file_id
            while parent_id:
                parent = (await session.execute(
                    select(File).where(File.id == parent_id)
                )).scalar_one_or_none()
                if parent:
                    versions.insert(0, parent)
                    parent_id = parent.parent_file_id
        else:
            # This might be the original, get all child versions
            child_versions = (await session.execute(
                select(File).where(File.parent_file_id == file.id).order_by(File.version)
            )).scalars().all()
            versions = child_versions
    
    return templates.TemplateResponse("files/detail.html", {
        "request": request,
        "file": file,
        "versions": versions
    })


@app.post("/files/{file_id}/upload-version", response_class=HTMLResponse)
async def upload_new_version(
    request: Request,
    file_id: int,
    file: UploadFile = FastAPIFile(...)
):
    """Upload new version of a file"""
    async with async_session() as session:
        parent_file = (await session.execute(
            select(File).where(File.id == file_id)
        )).scalar_one_or_none()
        
        if not parent_file:
            raise HTTPException(404, "Файл не найден")
        
        # Save new version
        ext = file.filename.split(".")[-1] if "." in file.filename else ""
        filename = f"{uuid.uuid4()}.{ext}" if ext else str(uuid.uuid4())
        file_path = f"uploads/{filename}"
        
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        
        # Create new file record as version
        new_version = File(
            name=parent_file.name,
            original_name=file.filename,
            file_path=file_path,
            file_size=len(content),
            mime_type=file.content_type,
            version=parent_file.version + 1,
            parent_file_id=parent_file.id,
            client_id=parent_file.client_id,
            deal_id=parent_file.deal_id,
            task_id=parent_file.task_id,
            is_private=parent_file.is_private,
            allowed_roles=parent_file.allowed_roles
        )
        session.add(new_version)
        await session.commit()
        await session.refresh(new_version)
    
    return RedirectResponse(url=f"/files/{new_version.id}", status_code=303)


@app.post("/files/{file_id}/access", response_class=HTMLResponse)
async def update_file_access(
    request: Request,
    file_id: int,
    is_private: bool = Form(False),
    allowed_roles: str = Form(None)
):
    """Update file access restrictions"""
    async with async_session() as session:
        file = (await session.execute(
            select(File).where(File.id == file_id)
        )).scalar_one_or_none()
        
        if not file:
            raise HTTPException(404, "Файл не найден")
        
        file.is_private = is_private
        if allowed_roles:
            file.allowed_roles = [r.strip() for r in allowed_roles.split(",") if r.strip()]
        else:
            file.allowed_roles = [] if is_private else None
        
        await session.commit()
    
    return RedirectResponse(url=f"/files/{file_id}", status_code=303)


# ==================== CLOUD STORAGE INTEGRATION ====================

class CloudStorageProvider:
    """Base class for cloud storage providers"""
    pass


class GoogleDriveIntegration(CloudStorageProvider):
    """Google Drive integration"""
    def __init__(self):
        self.provider = "google_drive"
    
    async def upload(self, file_path: str, name: str) -> dict:
        # Placeholder for Google Drive API integration
        return {"external_id": "gdrive_xxx", "url": "https://drive.google.com/xxx"}
    
    async def download(self, external_id: str) -> bytes:
        # Placeholder for Google Drive API integration
        return b""


class YandexDiskIntegration(CloudStorageProvider):
    """Yandex Disk integration"""
    def __init__(self):
        self.provider = "yandex_disk"
    
    async def upload(self, file_path: str, name: str) -> dict:
        # Placeholder for Yandex Disk API integration
        return {"external_id": "yadisk_xxx", "url": "https://disk.yandex.ru/xxx"}
    
    async def download(self, external_id: str) -> bytes:
        # Placeholder for Yandex Disk API integration
        return b""


class DropboxIntegration(CloudStorageProvider):
    """Dropbox integration"""
    def __init__(self):
        self.provider = "dropbox"
    
    async def upload(self, file_path: str, name: str) -> dict:
        # Placeholder for Dropbox API integration
        return {"external_id": "dropbox_xxx", "url": "https://dropbox.com/xxx"}
    
    async def download(self, external_id: str) -> bytes:
        # Placeholder for Dropbox API integration
        return b""


# Cloud storage settings model is in Setting table
@app.get("/settings/cloud-storage", response_class=HTMLResponse)
async def cloud_storage_settings(request: Request):
    """Cloud storage integration settings"""
    async with async_session() as session:
        # Get cloud storage settings
        settings = (await session.execute(
            select(Setting).where(Setting.key.like("cloud_%"))
        )).scalars().all()
        
        settings_dict = {s.key: s.value for s in settings}
    
    return templates.TemplateResponse("settings/cloud_storage.html", {
        "request": request,
        "settings": settings_dict
    })


@app.post("/settings/cloud-storage", response_class=HTMLResponse)
async def save_cloud_storage_settings(
    request: Request,
    provider: str = Form(None),
    google_drive_token: str = Form(None),
    yandex_disk_token: str = Form(None),
    dropbox_token: str = Form(None),
    auto_sync: bool = Form(False)
):
    """Save cloud storage settings"""
    async with async_session() as session:
        settings_to_save = [
            ("cloud_provider", provider or "local"),
            ("cloud_google_drive_token", google_drive_token or ""),
            ("cloud_yandex_disk_token", yandex_disk_token or ""),
            ("cloud_dropbox_token", dropbox_token or ""),
            ("cloud_auto_sync", str(auto_sync).lower())
        ]
        
        for key, value in settings_to_save:
            existing = (await session.execute(
                select(Setting).where(Setting.key == key)
            )).scalar_one_or_none()
            
            if existing:
                existing.value = value
            else:
                setting = Setting(key=key, value=value)
                session.add(setting)
        
        await session.commit()
    
    return RedirectResponse(url="/settings/cloud-storage", status_code=303)


@app.post("/files/{file_id}/sync-cloud", response_class=HTMLResponse)
async def sync_file_to_cloud(request: Request, file_id: int):
    """Sync file to cloud storage"""
    async with async_session() as session:
        file = (await session.execute(
            select(File).where(File.id == file_id)
        )).scalar_one_or_none()
        
        if not file:
            raise HTTPException(404, "Файл не найден")
        
        # Get cloud provider setting
        provider_setting = (await session.execute(
            select(Setting).where(Setting.key == "cloud_provider")
        )).scalar_one_or_none()
        
        provider = provider_setting.value if provider_setting else "local"
        
        # In a real implementation, this would call the actual cloud API
        # For now, we just update the file record with a placeholder
        if provider != "local":
            file.external_id = f"{provider}_{file.id}"
            # In production: actual upload to cloud
        
        await session.commit()
    
    return RedirectResponse(url=f"/files/{file_id}", status_code=303)


# ==================== CALENDAR ====================

@app.get("/calendar", response_class=HTMLResponse)
async def calendar_view(request: Request, month: int = None, year: int = None):
    today = date.today()
    current_month = month or today.month
    current_year = year or today.year
    
    async with async_session() as session:
        # Get events for the month
        start_date = date(current_year, current_month, 1)
        if current_month == 12:
            end_date = date(current_year + 1, 1, 1)
        else:
            end_date = date(current_year, current_month + 1, 1)
        
        events = (await session.execute(
            select(CalendarEvent)
            .options(selectinload(CalendarEvent.client), selectinload(CalendarEvent.deal))
            .where(
                CalendarEvent.start_at >= start_date,
                CalendarEvent.start_at < end_date
            )
            .order_by(CalendarEvent.start_at)
        )).scalars().all()
        
        # Get tasks with due dates
        tasks = (await session.execute(
            select(Task)
            .options(selectinload(Task.client), selectinload(Task.deal))
            .where(
                Task.due_date >= start_date,
                Task.due_date < end_date,
                Task.status != "completed"
            )
            .order_by(Task.due_date)
        )).scalars().all()
    
    # Calculate calendar grid
    import calendar
    cal = calendar.Calendar()
    weeks = list(cal.monthdayscalendar(current_year, current_month))
    
    # Previous/next month navigation
    prev_month = current_month - 1 if current_month > 1 else 12
    prev_year = current_year if current_month > 1 else current_year - 1
    next_month = current_month + 1 if current_month < 12 else 1
    next_year = current_year if current_month < 12 else current_year + 1
    
    return templates.TemplateResponse("calendar/view.html", {
        "request": request,
        "events": events,
        "tasks": tasks,
        "weeks": weeks,
        "current_month": current_month,
        "current_year": current_year,
        "prev_month": prev_month,
        "prev_year": prev_year,
        "next_month": next_month,
        "next_year": next_year,
        "month_name": calendar.month_name[current_month],
        "today": today
    })


@app.get("/calendar/new", response_class=HTMLResponse)
async def new_event_form(request: Request, client_id: int = None, deal_id: int = None):
    async with async_session() as session:
        client = None
        deal = None
        if client_id:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
        if deal_id:
            deal = (await session.execute(
                select(Deal).where(Deal.id == deal_id)
            )).scalar_one_or_none()
        
        # Get all clients and deals for dropdowns
        clients = (await session.execute(
            select(Client).order_by(Client.name)
        )).scalars().all()
        
        deals = (await session.execute(
            select(Deal).options(selectinload(Deal.client)).order_by(Deal.created_at.desc())
        )).scalars().all()
    
    return templates.TemplateResponse("calendar/form.html", {
        "request": request,
        "event": None,
        "client": client,
        "deal": deal,
        "clients": clients,
        "deals": deals
    })


@app.post("/calendar", response_class=HTMLResponse)
async def create_event(
    request: Request,
    title: str = Form(...),
    description: str = Form(None),
    start_at: str = Form(...),
    end_at: str = Form(None),
    is_all_day: bool = Form(False),
    location: str = Form(None),
    is_online: bool = Form(False),
    meeting_url: str = Form(None),
    client_id: int = Form(None),
    deal_id: int = Form(None)
):
    async with async_session() as session:
        event = CalendarEvent(
            title=title,
            description=description,
            start_at=datetime.fromisoformat(start_at),
            end_at=datetime.fromisoformat(end_at) if end_at else None,
            is_all_day=is_all_day,
            location=location,
            is_online=is_online,
            meeting_url=meeting_url,
            client_id=client_id if client_id else None,
            deal_id=deal_id if deal_id else None
        )
        session.add(event)
        await session.commit()
        await session.refresh(event)
    
    return RedirectResponse(url="/calendar", status_code=303)


@app.post("/calendar/{event_id}/delete", response_class=HTMLResponse)
async def delete_event(request: Request, event_id: int):
    async with async_session() as session:
        event = (await session.execute(
            select(CalendarEvent).where(CalendarEvent.id == event_id)
        )).scalar_one_or_none()
        
        if not event:
            raise HTTPException(404, "Событие не найдено")
        
        await session.delete(event)
        await session.commit()
    
    return RedirectResponse(url="/calendar", status_code=303)


@app.get("/calendar/event/{event_id}", response_class=HTMLResponse)
async def event_detail(request: Request, event_id: int):
    """Event detail page"""
    async with async_session() as session:
        event = (await session.execute(
            select(CalendarEvent)
            .options(
                selectinload(CalendarEvent.client),
                selectinload(CalendarEvent.deal)
            )
            .where(CalendarEvent.id == event_id)
        )).scalar_one_or_none()
        
        if not event:
            raise HTTPException(404, "Событие не найдено")
    
    return templates.TemplateResponse("calendar/detail.html", {
        "request": request,
        "event": event
    })


@app.get("/calendar/{event_id}/edit", response_class=HTMLResponse)
async def edit_event_form(request: Request, event_id: int):
    """Edit event form"""
    async with async_session() as session:
        event = (await session.execute(
            select(CalendarEvent).where(CalendarEvent.id == event_id)
        )).scalar_one_or_none()
        
        if not event:
            raise HTTPException(404, "Событие не найдено")
        
        clients = (await session.execute(
            select(Client).order_by(Client.name)
        )).scalars().all()
        
        deals = (await session.execute(
            select(Deal).options(selectinload(Deal.client)).order_by(Deal.created_at.desc())
        )).scalars().all()
    
    return templates.TemplateResponse("calendar/form.html", {
        "request": request,
        "event": event,
        "clients": clients,
        "deals": deals
    })


@app.post("/calendar/{event_id}/edit", response_class=HTMLResponse)
async def update_event(
    request: Request,
    event_id: int,
    title: str = Form(...),
    description: str = Form(None),
    start_at: str = Form(...),
    end_at: str = Form(None),
    is_all_day: bool = Form(False),
    location: str = Form(None),
    is_online: bool = Form(False),
    meeting_url: str = Form(None),
    client_id: int = Form(None),
    deal_id: int = Form(None)
):
    """Update event"""
    async with async_session() as session:
        event = (await session.execute(
            select(CalendarEvent).where(CalendarEvent.id == event_id)
        )).scalar_one_or_none()
        
        if not event:
            raise HTTPException(404, "Событие не найдено")
        
        event.title = title
        event.description = description
        event.start_at = datetime.fromisoformat(start_at)
        event.end_at = datetime.fromisoformat(end_at) if end_at else None
        event.is_all_day = is_all_day
        event.location = location
        event.is_online = is_online
        event.meeting_url = meeting_url
        event.client_id = client_id if client_id else None
        event.deal_id = deal_id if deal_id else None
        
        await session.commit()
    
    return RedirectResponse(url=f"/calendar/event/{event_id}", status_code=303)


@app.get("/calendar/team", response_class=HTMLResponse)
async def team_calendar_view(request: Request, month: int = None, year: int = None):
    """Team calendar view showing all team members' events"""
    today = date.today()
    current_month = month or today.month
    current_year = year or today.year
    
    async with async_session() as session:
        # Get all users
        users = (await session.execute(
            select(User).where(User.is_active == True)
        )).scalars().all()
        
        # Get events for the month (all users)
        start_date = date(current_year, current_month, 1)
        if current_month == 12:
            end_date = date(current_year + 1, 1, 1)
        else:
            end_date = date(current_year, current_month + 1, 1)
        
        events = (await session.execute(
            select(CalendarEvent)
            .options(selectinload(CalendarEvent.client))
            .where(
                CalendarEvent.start_at >= start_date,
                CalendarEvent.start_at < end_date
            )
            .order_by(CalendarEvent.start_at)
        )).scalars().all()
    
    import calendar
    cal = calendar.Calendar()
    weeks = list(cal.monthdayscalendar(current_year, current_month))
    
    return templates.TemplateResponse("calendar/team.html", {
        "request": request,
        "events": events,
        "users": users,
        "weeks": weeks,
        "current_month": current_month,
        "current_year": current_year,
        "month_name": calendar.month_name[current_month]
    })


# ==================== CALENDAR SYNC ====================

class GoogleCalendarSync:
    """Google Calendar synchronization"""
    def __init__(self):
        self.provider = "google"
    
    async def sync_event(self, event: CalendarEvent, access_token: str) -> dict:
        """Sync event to Google Calendar"""
        # Placeholder for Google Calendar API integration
        # In production, use google-api-python-client
        return {
            "external_id": f"google_{event.id}",
            "url": f"https://calendar.google.com/event?eid={event.id}"
        }
    
    async def get_events(self, access_token: str, start: datetime, end: datetime) -> list:
        """Get events from Google Calendar"""
        # Placeholder for Google Calendar API integration
        return []


class OutlookCalendarSync:
    """Outlook/Microsoft 365 Calendar synchronization"""
    def __init__(self):
        self.provider = "outlook"
    
    async def sync_event(self, event: CalendarEvent, access_token: str) -> dict:
        """Sync event to Outlook Calendar"""
        # Placeholder for Microsoft Graph API integration
        return {
            "external_id": f"outlook_{event.id}",
            "url": f"https://outlook.live.com/calendar/item/{event.id}"
        }
    
    async def get_events(self, access_token: str, start: datetime, end: datetime) -> list:
        """Get events from Outlook Calendar"""
        # Placeholder for Microsoft Graph API integration
        return []


@app.get("/settings/calendar-sync", response_class=HTMLResponse)
async def calendar_sync_settings(request: Request):
    """Calendar synchronization settings"""
    async with async_session() as session:
        settings = (await session.execute(
            select(Setting).where(Setting.key.like("calendar_%"))
        )).scalars().all()
        
        settings_dict = {s.key: s.value for s in settings}
    
    return templates.TemplateResponse("settings/calendar_sync.html", {
        "request": request,
        "settings": settings_dict
    })


@app.post("/settings/calendar-sync", response_class=HTMLResponse)
async def save_calendar_sync_settings(
    request: Request,
    google_enabled: bool = Form(False),
    google_token: str = Form(None),
    outlook_enabled: bool = Form(False),
    outlook_token: str = Form(None),
    auto_sync: bool = Form(False),
    sync_direction: str = Form("both")
):
    """Save calendar sync settings"""
    async with async_session() as session:
        settings_to_save = [
            ("calendar_google_enabled", str(google_enabled).lower()),
            ("calendar_google_token", google_token or ""),
            ("calendar_outlook_enabled", str(outlook_enabled).lower()),
            ("calendar_outlook_token", outlook_token or ""),
            ("calendar_auto_sync", str(auto_sync).lower()),
            ("calendar_sync_direction", sync_direction)
        ]
        
        for key, value in settings_to_save:
            existing = (await session.execute(
                select(Setting).where(Setting.key == key)
            )).scalar_one_or_none()
            
            if existing:
                existing.value = value
            else:
                setting = Setting(key=key, value=value)
                session.add(setting)
        
        await session.commit()
    
    return RedirectResponse(url="/settings/calendar-sync", status_code=303)


@app.post("/calendar/{event_id}/sync", response_class=HTMLResponse)
async def sync_event_to_external(request: Request, event_id: int):
    """Sync event to external calendar"""
    async with async_session() as session:
        event = (await session.execute(
            select(CalendarEvent).where(CalendarEvent.id == event_id)
        )).scalar_one_or_none()
        
        if not event:
            raise HTTPException(404, "Событие не найдено")
        
        # Get sync settings
        google_enabled = (await session.execute(
            select(Setting).where(Setting.key == "calendar_google_enabled")
        )).scalar_one_or_none()
        
        outlook_enabled = (await session.execute(
            select(Setting).where(Setting.key == "calendar_outlook_enabled")
        )).scalar_one_or_none()
        
        # Sync to enabled providers
        if google_enabled and google_enabled.value == "true":
            sync = GoogleCalendarSync()
            # In production: get actual token and sync
            event.external_provider = "google"
        
        if outlook_enabled and outlook_enabled.value == "true":
            sync = OutlookCalendarSync()
            # In production: get actual token and sync
            if not event.external_provider:
                event.external_provider = "outlook"
        
        await session.commit()
    
    return RedirectResponse(url=f"/calendar/event/{event_id}", status_code=303)


# ==================== SLOT BOOKING ====================

@app.get("/calendar/slots", response_class=HTMLResponse)
async def available_slots(request: Request, date_str: str = None):
    """View available booking slots"""
    selected_date = datetime.strptime(date_str, "%Y-%m-%d").date() if date_str else date.today()
    
    async with async_session() as session:
        # Get all events for the date
        day_start = datetime.combine(selected_date, datetime.min.time())
        day_end = datetime.combine(selected_date, datetime.max.time())
        
        events = (await session.execute(
            select(CalendarEvent)
            .where(
                CalendarEvent.start_at >= day_start,
                CalendarEvent.start_at <= day_end
            )
            .order_by(CalendarEvent.start_at)
        )).scalars().all()
        
        # Generate available slots (9 AM to 6 PM, 30 min slots)
        booked_times = set()
        for event in events:
            if event.start_at:
                booked_times.add(event.start_at.strftime("%H:%M"))
        
        available_slots = []
        for hour in range(9, 18):
            for minute in [0, 30]:
                time_str = f"{hour:02d}:{minute:02d}"
                if time_str not in booked_times:
                    available_slots.append({
                        "time": time_str,
                        "display": f"{hour:02d}:{minute:02d}",
                        "datetime": datetime.combine(selected_date, datetime.min.time().replace(hour=hour, minute=minute))
                    })
    
    return templates.TemplateResponse("calendar/slots.html", {
        "request": request,
        "selected_date": selected_date,
        "available_slots": available_slots,
        "events": events
    })


@app.post("/calendar/book-slot", response_class=HTMLResponse)
async def book_slot(
    request: Request,
    date_str: str = Form(...),
    time_str: str = Form(...),
    title: str = Form(...),
    client_id: int = Form(None),
    description: str = Form(None)
):
    """Book a time slot"""
    async with async_session() as session:
        # Parse date and time
        selected_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        hour, minute = map(int, time_str.split(":"))
        start_at = datetime.combine(selected_date, datetime.min.time().replace(hour=hour, minute=minute))
        end_at = start_at + timedelta(minutes=30)
        
        # Create event
        event = CalendarEvent(
            title=title,
            description=description,
            start_at=start_at,
            end_at=end_at,
            client_id=client_id if client_id else None
        )
        session.add(event)
        await session.commit()
        await session.refresh(event)
    
    return RedirectResponse(url=f"/calendar/event/{event.id}", status_code=303)


@app.get("/calendar/slots/week", response_class=HTMLResponse)
async def week_slots_view(request: Request, date_str: str = None):
    """View available slots for a week"""
    selected_date = datetime.strptime(date_str, "%Y-%m-%d").date() if date_str else date.today()
    
    # Get start of week (Monday)
    week_start = selected_date - timedelta(days=selected_date.weekday())
    week_end = week_start + timedelta(days=7)
    
    async with async_session() as session:
        # Get all events for the week
        events = (await session.execute(
            select(CalendarEvent)
            .where(
                CalendarEvent.start_at >= datetime.combine(week_start, datetime.min.time()),
                CalendarEvent.start_at < datetime.combine(week_end, datetime.min.time())
            )
            .order_by(CalendarEvent.start_at)
        )).scalars().all()
        
        # Build schedule grid
        schedule = {}
        for event in events:
            day = event.start_at.date()
            time_key = event.start_at.strftime("%H:%M")
            if day not in schedule:
                schedule[day] = {}
            schedule[day][time_key] = event
    
    # Generate time slots
    time_slots = []
    for hour in range(9, 18):
        for minute in [0, 30]:
            time_slots.append(f"{hour:02d}:{minute:02d}")
    
    # Generate week days
    week_days = []
    for i in range(7):
        day = week_start + timedelta(days=i)
        week_days.append({
            "date": day,
            "display": day.strftime("%d.%m"),
            "weekday": day.strftime("%a")
        })
    
    return templates.TemplateResponse("calendar/week_slots.html", {
        "request": request,
        "week_start": week_start,
        "week_days": week_days,
        "time_slots": time_slots,
        "schedule": schedule
    })


# ==================== INTEGRATIONS ====================

@app.get("/integrations", response_class=HTMLResponse)
async def integrations_list(request: Request):
    """List all integrations"""
    async with async_session() as session:
        integrations = (await session.execute(
            select(Integration).order_by(Integration.integration_type, Integration.name)
        )).scalars().all()
        
        # Group by type
        grouped = {}
        for integration in integrations:
            if integration.integration_type not in grouped:
                grouped[integration.integration_type] = []
            grouped[integration.integration_type].append(integration)
    
    return templates.TemplateResponse("integrations/list.html", {
        "request": request,
        "integrations": integrations,
        "grouped": grouped
    })


@app.get("/integrations/new", response_class=HTMLResponse)
async def new_integration_form(request: Request, integration_type: str = None):
    """New integration form"""
    return templates.TemplateResponse("integrations/form.html", {
        "request": request,
        "integration": None,
        "integration_type": integration_type
    })


@app.post("/integrations", response_class=HTMLResponse)
async def create_integration(
    request: Request,
    name: str = Form(...),
    integration_type: str = Form(...),
    config: str = Form("{}"),
    is_active: bool = Form(True)
):
    """Create integration"""
    async with async_session() as session:
        integration = Integration(
            name=name,
            integration_type=integration_type,
            config=json.loads(config) if config else {},
            is_active=is_active
        )
        session.add(integration)
        await session.commit()
        await session.refresh(integration)
    
    return RedirectResponse(url=f"/integrations/{integration.id}", status_code=303)


@app.get("/integrations/{integration_id}", response_class=HTMLResponse)
async def integration_detail(request: Request, integration_id: int):
    """Integration detail page"""
    async with async_session() as session:
        integration = (await session.execute(
            select(Integration).where(Integration.id == integration_id)
        )).scalar_one_or_none()
        
        if not integration:
            raise HTTPException(404, "Интеграция не найдена")
    
    return templates.TemplateResponse("integrations/detail.html", {
        "request": request,
        "integration": integration
    })


@app.get("/integrations/{integration_id}/edit", response_class=HTMLResponse)
async def edit_integration_form(request: Request, integration_id: int):
    """Edit integration form"""
    async with async_session() as session:
        integration = (await session.execute(
            select(Integration).where(Integration.id == integration_id)
        )).scalar_one_or_none()
        
        if not integration:
            raise HTTPException(404, "Интеграция не найдена")
    
    return templates.TemplateResponse("integrations/form.html", {
        "request": request,
        "integration": integration,
        "integration_type": integration.integration_type
    })


@app.post("/integrations/{integration_id}/edit", response_class=HTMLResponse)
async def update_integration(
    request: Request,
    integration_id: int,
    name: str = Form(...),
    config: str = Form("{}"),
    is_active: bool = Form(True)
):
    """Update integration"""
    async with async_session() as session:
        integration = (await session.execute(
            select(Integration).where(Integration.id == integration_id)
        )).scalar_one_or_none()
        
        if not integration:
            raise HTTPException(404, "Интеграция не найдена")
        
        integration.name = name
        integration.config = json.loads(config) if config else {}
        integration.is_active = is_active
        
        await session.commit()
    
    return RedirectResponse(url=f"/integrations/{integration_id}", status_code=303)


@app.post("/integrations/{integration_id}/delete", response_class=HTMLResponse)
async def delete_integration(request: Request, integration_id: int):
    """Delete integration"""
    async with async_session() as session:
        integration = (await session.execute(
            select(Integration).where(Integration.id == integration_id)
        )).scalar_one_or_none()
        
        if not integration:
            raise HTTPException(404, "Интеграция не найдена")
        
        await session.delete(integration)
        await session.commit()
    
    return RedirectResponse(url="/integrations", status_code=303)


@app.post("/integrations/{integration_id}/sync", response_class=HTMLResponse)
async def sync_integration(request: Request, integration_id: int):
    """Trigger integration sync"""
    async with async_session() as session:
        integration = (await session.execute(
            select(Integration).where(Integration.id == integration_id)
        )).scalar_one_or_none()
        
        if not integration:
            raise HTTPException(404, "Интеграция не найдена")
        
        # Update last_sync timestamp
        integration.last_sync = datetime.now()
        await session.commit()
    
    return RedirectResponse(url=f"/integrations/{integration_id}", status_code=303)


# ==================== WEBHOOKS ====================

@app.get("/webhooks", response_class=HTMLResponse)
async def webhooks_list(request: Request):
    """List all webhooks"""
    async with async_session() as session:
        webhooks = (await session.execute(
            select(Webhook).order_by(Webhook.created_at.desc())
        )).scalars().all()
    
    return templates.TemplateResponse("integrations/webhooks.html", {
        "request": request,
        "webhooks": webhooks
    })


@app.get("/webhooks/new", response_class=HTMLResponse)
async def new_webhook_form(request: Request):
    """New webhook form"""
    return templates.TemplateResponse("integrations/webhook_form.html", {
        "request": request,
        "webhook": None
    })


@app.post("/webhooks", response_class=HTMLResponse)
async def create_webhook(
    request: Request,
    name: str = Form(...),
    url: str = Form(...),
    events: str = Form("[]"),
    secret: str = Form(None),
    is_active: bool = Form(True)
):
    """Create webhook"""
    async with async_session() as session:
        webhook = Webhook(
            name=name,
            url=url,
            events=json.loads(events) if events else [],
            secret=secret,
            is_active=is_active
        )
        session.add(webhook)
        await session.commit()
        await session.refresh(webhook)
    
    return RedirectResponse(url=f"/webhooks/{webhook.id}", status_code=303)


@app.get("/webhooks/{webhook_id}", response_class=HTMLResponse)
async def webhook_detail(request: Request, webhook_id: int):
    """Webhook detail page"""
    async with async_session() as session:
        webhook = (await session.execute(
            select(Webhook).where(Webhook.id == webhook_id)
        )).scalar_one_or_none()
        
        if not webhook:
            raise HTTPException(404, "Webhook не найден")
    
    return templates.TemplateResponse("integrations/webhook_detail.html", {
        "request": request,
        "webhook": webhook
    })


@app.get("/webhooks/{webhook_id}/edit", response_class=HTMLResponse)
async def edit_webhook_form(request: Request, webhook_id: int):
    """Edit webhook form"""
    async with async_session() as session:
        webhook = (await session.execute(
            select(Webhook).where(Webhook.id == webhook_id)
        )).scalar_one_or_none()
        
        if not webhook:
            raise HTTPException(404, "Webhook не найден")
    
    return templates.TemplateResponse("integrations/webhook_form.html", {
        "request": request,
        "webhook": webhook
    })


@app.post("/webhooks/{webhook_id}/edit", response_class=HTMLResponse)
async def update_webhook(
    request: Request,
    webhook_id: int,
    name: str = Form(...),
    url: str = Form(...),
    events: str = Form("[]"),
    secret: str = Form(None),
    is_active: bool = Form(True)
):
    """Update webhook"""
    async with async_session() as session:
        webhook = (await session.execute(
            select(Webhook).where(Webhook.id == webhook_id)
        )).scalar_one_or_none()
        
        if not webhook:
            raise HTTPException(404, "Webhook не найден")
        
        webhook.name = name
        webhook.url = url
        webhook.events = json.loads(events) if events else []
        webhook.secret = secret
        webhook.is_active = is_active
        
        await session.commit()
    
    return RedirectResponse(url=f"/webhooks/{webhook_id}", status_code=303)


@app.post("/webhooks/{webhook_id}/delete", response_class=HTMLResponse)
async def delete_webhook(request: Request, webhook_id: int):
    """Delete webhook"""
    async with async_session() as session:
        webhook = (await session.execute(
            select(Webhook).where(Webhook.id == webhook_id)
        )).scalar_one_or_none()
        
        if not webhook:
            raise HTTPException(404, "Webhook не найден")
        
        await session.delete(webhook)
        await session.commit()
    
    return RedirectResponse(url="/webhooks", status_code=303)


@app.post("/webhooks/{webhook_id}/test", response_class=HTMLResponse)
async def test_webhook(request: Request, webhook_id: int):
    """Test webhook"""
    async with async_session() as session:
        webhook = (await session.execute(
            select(Webhook).where(Webhook.id == webhook_id)
        )).scalar_one_or_none()
        
        if not webhook:
            raise HTTPException(404, "Webhook не найден")
        
        # Update last_triggered timestamp
        webhook.last_triggered = datetime.now()
        await session.commit()
    
    return RedirectResponse(url=f"/webhooks/{webhook_id}", status_code=303)


# ==================== API ====================

@app.get("/api/clients", response_class=JSONResponse)
async def api_clients_list(
    search: str = None,
    client_type: str = None,
    status: str = None,
    limit: int = 50,
    offset: int = 0
):
    """API: List clients"""
    async with async_session() as session:
        query = select(Client)
        
        if search:
            query = query.where(
                or_(
                    Client.name.ilike(f"%{search}%"),
                    Client.email.ilike(f"%{search}%"),
                    Client.phone.ilike(f"%{search}%")
                )
            )
        
        if client_type:
            query = query.where(Client.client_type == client_type)
        
        if status:
            query = query.where(Client.status == status)
        
        query = query.offset(offset).limit(limit)
        
        clients = (await session.execute(
            query.options(selectinload(Client.deals))
        )).scalars().all()
        
        return {
            "clients": [
                {
                    "id": c.id,
                    "name": c.name,
                    "email": c.email,
                    "phone": c.phone,
                    "client_type": c.client_type,
                    "status": c.status,
                    "created_at": c.created_at.isoformat() if c.created_at else None
                }
                for c in clients
            ]
        }


@app.get("/api/clients/{client_id}", response_class=JSONResponse)
async def api_client_detail(client_id: int):
    """API: Get client by ID"""
    async with async_session() as session:
        client = (await session.execute(
            select(Client)
            .options(selectinload(Client.deals), selectinload(Client.tasks))
            .where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
        
        return {
            "id": client.id,
            "name": client.name,
            "email": client.email,
            "phone": client.phone,
            "client_type": client.client_type,
            "status": client.status,
            "created_at": client.created_at.isoformat() if client.created_at else None,
            "deals": [
                {"id": d.id, "title": d.title, "amount": float(d.amount) if d.amount else 0, "status": d.status}
                for d in client.deals
            ],
            "tasks": [
                {"id": t.id, "title": t.title, "status": t.status, "due_date": t.due_date.isoformat() if t.due_date else None}
                for t in client.tasks
            ]
        }


@app.post("/api/clients", response_class=JSONResponse)
async def api_create_client(request: Request):
    """API: Create client"""
    data = await request.json()
    
    async with async_session() as session:
        client = Client(
            name=data.get("name"),
            email=data.get("email"),
            phone=data.get("phone"),
            client_type=data.get("client_type", "lead"),
            status=data.get("status", "new"),
            company_name=data.get("company_name"),
            position=data.get("position"),
            source=data.get("source"),
            notes=data.get("notes")
        )
        session.add(client)
        await session.commit()
        await session.refresh(client)
        
        return {"id": client.id, "message": "Клиент создан"}


@app.get("/api/deals", response_class=JSONResponse)
async def api_deals_list(
    search: str = None,
    status: str = None,
    pipeline_id: int = None,
    limit: int = 50,
    offset: int = 0
):
    """API: List deals"""
    async with async_session() as session:
        query = select(Deal)
        
        if search:
            query = query.where(Deal.title.ilike(f"%{search}%"))
        
        if status:
            query = query.where(Deal.status == status)
        
        if pipeline_id:
            query = query.where(Deal.pipeline_id == pipeline_id)
        
        query = query.offset(offset).limit(limit)
        
        deals = (await session.execute(
            query.options(selectinload(Deal.client), selectinload(Deal.stage))
        )).scalars().all()
        
        return {
            "deals": [
                {
                    "id": d.id,
                    "title": d.title,
                    "amount": float(d.amount) if d.amount else 0,
                    "status": d.status,
                    "client": {"id": d.client.id, "name": d.client.name} if d.client else None,
                    "stage": {"id": d.stage.id, "name": d.stage.name} if d.stage else None,
                    "created_at": d.created_at.isoformat() if d.created_at else None
                }
                for d in deals
            ]
        }


@app.get("/api/deals/{deal_id}", response_class=JSONResponse)
async def api_deal_detail(deal_id: int):
    """API: Get deal by ID"""
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal)
            .options(selectinload(Deal.client), selectinload(Deal.stage), selectinload(Deal.tasks))
            .where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            raise HTTPException(404, "Сделка не найдена")
        
        return {
            "id": deal.id,
            "title": deal.title,
            "amount": float(deal.amount) if deal.amount else 0,
            "status": deal.status,
            "client": {"id": deal.client.id, "name": deal.client.name} if deal.client else None,
            "stage": {"id": deal.stage.id, "name": deal.stage.name} if deal.stage else None,
            "tasks": [
                {"id": t.id, "title": t.title, "status": t.status}
                for t in deal.tasks
            ],
            "created_at": deal.created_at.isoformat() if deal.created_at else None
        }


@app.get("/api/tasks", response_class=JSONResponse)
async def api_tasks_list(
    search: str = None,
    status: str = None,
    assignee_id: int = None,
    limit: int = 50,
    offset: int = 0
):
    """API: List tasks"""
    async with async_session() as session:
        query = select(Task)
        
        if search:
            query = query.where(Task.title.ilike(f"%{search}%"))
        
        if status:
            query = query.where(Task.status == status)
        
        if assignee_id:
            query = query.where(Task.assignee_id == assignee_id)
        
        query = query.offset(offset).limit(limit)
        
        tasks = (await session.execute(
            query.options(selectinload(Task.client), selectinload(Task.deal))
        )).scalars().all()
        
        return {
            "tasks": [
                {
                    "id": t.id,
                    "title": t.title,
                    "status": t.status,
                    "priority": t.priority,
                    "due_date": t.due_date.isoformat() if t.due_date else None,
                    "client": {"id": t.client.id, "name": t.client.name} if t.client else None,
                    "deal": {"id": t.deal.id, "title": t.deal.title} if t.deal else None
                }
                for t in tasks
            ]
        }


# ==================== ANALYTICS ====================

@app.get("/analytics", response_class=HTMLResponse)
async def analytics_dashboard(request: Request):
    async with async_session() as session:
        now = datetime.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        # ==================== SALES ANALYTICS ====================
        
        # Total revenue (won deals)
        total_revenue = await session.scalar(
            select(func.coalesce(func.sum(Deal.amount), 0))
            .where(Deal.status == "won")
        )
        
        # Monthly revenue
        monthly_revenue = await session.scalar(
            select(func.coalesce(func.sum(Deal.amount), 0))
            .where(Deal.status == "won")
            .where(Deal.actual_close_date >= month_start)
        )
        
        deals_won_count = await session.scalar(
            select(func.count(Deal.id)).where(Deal.status == "won")
        )
        
        # Average deal size
        avg_deal = await session.scalar(
            select(func.coalesce(func.avg(Deal.amount), 0))
            .where(Deal.status == "won")
        )
        
        # ==================== CONVERSION BY STAGES ====================
        
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
        
        conversion_data = []
        total_deals_in_pipeline = 0
        for pipeline in pipelines:
            for stage in pipeline.stages:
                count = await session.scalar(
                    select(func.count(Deal.id)).where(Deal.stage_id == stage.id)
                )
                total_deals_in_pipeline += count or 0
                conversion_data.append({
                    "pipeline": pipeline.name,
                    "stage": stage.name,
                    "count": count or 0,
                    "probability": stage.probability
                })
        
        # ==================== DEAL CYCLE LENGTH ====================
        
        # Calculate average deal cycle (days from created to actual_close_date)
        won_deals = (await session.execute(
            select(Deal)
            .where(Deal.status == "won")
            .where(Deal.actual_close_date != None)
        )).scalars().all()
        
        total_cycle_days = 0
        cycle_count = 0
        for deal in won_deals:
            if deal.actual_close_date and deal.created_at:
                cycle_days = (deal.actual_close_date - deal.created_at.date()).days
                total_cycle_days += cycle_days
                cycle_count += 1
        
        avg_deal_cycle = round(total_cycle_days / cycle_count, 1) if cycle_count > 0 else 0
        
        # ==================== FUNNEL BY MANAGERS ====================
        
        managers = (await session.execute(select(User))).scalars().all()
        
        funnel_by_managers = []
        for manager in managers:
            manager_deals = (await session.execute(
                select(Deal).where(Deal.responsible_id == manager.id)
            )).scalars().all()
            
            won = len([d for d in manager_deals if d.status == "won"])
            lost = len([d for d in manager_deals if d.status == "lost"])
            open_deals = len([d for d in manager_deals if d.status == "open"])
            total = len(manager_deals)
            
            revenue = sum(float(d.amount or 0) for d in manager_deals if d.status == "won")
            
            funnel_by_managers.append({
                "id": manager.id,
                "name": manager.full_name,
                "total": total,
                "won": won,
                "lost": lost,
                "open": open_deals,
                "revenue": revenue,
                "conversion_rate": round(won / total * 100, 1) if total > 0 else 0
            })
        
        # Sort by revenue descending
        funnel_by_managers.sort(key=lambda x: x["revenue"], reverse=True)
        
        # ==================== MANAGEMENT ANALYTICS ====================
        
        # CAC (Customer Acquisition Cost) - simplified calculation
        # Total marketing costs / number of new clients
        total_clients = await session.scalar(select(func.count(Client.id)))
        new_clients_this_month = await session.scalar(
            select(func.count(Client.id))
            .where(Client.created_at >= month_start)
        )
        
        # LTV (Lifetime Value) - average revenue per client
        total_revenue_float = float(total_revenue or 0)
        ltv = total_revenue_float / total_clients if total_clients > 0 else 0
        
        # Margin analysis
        total_margin = await session.scalar(
            select(func.coalesce(func.sum(Deal.margin), 0))
            .where(Deal.status == "won")
        )
        avg_margin_percent = await session.scalar(
            select(func.coalesce(func.avg(Deal.margin_percent), 0))
            .where(Deal.status == "won")
            .where(Deal.margin_percent != None)
        )
        
        # ==================== LEAD SOURCES ====================
        
        sources = (await session.execute(
            select(Client.source, func.count(Client.id))
            .where(Client.source != None)
            .group_by(Client.source)
        )).all()
        
        # Revenue by source
        source_revenue = {}
        for source, _ in sources:
            revenue = await session.scalar(
                select(func.coalesce(func.sum(Deal.amount), 0))
                .join(Client, Deal.client_id == Client.id)
                .where(Client.source == source)
                .where(Deal.status == "won")
            )
            source_revenue[source] = float(revenue or 0)
        
        # ==================== PLAN FULFILLMENT ====================
        
        # Monthly target (simplified - could be from settings)
        monthly_target = 1000000  # 1M default target
        plan_fulfillment = round(float(monthly_revenue or 0) / monthly_target * 100, 1)
        
        # ==================== TASKS ====================
        
        tasks_completed = await session.scalar(
            select(func.count(Task.id)).where(Task.status == "completed")
        )
        tasks_overdue = await session.scalar(
            select(func.count(Task.id))
            .where(Task.status != "completed", Task.due_date < datetime.now())
        )
    
    return templates.TemplateResponse("analytics/dashboard.html", {
        "request": request,
        "metrics": {
            "total_revenue": total_revenue or 0,
            "monthly_revenue": monthly_revenue or 0,
            "deals_won_count": deals_won_count or 0,
            "avg_deal": avg_deal or 0,
            "avg_deal_cycle": avg_deal_cycle,
            "tasks_completed": tasks_completed or 0,
            "tasks_overdue": tasks_overdue or 0,
            "total_clients": total_clients or 0,
            "new_clients_this_month": new_clients_this_month or 0,
            "ltv": ltv,
            "total_margin": total_margin or 0,
            "avg_margin_percent": avg_margin_percent or 0,
            "monthly_target": monthly_target,
            "plan_fulfillment": plan_fulfillment
        },
        "conversion_data": conversion_data,
        "sources": sources,
        "source_revenue": source_revenue,
        "funnel_by_managers": funnel_by_managers
    })


# ==================== SETTINGS ====================

@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    async with async_session() as session:
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
        
        custom_fields = (await session.execute(
            select(CustomField).order_by(CustomField.entity_type, CustomField.sort_order)
        )).scalars().all()
        
        automations = (await session.execute(
            select(Automation).order_by(Automation.name)
        )).scalars().all()
        
        integrations = (await session.execute(
            select(Integration).order_by(Integration.name)
        )).scalars().all()
    
    return templates.TemplateResponse("settings/index.html", {
        "request": request,
        "pipelines": pipelines,
        "custom_fields": custom_fields,
        "automations": automations,
        "integrations": integrations
    })


@app.get("/settings/pipelines", response_class=HTMLResponse)
async def pipelines_settings(request: Request):
    async with async_session() as session:
        pipelines = (await session.execute(
            select(Pipeline).options(selectinload(Pipeline.stages))
        )).scalars().all()
    
    return templates.TemplateResponse("settings/pipelines.html", {
        "request": request,
        "pipelines": pipelines
    })


@app.post("/settings/pipelines", response_class=HTMLResponse)
async def create_pipeline(
    request: Request,
    name: str = Form(...),
    description: str = Form(None)
):
    async with async_session() as session:
        pipeline = Pipeline(name=name, description=description)
        session.add(pipeline)
        await session.commit()
    
    return RedirectResponse(url="/settings/pipelines", status_code=303)


@app.post("/settings/pipelines/{pipeline_id}/stages", response_class=HTMLResponse)
async def create_stage(
    request: Request,
    pipeline_id: int,
    name: str = Form(...),
    probability: int = Form(0),
    color: str = Form("#6366f1"),
    sla_hours: int = Form(None)
):
    async with async_session() as session:
        # Get max sort order
        max_order = await session.scalar(
            select(func.coalesce(func.max(PipelineStage.sort_order), 0))
            .where(PipelineStage.pipeline_id == pipeline_id)
        )
        
        stage = PipelineStage(
            pipeline_id=pipeline_id,
            name=name,
            probability=probability,
            color=color,
            sla_hours=sla_hours,
            sort_order=(max_order or 0) + 1
        )
        session.add(stage)
        await session.commit()
    
    return RedirectResponse(url="/settings/pipelines", status_code=303)


@app.get("/settings/custom-fields", response_class=HTMLResponse)
async def custom_fields_settings(request: Request):
    async with async_session() as session:
        custom_fields = (await session.execute(
            select(CustomField).order_by(CustomField.entity_type, CustomField.sort_order)
        )).scalars().all()
    
    return templates.TemplateResponse("settings/custom_fields.html", {
        "request": request,
        "custom_fields": custom_fields
    })


@app.post("/settings/custom-fields", response_class=HTMLResponse)
async def create_custom_field(
    request: Request,
    entity_type: str = Form(...),
    name: str = Form(...),
    field_type: str = Form(...),
    options: str = Form(None),
    is_required: bool = Form(False)
):
    async with async_session() as session:
        field = CustomField(
            entity_type=entity_type,
            name=name,
            field_type=field_type,
            options=json.loads(options) if options else None,
            is_required=is_required
        )
        session.add(field)
        await session.commit()
    
    return RedirectResponse(url="/settings/custom-fields", status_code=303)


@app.get("/settings/automations", response_class=HTMLResponse)
async def automations_settings(request: Request):
    async with async_session() as session:
        automations = (await session.execute(
            select(Automation).order_by(Automation.name)
        )).scalars().all()
    
    return templates.TemplateResponse("settings/automations.html", {
        "request": request,
        "automations": automations
    })


@app.post("/settings/automations", response_class=HTMLResponse)
async def create_automation(
    request: Request,
    name: str = Form(...),
    description: str = Form(None),
    trigger_type: str = Form(...),
    trigger_config: str = Form(None),
    actions: str = Form(...),
    conditions: str = Form(None),
    delay_minutes: int = Form(0)
):
    async with async_session() as session:
        automation = Automation(
            name=name,
            description=description,
            trigger_type=trigger_type,
            trigger_config=json.loads(trigger_config) if trigger_config else None,
            actions=json.loads(actions),
            conditions=json.loads(conditions) if conditions else None,
            delay_minutes=delay_minutes
        )
        session.add(automation)
        await session.commit()
    
    return RedirectResponse(url="/settings/automations", status_code=303)


# ==================== API ENDPOINTS ====================

@app.get("/api/clients/search")
async def api_clients_search(q: str):
    async with async_session() as session:
        clients = (await session.execute(
            select(Client)
            .where(
                or_(
                    Client.full_name.ilike(f"%{q}%"),
                    Client.company_name.ilike(f"%{q}%"),
                    Client.phone.ilike(f"%{q}%"),
                    Client.email.ilike(f"%{q}%")
                )
            )
            .limit(10)
        )).scalars().all()
        
        return [
            {
                "id": c.id,
                "name": c.full_name or c.company_name,
                "type": c.client_type,
                "phone": c.phone,
                "email": c.email
            }
            for c in clients
        ]


@app.get("/api/deals/search")
async def api_deals_search(q: str):
    async with async_session() as session:
        deals = (await session.execute(
            select(Deal)
            .where(Deal.title.ilike(f"%{q}%"))
            .limit(10)
        )).scalars().all()
        
        return [
            {
                "id": d.id,
                "title": d.title,
                "amount": float(d.amount) if d.amount else 0,
                "status": d.status
            }
            for d in deals
        ]


@app.post("/api/deals/{deal_id}/stage")
async def api_update_deal_stage(deal_id: int, stage_id: int):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal).where(Deal.id == deal_id)
        )).scalar_one_or_none()
        
        if not deal:
            return {"success": False, "error": "Deal not found"}
        
        deal.stage_id = stage_id
        deal.updated_at = datetime.now()
        await session.commit()
        
        return {"success": True}


# ==================== HTMX PARTIALS ====================

@app.get("/partials/client-card/{client_id}", response_class=HTMLResponse)
async def partial_client_card(request: Request, client_id: int):
    async with async_session() as session:
        client = (await session.execute(
            select(Client).where(Client.id == client_id)
        )).scalar_one_or_none()
    
    return templates.TemplateResponse("clients/partials/card.html", {
        "request": request,
        "client": client
    })


@app.get("/partials/deal-card/{deal_id}", response_class=HTMLResponse)
async def partial_deal_card(request: Request, deal_id: int):
    async with async_session() as session:
        deal = (await session.execute(
            select(Deal)
            .options(selectinload(Deal.client), selectinload(Deal.stage))
            .where(Deal.id == deal_id)
        )).scalar_one_or_none()
    
    return templates.TemplateResponse("deals/partials/card.html", {
        "request": request,
        "deal": deal
    })


@app.get("/partials/task-card/{task_id}", response_class=HTMLResponse)
async def partial_task_card(request: Request, task_id: int):
    async with async_session() as session:
        task = (await session.execute(
            select(Task)
            .options(selectinload(Task.client), selectinload(Task.deal))
            .where(Task.id == task_id)
        )).scalar_one_or_none()
    
    return templates.TemplateResponse("tasks/partials/card.html", {
        "request": request,
        "task": task
    })


# ==================== CLIENT DEDUPLICATION ====================

@app.get("/clients/duplicates", response_class=HTMLResponse)
async def find_duplicates_page(request: Request):
    """Page for finding and managing duplicate clients"""
    async with async_session() as session:
        # Find potential duplicates by email
        email_duplicates = (await session.execute(
            select(Client.email, func.count(Client.id).label('count'))
            .where(Client.email != None, Client.email != '')
            .group_by(Client.email)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by phone
        phone_duplicates = (await session.execute(
            select(Client.phone, func.count(Client.id).label('count'))
            .where(Client.phone != None, Client.phone != '')
            .group_by(Client.phone)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Find potential duplicates by name
        name_duplicates = (await session.execute(
            select(Client.full_name, func.count(Client.id).label('count'))
            .where(Client.full_name != None, Client.full_name != '')
            .group_by(Client.full_name)
            .having(func.count(Client.id) > 1)
        )).all()
        
        # Get duplicate groups with details
        duplicate_groups = []
        
        for email, count in email_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.email == email)
            )).scalars().all()
            duplicate_groups.append({
                "type": "email",
                "value": email,
                "count": count,
                "clients": clients
            })
        
        for phone, count in phone_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.phone == phone)
            )).scalars().all()
            duplicate_groups.append({
                "type": "phone",
                "value": phone,
                "count": count,
                "clients": clients
            })
        
        for name, count in name_duplicates:
            clients = (await session.execute(
                select(Client).where(Client.full_name == name)
            )).scalars().all()
            # Only add if not already in email/phone duplicates
            client_ids = [c.id for c in clients]
            if not any(c.id in client_ids for group in duplicate_groups for c in group['clients']):
                duplicate_groups.append({
                    "type": "name",
                    "value": name,
                    "count": count,
                    "clients": clients
                })
    
    return templates.TemplateResponse("clients/duplicates.html", {
        "request": request,
        "duplicate_groups": duplicate_groups
    })


@app.get("/api/clients/duplicates")
async def api_find_duplicates():
    """API endpoint to find duplicate clients"""
    async with async_session() as session:
        duplicates = []
        
        # Find by email
        email_dups = (await session.execute(
            select(Client.email, func.count(Client.id).label('count'))
            .where(Client.email != None, Client.email != '')
            .group_by(Client.email)
            .having(func.count(Client.id) > 1)
        )).all()
        
        for email, count in email_dups:
            clients = (await session.execute(
                select(Client).where(Client.email == email)
            )).scalars().all()
            duplicates.append({
                "match_type": "email",
                "match_value": email,
                "count": count,
                "clients": [{"id": c.id, "name": c.full_name, "type": c.client_type} for c in clients]
            })
        
        return {"duplicates": duplicates}


@app.post("/clients/merge", response_class=HTMLResponse)
async def merge_clients(
    request: Request,
    primary_id: int = Form(...),
    duplicate_ids: str = Form(...)  # Comma-separated IDs
):
    """Merge duplicate clients into primary client"""
    async with async_session() as session:
        primary = (await session.execute(
            select(Client).where(Client.id == primary_id)
        )).scalar_one_or_none()
        
        if not primary:
            raise HTTPException(404, "Основной клиент не найден")
        
        dup_ids = [int(id.strip()) for id in duplicate_ids.split(",") if id.strip()]
        
        for dup_id in dup_ids:
            if dup_id == primary_id:
                continue
                
            duplicate = (await session.execute(
                select(Client).where(Client.id == dup_id)
            )).scalar_one_or_none()
            
            if not duplicate:
                continue
            
            # Transfer deals to primary
            await session.execute(
                Deal.__table__.update()
                .where(Deal.client_id == dup_id)
                .values(client_id=primary_id)
            )
            
            # Transfer tasks to primary
            await session.execute(
                Task.__table__.update()
                .where(Task.client_id == dup_id)
                .values(client_id=primary_id)
            )
            
            # Transfer communications to primary
            await session.execute(
                Communication.__table__.update()
                .where(Communication.client_id == dup_id)
                .values(client_id=primary_id)
            )
            
            # Transfer documents to primary
            await session.execute(
                Document.__table__.update()
                .where(Document.client_id == dup_id)
                .values(client_id=primary_id)
            )
            
            # Transfer files to primary
            await session.execute(
                File.__table__.update()
                .where(File.client_id == dup_id)
                .values(client_id=primary_id)
            )
            
            # Transfer events to primary
            await session.execute(
                CalendarEvent.__table__.update()
                .where(CalendarEvent.client_id == dup_id)
                .values(client_id=primary_id)
            )
            
            # Merge tags
            if duplicate.tags and duplicate.tags not in (primary.tags or ""):
                primary_tags = set(t.strip() for t in (primary.tags or "").split(",") if t.strip())
                dup_tags = set(t.strip() for t in duplicate.tags.split(",") if t.strip())
                primary.tags = ",".join(primary_tags | dup_tags)
            
            # Merge custom fields
            if duplicate.custom_fields:
                primary_fields = primary.custom_fields or {}
                primary_fields.update(duplicate.custom_fields)
                primary.custom_fields = primary_fields
            
            # Fill empty fields in primary from duplicate
            if not primary.phone and duplicate.phone:
                primary.phone = duplicate.phone
            if not primary.email and duplicate.email:
                primary.email = duplicate.email
            if not primary.website and duplicate.website:
                primary.website = duplicate.website
            if not primary.address and duplicate.address:
                primary.address = duplicate.address
            if not primary.comment and duplicate.comment:
                primary.comment = duplicate.comment
            
            # Log activity
            await log_activity(
                session, 1, "client", primary.id, "merged",
                f"Объединен с клиентом #{dup_id} ({duplicate.full_name})"
            )
            
            # Delete duplicate
            await session.delete(duplicate)
        
        primary.updated_at = datetime.now()
        await session.commit()
    
    return RedirectResponse(url=f"/clients/{primary_id}", status_code=303)


# ==================== CUSTOM FIELDS ====================

@app.get("/settings/custom-fields", response_class=HTMLResponse)
async def custom_fields_page(request: Request):
    """Custom fields management page"""
    async with async_session() as session:
        custom_fields = (await session.execute(
            select(CustomField).order_by(CustomField.entity_type, CustomField.sort_order)
        )).scalars().all()
        
        # Group by entity type
        fields_by_entity = {}
        for field in custom_fields:
            if field.entity_type not in fields_by_entity:
                fields_by_entity[field.entity_type] = []
            fields_by_entity[field.entity_type].append(field)
    
    return templates.TemplateResponse("settings/custom_fields.html", {
        "request": request,
        "fields_by_entity": fields_by_entity,
        "custom_fields": custom_fields
    })


@app.post("/settings/custom-fields", response_class=HTMLResponse)
async def create_custom_field(
    request: Request,
    name: str = Form(...),
    entity_type: str = Form(...),
    field_type: str = Form(...),
    options: str = Form(None),  # JSON for select/multiselect
    is_required: bool = Form(False)
):
    """Create a new custom field"""
    async with async_session() as session:
        # Get max sort order
        max_order = await session.scalar(
            select(func.coalesce(func.max(CustomField.sort_order), 0))
            .where(CustomField.entity_type == entity_type)
        )
        
        field = CustomField(
            name=name,
            entity_type=entity_type,
            field_type=field_type,
            options=json.loads(options) if options else None,
            is_required=is_required,
            sort_order=max_order + 1
        )
        session.add(field)
        await session.commit()
    
    return RedirectResponse(url="/settings/custom-fields", status_code=303)


@app.post("/settings/custom-fields/{field_id}/delete", response_class=HTMLResponse)
async def delete_custom_field(request: Request, field_id: int):
    """Delete a custom field"""
    async with async_session() as session:
        field = (await session.execute(
            select(CustomField).where(CustomField.id == field_id)
        )).scalar_one_or_none()
        
        if field:
            await session.delete(field)
            await session.commit()
    
    return RedirectResponse(url="/settings/custom-fields", status_code=303)


@app.get("/api/custom-fields/{entity_type}")
async def api_get_custom_fields(entity_type: str):
    """Get custom fields for an entity type"""
    async with async_session() as session:
        fields = (await session.execute(
            select(CustomField)
            .where(CustomField.entity_type == entity_type)
            .order_by(CustomField.sort_order)
        )).scalars().all()
        
        return [
            {
                "id": f.id,
                "name": f.name,
                "field_type": f.field_type,
                "options": f.options,
                "is_required": f.is_required
            }
            for f in fields
        ]


@app.post("/clients/{client_id}/custom-fields")
async def update_client_custom_fields(
    client_id: int,
    fields: dict = None
):
    """Update custom fields for a client"""
    async with async_session() as session:
        client = (await session.execute(
            select(Client).where(Client.id == client_id)
        )).scalar_one_or_none()
        
        if not client:
            raise HTTPException(404, "Клиент не найден")
        
        client.custom_fields = fields
        client.updated_at = datetime.now()
        await session.commit()
        
        return {"success": True}


# ==================== CLIENT SEGMENTATION ====================

@app.get("/clients/segments", response_class=HTMLResponse)
async def client_segments_page(request: Request):
    """Client segmentation page"""
    async with async_session() as session:
        # Get all unique tags
        clients = (await session.execute(select(Client))).scalars().all()
        
        tags_count = {}
        for client in clients:
            if client.tags:
                for tag in client.tags.split(","):
                    tag = tag.strip()
                    if tag:
                        tags_count[tag] = tags_count.get(tag, 0) + 1
        
        # Get status distribution
        status_counts = {}
        for client in clients:
            status_counts[client.status] = status_counts.get(client.status, 0) + 1
        
        # Get type distribution
        type_counts = {}
        for client in clients:
            type_counts[client.client_type] = type_counts.get(client.client_type, 0) + 1
        
        # Get source distribution
        source_counts = {}
        for client in clients:
            if client.source:
                source_counts[client.source] = source_counts.get(client.source, 0) + 1
    
    return templates.TemplateResponse("clients/segments.html", {
        "request": request,
        "tags_count": tags_count,
        "status_counts": status_counts,
        "type_counts": type_counts,
        "source_counts": source_counts
    })


@app.post("/clients/bulk-tag", response_class=HTMLResponse)
async def bulk_tag_clients(
    request: Request,
    client_ids: str = Form(...),
    tags: str = Form(...)
):
    """Add tags to multiple clients"""
    async with async_session() as session:
        ids = [int(id.strip()) for id in client_ids.split(",") if id.strip()]
        new_tags = [t.strip() for t in tags.split(",") if t.strip()]
        
        for client_id in ids:
            client = (await session.execute(
                select(Client).where(Client.id == client_id)
            )).scalar_one_or_none()
            
            if client:
                existing_tags = set(t.strip() for t in (client.tags or "").split(",") if t.strip())
                existing_tags.update(new_tags)
                client.tags = ",".join(existing_tags)
        
        await session.commit()
    
    return RedirectResponse(url="/clients", status_code=303)


@app.post("/clients/bulk-status", response_class=HTMLResponse)
async def bulk_update_status(
    request: Request,
    client_ids: str = Form(...),
    status: str = Form(...)
):
    """Update status for multiple clients"""
    async with async_session() as session:
        ids = [int(id.strip()) for id in client_ids.split(",") if id.strip()]
        
        await session.execute(
            Client.__table__.update()
            .where(Client.id.in_(ids))
            .values(status=status, updated_at=datetime.now())
        )
        
        await session.commit()
    
    return RedirectResponse(url="/clients", status_code=303)


# ==================== MESSAGE TEMPLATES ====================

@app.get("/settings/templates", response_class=HTMLResponse)
async def templates_list(request: Request):
    async with async_session() as session:
        templates_data = (await session.execute(
            select(MessageTemplate).order_by(MessageTemplate.channel, MessageTemplate.name)
        )).scalars().all()
    
    return templates.TemplateResponse("settings/templates.html", {
        "request": request,
        "templates": templates_data
    })


@app.get("/settings/templates/new", response_class=HTMLResponse)
async def new_template_form(request: Request):
    return templates.TemplateResponse("settings/template_form.html", {
        "request": request,
        "template": None
    })


@app.post("/settings/templates", response_class=HTMLResponse)
async def create_template(
    request: Request,
    name: str = Form(...),
    channel: str = Form(...),
    subject: str = Form(None),
    body: str = Form(...),
    variables: str = Form(None),
    is_global: bool = Form(False)
):
    async with async_session() as session:
        template = MessageTemplate(
            name=name,
            channel=channel,
            subject=subject,
            body=body,
            variables=variables.split(",") if variables else [],
            is_global=is_global
        )
        session.add(template)
        await session.commit()
    
    return RedirectResponse(url="/settings/templates", status_code=303)


@app.get("/settings/templates/{template_id}/edit", response_class=HTMLResponse)
async def edit_template_form(request: Request, template_id: int):
    async with async_session() as session:
        template = (await session.execute(
            select(MessageTemplate).where(MessageTemplate.id == template_id)
        )).scalar_one_or_none()
    
    return templates.TemplateResponse("settings/template_form.html", {
        "request": request,
        "template": template
    })


@app.post("/settings/templates/{template_id}/edit", response_class=HTMLResponse)
async def update_template(
    request: Request,
    template_id: int,
    name: str = Form(...),
    channel: str = Form(...),
    subject: str = Form(None),
    body: str = Form(...),
    variables: str = Form(None),
    is_global: bool = Form(False)
):
    async with async_session() as session:
        template = (await session.execute(
            select(MessageTemplate).where(MessageTemplate.id == template_id)
        )).scalar_one_or_none()
        
        if template:
            template.name = name
            template.channel = channel
            template.subject = subject
            template.body = body
            template.variables = variables.split(",") if variables else []
            template.is_global = is_global
            await session.commit()
    
    return RedirectResponse(url="/settings/templates", status_code=303)


@app.post("/settings/templates/{template_id}/delete", response_class=HTMLResponse)
async def delete_template(request: Request, template_id: int):
    async with async_session() as session:
        template = (await session.execute(
            select(MessageTemplate).where(MessageTemplate.id == template_id)
        )).scalar_one_or_none()
        
        if template:
            await session.delete(template)
            await session.commit()
    
    return RedirectResponse(url="/settings/templates", status_code=303)


# ==================== SLA MANAGEMENT ====================

@app.get("/settings/sla", response_class=HTMLResponse)
async def sla_rules_list(request: Request):
    async with async_session() as session:
        rules = (await session.execute(
            select(SLARule).order_by(SLARule.channel, SLARule.priority)
        )).scalars().all()
        
        # Get SLA statistics
        sla_stats = (await session.execute(
            select(SLATracking)
            .order_by(SLATracking.created_at.desc())
            .limit(100)
        )).scalars().all()
        
        total_tracked = len(sla_stats)
        within_sla = sum(1 for s in sla_stats if s.is_within_sla)
        breached = sum(1 for s in sla_stats if s.is_breached)
    
    return templates.TemplateResponse("settings/sla.html", {
        "request": request,
        "rules": rules,
        "stats": {
            "total": total_tracked,
            "within_sla": within_sla,
            "breached": breached,
            "compliance_rate": round(within_sla / total_tracked * 100, 1) if total_tracked > 0 else 0
        }
    })


@app.post("/settings/sla", response_class=HTMLResponse)
async def create_sla_rule(
    request: Request,
    name: str = Form(...),
    channel: str = Form(...),
    priority: str = Form("medium"),
    response_time_minutes: int = Form(60),
    working_hours_only: bool = Form(False)
):
    async with async_session() as session:
        rule = SLARule(
            name=name,
            channel=channel,
            priority=priority,
            response_time_minutes=response_time_minutes,
            working_hours_only=working_hours_only
        )
        session.add(rule)
        await session.commit()
    
    return RedirectResponse(url="/settings/sla", status_code=303)


@app.post("/settings/sla/{rule_id}/delete", response_class=HTMLResponse)
async def delete_sla_rule(request: Request, rule_id: int):
    async with async_session() as session:
        rule = (await session.execute(
            select(SLARule).where(SLARule.id == rule_id)
        )).scalar_one_or_none()
        
        if rule:
            await session.delete(rule)
            await session.commit()
    
    return RedirectResponse(url="/settings/sla", status_code=303)


# ==================== UNIFIED INBOX ====================

@app.get("/inbox", response_class=HTMLResponse)
async def unified_inbox(
    request: Request,
    channel: str = Query(None),
    direction: str = Query(None),
    unread: bool = Query(False)
):
    """Unified inbox for all communication channels"""
    async with async_session() as session:
        query = select(Communication).options(
            selectinload(Communication.client)
        )
        
        if channel:
            query = query.where(Communication.channel == channel)
        if direction:
            query = query.where(Communication.direction == direction)
        if unread:
            query = query.where(Communication.read_at == None)
        
        query = query.order_by(Communication.created_at.desc())
        messages = (await session.execute(query)).scalars().all()
        
        # Get counts by channel
        channel_counts = {}
        for ch in ['email', 'phone', 'whatsapp', 'telegram', 'chat', 'social']:
            count = (await session.execute(
                select(func.count()).select_from(Communication)
                .where(Communication.channel == ch)
            )).scalar()
            channel_counts[ch] = count
        
        # Get unread count
        unread_count = (await session.execute(
            select(func.count()).select_from(Communication)
            .where(Communication.read_at == None)
        )).scalar()
        
        # Get SLA breaches
        sla_breaches = (await session.execute(
            select(func.count()).select_from(SLATracking)
            .where(SLATracking.is_breached == True)
        )).scalar()
    
    return templates.TemplateResponse("messages/inbox.html", {
        "request": request,
        "messages": messages,
        "channel_counts": channel_counts,
        "unread_count": unread_count,
        "sla_breaches": sla_breaches,
        "filters": {"channel": channel, "direction": direction, "unread": unread}
    })


@app.get("/inbox/{message_id}", response_class=HTMLResponse)
async def message_detail(request: Request, message_id: int):
    """View message details and reply"""
    async with async_session() as session:
        message = (await session.execute(
            select(Communication)
            .options(selectinload(Communication.client))
            .where(Communication.id == message_id)
        )).scalar_one_or_none()
        
        if not message:
            raise HTTPException(404, "Сообщение не найдено")
        
        # Mark as read
        if not message.read_at:
            message.read_at = datetime.now()
            await session.commit()
        
        # Get templates for reply
        templates_list = (await session.execute(
            select(MessageTemplate)
            .where(MessageTemplate.channel == message.channel)
        )).scalars().all()
    
    return templates.TemplateResponse("messages/detail.html", {
        "request": request,
        "message": message,
        "templates": templates_list
    })


@app.post("/inbox/{message_id}/reply", response_class=HTMLResponse)
async def reply_to_message(
    request: Request,
    message_id: int,
    body: str = Form(...),
    subject: str = Form(None)
):
    """Reply to a message"""
    async with async_session() as session:
        original = (await session.execute(
            select(Communication)
            .options(selectinload(Communication.client))
            .where(Communication.id == message_id)
        )).scalar_one_or_none()
        
        if not original:
            raise HTTPException(404, "Сообщение не найдено")
        
        # Create reply
        reply = Communication(
            channel=original.channel,
            direction="outbound",
            client_id=original.client_id,
            to_contact=original.from_contact,
            subject=subject or f"Re: {original.subject}",
            body=body,
            status="sent",
            sent_at=datetime.now()
        )
        session.add(reply)
        
        # Update SLA tracking if applicable
        if original.client_id:
            sla_track = (await session.execute(
                select(SLATracking)
                .where(SLATracking.client_id == original.client_id)
                .where(SLATracking.first_response_at == None)
                .order_by(SLATracking.created_at.desc())
            )).scalar_one_or_none()
            
            if sla_track:
                sla_track.first_response_at = datetime.now()
                response_time = (datetime.now() - sla_track.created_at).total_seconds() / 60
                sla_track.response_time_minutes = int(response_time)
                sla_track.is_within_sla = response_time <= sla_track.target_time_minutes
        
        # Update client last contact
        if original.client:
            original.client.last_contact_at = datetime.now()
        
        await session.commit()
    
    return RedirectResponse(url=f"/inbox/{message_id}", status_code=303)


# ==================== ROLES & PERMISSIONS ====================

@app.get("/settings/roles", response_class=HTMLResponse)
async def roles_list(request: Request):
    """List all roles"""
    async with async_session() as session:
        roles = (await session.execute(
            select(Role).order_by(Role.name)
        )).scalars().all()
    
    return templates.TemplateResponse("settings/roles.html", {
        "request": request,
        "roles": roles
    })


@app.post("/settings/roles", response_class=HTMLResponse)
async def create_role(
    request: Request,
    name: str = Form(...),
    permissions: str = Form(None)  # JSON string
):
    """Create a new role"""
    async with async_session() as session:
        role = Role(
            name=name,
            permissions=json.loads(permissions) if permissions else {}
        )
        session.add(role)
        await session.commit()
    
    return RedirectResponse(url="/settings/roles", status_code=303)


@app.get("/settings/roles/{role_id}/edit", response_class=HTMLResponse)
async def edit_role_form(request: Request, role_id: int):
    """Edit role form"""
    async with async_session() as session:
        role = (await session.execute(
            select(Role).where(Role.id == role_id)
        )).scalar_one_or_none()
    
    return templates.TemplateResponse("settings/role_form.html", {
        "request": request,
        "role": role
    })


@app.post("/settings/roles/{role_id}/edit", response_class=HTMLResponse)
async def update_role(
    request: Request,
    role_id: int,
    name: str = Form(...),
    permissions: str = Form(None)
):
    """Update role"""
    async with async_session() as session:
        role = (await session.execute(
            select(Role).where(Role.id == role_id)
        )).scalar_one_or_none()
        
        if role:
            role.name = name
            role.permissions = json.loads(permissions) if permissions else {}
            await session.commit()
    
    return RedirectResponse(url="/settings/roles", status_code=303)


@app.post("/settings/roles/{role_id}/delete", response_class=HTMLResponse)
async def delete_role(request: Request, role_id: int):
    """Delete role"""
    async with async_session() as session:
        role = (await session.execute(
            select(Role).where(Role.id == role_id)
        )).scalar_one_or_none()
        
        if role:
            await session.delete(role)
            await session.commit()
    
    return RedirectResponse(url="/settings/roles", status_code=303)


# ==================== TEAMS ====================

@app.get("/settings/teams", response_class=HTMLResponse)
async def teams_list(request: Request):
    """List all teams"""
    async with async_session() as session:
        teams = (await session.execute(
            select(Team).options(selectinload(Team.manager), selectinload(Team.members))
        )).scalars().all()
        
        users = (await session.execute(select(User))).scalars().all()
    
    return templates.TemplateResponse("settings/teams.html", {
        "request": request,
        "teams": teams,
        "users": users
    })


@app.post("/settings/teams", response_class=HTMLResponse)
async def create_team(
    request: Request,
    name: str = Form(...),
    description: str = Form(None),
    manager_id: int = Form(None),
    parent_team_id: int = Form(None)
):
    """Create a new team"""
    async with async_session() as session:
        team = Team(
            name=name,
            description=description,
            manager_id=manager_id if manager_id else None,
            parent_team_id=parent_team_id if parent_team_id else None
        )
        session.add(team)
        await session.commit()
    
    return RedirectResponse(url="/settings/teams", status_code=303)


@app.post("/settings/teams/{team_id}/delete", response_class=HTMLResponse)
async def delete_team(request: Request, team_id: int):
    """Delete team"""
    async with async_session() as session:
        team = (await session.execute(
            select(Team).where(Team.id == team_id)
        )).scalar_one_or_none()
        
        if team:
            await session.delete(team)
            await session.commit()
    
    return RedirectResponse(url="/settings/teams", status_code=303)


# ==================== OFFICES / BRANCHES ====================

@app.get("/settings/offices", response_class=HTMLResponse)
async def offices_list(request: Request):
    """List all offices/branches"""
    async with async_session() as session:
        offices = (await session.execute(
            select(Office).options(selectinload(Office.director), selectinload(Office.legal_entity))
        )).scalars().all()
        
        users = (await session.execute(select(User))).scalars().all()
        legal_entities = (await session.execute(select(LegalEntity))).scalars().all()
    
    return templates.TemplateResponse("settings/offices.html", {
        "request": request,
        "offices": offices,
        "users": users,
        "legal_entities": legal_entities
    })


@app.post("/settings/offices", response_class=HTMLResponse)
async def create_office(
    request: Request,
    name: str = Form(...),
    code: str = Form(None),
    address: str = Form(None),
    city: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    director_id: int = Form(None),
    legal_entity_id: int = Form(None),
    is_headquarters: bool = Form(False)
):
    """Create a new office"""
    async with async_session() as session:
        office = Office(
            name=name,
            code=code,
            address=address,
            city=city,
            phone=phone,
            email=email,
            director_id=director_id if director_id else None,
            legal_entity_id=legal_entity_id if legal_entity_id else None,
            is_headquarters=is_headquarters
        )
        session.add(office)
        await session.commit()
    
    return RedirectResponse(url="/settings/offices", status_code=303)


@app.post("/settings/offices/{office_id}/delete", response_class=HTMLResponse)
async def delete_office(request: Request, office_id: int):
    """Delete office"""
    async with async_session() as session:
        office = (await session.execute(
            select(Office).where(Office.id == office_id)
        )).scalar_one_or_none()
        
        if office:
            await session.delete(office)
            await session.commit()
    
    return RedirectResponse(url="/settings/offices", status_code=303)


# ==================== LEGAL ENTITIES ====================

@app.get("/settings/legal-entities", response_class=HTMLResponse)
async def legal_entities_list(request: Request):
    """List all legal entities"""
    async with async_session() as session:
        entities = (await session.execute(
            select(LegalEntity).options(selectinload(LegalEntity.offices))
        )).scalars().all()
    
    return templates.TemplateResponse("settings/legal_entities.html", {
        "request": request,
        "legal_entities": entities
    })


@app.post("/settings/legal-entities", response_class=HTMLResponse)
async def create_legal_entity(
    request: Request,
    name: str = Form(...),
    short_name: str = Form(None),
    inn: str = Form(None),
    kpp: str = Form(None),
    ogrn: str = Form(None),
    legal_address: str = Form(None),
    physical_address: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    bank_name: str = Form(None),
    bank_bik: str = Form(None),
    bank_account: str = Form(None),
    general_director: str = Form(None)
):
    """Create a new legal entity"""
    async with async_session() as session:
        entity = LegalEntity(
            name=name,
            short_name=short_name,
            inn=inn,
            kpp=kpp,
            ogrn=ogrn,
            legal_address=legal_address,
            physical_address=physical_address,
            phone=phone,
            email=email,
            bank_name=bank_name,
            bank_bik=bank_bik,
            bank_account=bank_account,
            general_director=general_director
        )
        session.add(entity)
        await session.commit()
    
    return RedirectResponse(url="/settings/legal-entities", status_code=303)


@app.post("/settings/legal-entities/{entity_id}/delete", response_class=HTMLResponse)
async def delete_legal_entity(request: Request, entity_id: int):
    """Delete legal entity"""
    async with async_session() as session:
        entity = (await session.execute(
            select(LegalEntity).where(LegalEntity.id == entity_id)
        )).scalar_one_or_none()
        
        if entity:
            await session.delete(entity)
            await session.commit()
    
    return RedirectResponse(url="/settings/legal-entities", status_code=303)


# ==================== BUSINESS PROCESSES ====================

@app.get("/settings/business-processes", response_class=HTMLResponse)
async def business_processes_list(request: Request):
    """List all business processes"""
    async with async_session() as session:
        processes = (await session.execute(
            select(BusinessProcess).order_by(BusinessProcess.name)
        )).scalars().all()
    
    return templates.TemplateResponse("settings/business_processes.html", {
        "request": request,
        "processes": processes
    })


@app.get("/settings/business-processes/new", response_class=HTMLResponse)
async def new_business_process_form(request: Request):
    """New business process form"""
    return templates.TemplateResponse("settings/business_process_form.html", {
        "request": request,
        "process": None
    })


@app.post("/settings/business-processes", response_class=HTMLResponse)
async def create_business_process(
    request: Request,
    name: str = Form(...),
    description: str = Form(None),
    process_type: str = Form(...),
    steps: str = Form(None),  # JSON string
    trigger_type: str = Form("manual"),
    trigger_config: str = Form(None),
    auto_start: bool = Form(False)
):
    """Create a new business process"""
    async with async_session() as session:
        process = BusinessProcess(
            name=name,
            description=description,
            process_type=process_type,
            steps=json.loads(steps) if steps else [],
            trigger_type=trigger_type,
            trigger_config=json.loads(trigger_config) if trigger_config else None,
            auto_start=auto_start
        )
        session.add(process)
        await session.commit()
    
    return RedirectResponse(url="/settings/business-processes", status_code=303)


@app.get("/settings/business-processes/{process_id}/edit", response_class=HTMLResponse)
async def edit_business_process_form(request: Request, process_id: int):
    """Edit business process form"""
    async with async_session() as session:
        process = (await session.execute(
            select(BusinessProcess).where(BusinessProcess.id == process_id)
        )).scalar_one_or_none()
    
    return templates.TemplateResponse("settings/business_process_form.html", {
        "request": request,
        "process": process
    })


@app.post("/settings/business-processes/{process_id}/edit", response_class=HTMLResponse)
async def update_business_process(
    request: Request,
    process_id: int,
    name: str = Form(...),
    description: str = Form(None),
    process_type: str = Form(...),
    steps: str = Form(None),
    trigger_type: str = Form("manual"),
    trigger_config: str = Form(None),
    auto_start: bool = Form(False),
    is_active: bool = Form(True)
):
    """Update business process"""
    async with async_session() as session:
        process = (await session.execute(
            select(BusinessProcess).where(BusinessProcess.id == process_id)
        )).scalar_one_or_none()
        
        if process:
            process.name = name
            process.description = description
            process.process_type = process_type
            process.steps = json.loads(steps) if steps else []
            process.trigger_type = trigger_type
            process.trigger_config = json.loads(trigger_config) if trigger_config else None
            process.auto_start = auto_start
            process.is_active = is_active
            await session.commit()
    
    return RedirectResponse(url="/settings/business-processes", status_code=303)


@app.post("/settings/business-processes/{process_id}/delete", response_class=HTMLResponse)
async def delete_business_process(request: Request, process_id: int):
    """Delete business process"""
    async with async_session() as session:
        process = (await session.execute(
            select(BusinessProcess).where(BusinessProcess.id == process_id)
        )).scalar_one_or_none()
        
        if process:
            await session.delete(process)
            await session.commit()
    
    return RedirectResponse(url="/settings/business-processes", status_code=303)


@app.post("/settings/business-processes/{process_id}/start", response_class=HTMLResponse)
async def start_business_process(
    request: Request,
    process_id: int,
    entity_type: str = Form(...),
    entity_id: int = Form(...)
):
    """Start a business process for an entity"""
    async with async_session() as session:
        process = (await session.execute(
            select(BusinessProcess).where(BusinessProcess.id == process_id)
        )).scalar_one_or_none()
        
        if not process:
            raise HTTPException(404, "Бизнес-процесс не найден")
        
        instance = BusinessProcessInstance(
            process_id=process_id,
            entity_type=entity_type,
            entity_id=entity_id,
            status="running",
            current_step=0,
            history=[]
        )
        session.add(instance)
        await session.commit()
    
    return RedirectResponse(url=f"/settings/business-processes/{process_id}", status_code=303)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
