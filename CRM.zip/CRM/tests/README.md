# Integration Tests

This directory contains integration tests for the CRM system.

## Test Structure

```
tests/
├── __init__.py              # Test package initialization
├── conftest.py              # Pytest fixtures and configuration
├── pytest.ini               # Pytest configuration
├── test_auth.py             # Authentication flow tests
├── test_password_reset.py   # Password reset flow tests
├── test_multitenancy.py     # Multi-tenancy isolation tests
└── test_users.py            # User management tests
```

## Running Tests

### Run all tests:
```bash
pytest tests/
```

### Run specific test file:
```bash
pytest tests/test_auth.py
```

### Run with verbose output:
```bash
pytest tests/ -v
```

### Run only fast tests (exclude slow):
```bash
pytest tests/ -m "not slow"
```

## Test Categories

### Authentication Tests (`test_auth.py`)
- Login flow
- Refresh token flow
- Token validation
- Logout

### Password Reset Tests (`test_password_reset.py`)
- Request password reset
- Reset password with token
- Token validation

### Multi-tenancy Tests (`test_multitenancy.py`)
- Company data isolation
- Cross-company access blocking
- Superuser permissions

### User Management Tests (`test_users.py`)
- Create user
- Update user
- Delete user
- List users with pagination
- Permission checks

## Fixtures

Available fixtures in `conftest.py`:

- `client` - Async HTTP client for API calls
- `db_session` - Database session for direct DB operations
- `test_company` - Pre-created test company
- `second_company` - Second company for multi-tenancy tests
- `test_user` - Regular user in test_company
- `test_admin` - Admin user in test_company
- `second_company_user` - User in second_company
- `auth_tokens` - Authentication tokens for test_user
- `auth_headers` - HTTP headers with bearer token for test_user
- `admin_tokens` - Authentication tokens for admin
- `admin_headers` - HTTP headers with bearer token for admin
- `second_company_tokens` - Tokens for second_company_user
- `second_company_headers` - Headers for second_company_user

## Database

Tests use SQLite in-memory database (`sqlite+aiosqlite`) for fast execution.
Database is created fresh for each test session and dropped after.

## Environment Variables

Create `.env.test` file for test-specific configuration:

```env
DATABASE_URL=sqlite+aiosqlite:///./test.db
JWT_SECRET=test-secret-key
DEBUG=True
```
