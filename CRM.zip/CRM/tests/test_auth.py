"""
Integration tests for Authentication flows
- Login
- Refresh token
- Logout
- Token validation
"""
import pytest
from httpx import AsyncClient
import jwt
from datetime import datetime, timezone, timedelta

from app.core.config import settings
from app.modules.users.models import User


class TestLoginFlow:
    """Test login flow integration"""

    @pytest.mark.asyncio
    async def test_login_success(self, client: AsyncClient, test_user: User):
        """Test successful login returns access and refresh tokens"""
        response = await client.post("/api/v1/auth/login", data={
            "username": test_user.email,
            "password": "TestPassword123!"
        })
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify response structure
        assert "access_token" in data
        assert "refresh_token" in data
        assert "token_type" in data
        assert data["token_type"] == "bearer"
        
        # Verify access token is valid JWT
        access_token = data["access_token"]
        decoded = jwt.decode(access_token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        assert decoded["sub"] == test_user.id
        assert decoded["email"] == test_user.email
        assert "exp" in decoded
        assert "jti" in decoded

    @pytest.mark.asyncio
    async def test_login_invalid_password(self, client: AsyncClient, test_user: User):
        """Test login with invalid password fails"""
        response = await client.post("/api/v1/auth/login", data={
            "username": test_user.email,
            "password": "WrongPassword123!"
        })
        
        assert response.status_code == 401
        data = response.json()
        assert "detail" in data

    @pytest.mark.asyncio
    async def test_login_nonexistent_user(self, client: AsyncClient):
        """Test login with non-existent user fails"""
        response = await client.post("/api/v1/auth/login", data={
            "username": "nonexistent@example.com",
            "password": "SomePassword123!"
        })
        
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_login_inactive_user(self, client: AsyncClient, db_session, test_company):
        """Test login with inactive user fails"""
        from app.core.security import hash_password
        import uuid
        
        # Create inactive user
        inactive_user = User(
            id=str(uuid.uuid4()),
            company_id=test_company.id,
            email="inactive@example.com",
            password_hash=hash_password("InactivePass123!"),
            full_name="Inactive User",
            is_active=False,
            email_verified=True
        )
        db_session.add(inactive_user)
        await db_session.commit()
        
        response = await client.post("/api/v1/auth/login", data={
            "username": inactive_user.email,
            "password": "InactivePass123!"
        })
        
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_login_missing_fields(self, client: AsyncClient):
        """Test login with missing fields fails"""
        response = await client.post("/api/v1/auth/login", data={
            "username": "test@example.com"
            # Missing password
        })
        
        assert response.status_code in [400, 422]


class TestRefreshTokenFlow:
    """Test refresh token flow integration"""

    @pytest.mark.asyncio
    async def test_refresh_token_success(self, client: AsyncClient, auth_tokens: dict):
        """Test successful token refresh"""
        response = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": auth_tokens["refresh_token"]
        })
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify new tokens are returned
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
        
        # New tokens should be different
        assert data["access_token"] != auth_tokens["access_token"]
        assert data["refresh_token"] != auth_tokens["refresh_token"]

    @pytest.mark.asyncio
    async def test_refresh_token_invalid(self, client: AsyncClient):
        """Test refresh with invalid token fails"""
        response = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": "invalid_token_here"
        })
        
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_refresh_token_reuse(self, client: AsyncClient, auth_tokens: dict):
        """Test that refresh token cannot be reused"""
        # First refresh
        response1 = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": auth_tokens["refresh_token"]
        })
        assert response1.status_code == 200
        
        # Second refresh with same token should fail
        response2 = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": auth_tokens["refresh_token"]
        })
        assert response2.status_code == 401

    @pytest.mark.asyncio
    async def test_access_token_expired(self, client: AsyncClient, test_user: User):
        """Test that expired access token is rejected"""
        # Create an expired token manually
        expired_token = jwt.encode(
            {
                "sub": test_user.id,
                "email": test_user.email,
                "exp": datetime.now(timezone.utc) - timedelta(hours=1),
                "jti": "test-jti"
            },
            settings.JWT_SECRET,
            algorithm=settings.JWT_ALGORITHM
        )
        
        response = await client.get(
            "/api/v1/users/me",
            headers={"Authorization": f"Bearer {expired_token}"}
        )
        
        assert response.status_code == 401


class TestLogoutFlow:
    """Test logout flow integration"""

    @pytest.mark.asyncio
    async def test_logout_success(self, client: AsyncClient, auth_tokens: dict, auth_headers: dict):
        """Test successful logout invalidates tokens"""
        response = await client.post(
            "/api/v1/auth/logout",
            headers=auth_headers,
            json={"refresh_token": auth_tokens["refresh_token"]}
        )
        
        assert response.status_code == 200
        
        # Try to use refresh token after logout
        refresh_response = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": auth_tokens["refresh_token"]
        })
        assert refresh_response.status_code == 401

    @pytest.mark.asyncio
    async def test_logout_without_auth(self, client: AsyncClient):
        """Test logout without authentication fails"""
        response = await client.post("/api/v1/auth/logout")
        assert response.status_code == 401


class TestTokenValidation:
    """Test token validation edge cases"""

    @pytest.mark.asyncio
    async def test_protected_endpoint_without_token(self, client: AsyncClient):
        """Test accessing protected endpoint without token fails"""
        response = await client.get("/api/v1/users/me")
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_protected_endpoint_with_invalid_token(self, client: AsyncClient):
        """Test accessing protected endpoint with invalid token fails"""
        response = await client.get(
            "/api/v1/users/me",
            headers={"Authorization": "Bearer invalid_token"}
        )
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_protected_endpoint_with_malformed_header(self, client: AsyncClient):
        """Test accessing protected endpoint with malformed auth header fails"""
        response = await client.get(
            "/api/v1/users/me",
            headers={"Authorization": "InvalidHeaderFormat"}
        )
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_access_user_endpoint_with_valid_token(self, client: AsyncClient, auth_headers: dict, test_user: User):
        """Test accessing user endpoint with valid token succeeds"""
        response = await client.get("/api/v1/users/me", headers=auth_headers)
        
        assert response.status_code == 200
        data = response.json()
        assert data["email"] == test_user.email
        assert data["full_name"] == test_user.full_name
