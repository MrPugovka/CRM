"""
Integration tests for Multi-tenancy Isolation
- Users can only access data from their company
- Cross-company data access is blocked
- Company isolation in queries
"""
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import uuid

from app.modules.users.models import User, Company
from app.core.security import hash_password


class TestMultiTenancyIsolation:
    """Test multi-tenancy data isolation"""

    @pytest.mark.asyncio
    async def test_user_cannot_access_other_company_data(
        self,
        client: AsyncClient,
        auth_headers: dict,
        test_user: User,
        second_company: Company
    ):
        """Test that user cannot access data from another company"""
        # Try to access users list - should only see own company's users
        response = await client.get("/api/v1/users/", headers=auth_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        # Should only contain users from test_user's company
        if "items" in data:
            for user in data["items"]:
                assert user.get("company_id") == test_user.company_id

    @pytest.mark.asyncio
    async def test_user_isolated_by_company_in_query(
        self,
        client: AsyncClient,
        db_session: AsyncSession,
        test_company: Company,
        second_company: Company
    ):
        """Test that database queries are properly filtered by company"""
        # Create users in both companies
        user1 = User(
            id=str(uuid.uuid4()),
            company_id=test_company.id,
            email="user1@company1.com",
            password_hash=hash_password("Pass123!"),
            full_name="User 1",
            is_active=True
        )
        user2 = User(
            id=str(uuid.uuid4()),
            company_id=second_company.id,
            email="user2@company2.com",
            password_hash=hash_password("Pass123!"),
            full_name="User 2",
            is_active=True
        )
        
        db_session.add_all([user1, user2])
        await db_session.commit()
        
        # Query users - should respect company isolation
        from app.core.multitenancy import filter_by_company
        
        stmt = select(User)
        filtered_stmt = filter_by_company(stmt, User, user1)
        
        result = await db_session.execute(filtered_stmt)
        users = result.scalars().all()
        
        # Should only get users from user1's company
        for user in users:
            assert user.company_id == test_company.id
            assert user.company_id != second_company.id

    @pytest.mark.asyncio
    async def test_cross_company_access_blocked(
        self,
        client: AsyncClient,
        auth_headers: dict,
        second_company_user: User
    ):
        """Test that direct access to another company's user is blocked"""
        # Try to access a user from another company by ID
        response = await client.get(
            f"/api/v1/users/{second_company_user.id}",
            headers=auth_headers
        )
        
        # Should return 404 (not found) or 403 (forbidden)
        assert response.status_code in [404, 403]

    @pytest.mark.asyncio
    async def test_company_filter_applied_automatically(
        self,
        client: AsyncClient,
        db_session: AsyncSession,
        test_company: Company,
        second_company: Company,
        auth_headers: dict
    ):
        """Test that company filter is automatically applied to queries"""
        # Create multiple users in different companies
        for i in range(3):
            user = User(
                id=str(uuid.uuid4()),
                company_id=test_company.id,
                email=f"company1_user{i}@test.com",
                password_hash=hash_password("Pass123!"),
                full_name=f"Company1 User {i}",
                is_active=True
            )
            db_session.add(user)
        
        for i in range(3):
            user = User(
                id=str(uuid.uuid4()),
                company_id=second_company.id,
                email=f"company2_user{i}@test.com",
                password_hash=hash_password("Pass123!"),
                full_name=f"Company2 User {i}",
                is_active=True
            )
            db_session.add(user)
        
        await db_session.commit()
        
        # Get users list - should only return users from authenticated user's company
        response = await client.get("/api/v1/users/", headers=auth_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        if "items" in data:
            # All returned users should be from the same company
            for user in data["items"]:
                assert user.get("company_id") == test_company.id

    @pytest.mark.asyncio
    async def test_superuser_can_access_all_companies(
        self,
        client: AsyncClient,
        db_session: AsyncSession,
        test_company: Company,
        admin_headers: dict,
        test_admin: User
    ):
        """Test that superusers can bypass company filter"""
        # Make admin a superuser
        test_admin.is_superuser = True
        await db_session.commit()
        
        # Create users in multiple companies
        company2 = Company(
            id=str(uuid.uuid4()),
            name="Another Company",
            code="another-co",
            is_active=True
        )
        db_session.add(company2)
        await db_session.commit()
        
        # Superuser should be able to access all users
        response = await client.get("/api/v1/users/", headers=admin_headers)
        
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_user_cannot_create_resource_for_other_company(
        self,
        client: AsyncClient,
        auth_headers: dict,
        second_company: Company
    ):
        """Test that user cannot create resources for another company"""
        # Try to create a user with different company_id
        response = await client.post(
            "/api/v1/users/",
            headers=auth_headers,
            json={
                "email": "newuser@example.com",
                "password": "SecurePass123!",
                "full_name": "New User",
                "company_id": second_company.id  # Attempt to set different company
            }
        )
        
        # Should either ignore the company_id or reject the request
        assert response.status_code in [201, 200, 403]
        
        if response.status_code in [200, 201]:
            # Verify the created user has the correct company
            data = response.json()
            assert data.get("company_id") != second_company.id

    @pytest.mark.asyncio
    async def test_company_isolation_in_search(
        self,
        client: AsyncClient,
        db_session: AsyncSession,
        test_company: Company,
        second_company: Company,
        auth_headers: dict
    ):
        """Test that search respects company boundaries"""
        # Create users with same name in different companies
        user1 = User(
            id=str(uuid.uuid4()),
            company_id=test_company.id,
            email="john@company1.com",
            password_hash=hash_password("Pass123!"),
            full_name="John Doe",
            is_active=True
        )
        user2 = User(
            id=str(uuid.uuid4()),
            company_id=second_company.id,
            email="john@company2.com",
            password_hash=hash_password("Pass123!"),
            full_name="John Doe",
            is_active=True
        )
        
        db_session.add_all([user1, user2])
        await db_session.commit()
        
        # Search for "John" - should only return users from authenticated company
        response = await client.get(
            "/api/v1/users/?search=John",
            headers=auth_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        
        if "items" in data:
            for user in data["items"]:
                assert user.get("company_id") == test_company.id
                assert user.get("email") == "john@company1.com"

    @pytest.mark.asyncio
    async def test_company_context_in_audit_logs(
        self,
        client: AsyncClient,
        db_session: AsyncSession,
        test_user: User,
        auth_headers: dict
    ):
        """Test that audit logs include correct company context"""
        from app.core.audit import AuditLog
        
        # Perform an action that creates audit log
        response = await client.get("/api/v1/users/me", headers=auth_headers)
        assert response.status_code == 200
        
        # Check that audit log has correct company_id
        # Note: This assumes audit logging is configured
        result = await db_session.execute(
            select(AuditLog).where(AuditLog.user_id == test_user.id)
        )
        audit_logs = result.scalars().all()
        
        for log in audit_logs:
            assert log.company_id is not None
            # company_id should match the user's company

    @pytest.mark.asyncio
    async def test_isolation_persists_across_sessions(
        self,
        client: AsyncClient,
        auth_headers: dict,
        second_company_user: User
    ):
        """Test that company isolation persists across multiple requests"""
        # Make multiple requests
        for _ in range(3):
            response = await client.get("/api/v1/users/", headers=auth_headers)
            assert response.status_code == 200
            
            data = response.json()
            if "items" in data:
                for user in data["items"]:
                    # Should never see the second company's user
                    assert user.get("id") != second_company_user.id

    @pytest.mark.asyncio
    async def test_token_contains_company_info(
        self,
        client: AsyncClient,
        auth_tokens: dict,
        test_user: User
    ):
        """Test that JWT token contains company information"""
        import jwt
        from app.core.config import settings
        
        # Decode the access token
        decoded = jwt.decode(
            auth_tokens["access_token"],
            settings.JWT_SECRET,
            algorithms=[settings.JWT_ALGORITHM]
        )
        
        # Token should contain user and company info
        assert decoded["sub"] == test_user.id
        assert "company_id" in decoded or "email" in decoded
