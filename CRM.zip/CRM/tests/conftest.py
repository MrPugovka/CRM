"""
Pytest configuration and fixtures for integration tests
"""
import asyncio
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from app.main import app
from app.core.database import Base, get_db
from app.core.config import settings
from app.modules.users.models import User, Company, Role, Permission
from app.core.security import hash_password
import uuid
from datetime import datetime, timezone

# Test database URL (SQLite in memory for tests)
TEST_DATABASE_URL = "sqlite+aiosqlite:///./test.db"

# Create test engine
test_engine = create_async_engine(
    TEST_DATABASE_URL,
    echo=False,
    future=True
)

# Create test session factory
TestSessionLocal = async_sessionmaker(
    test_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


async def override_get_db():
    """Override database dependency for testing"""
    async with TestSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


# Override the dependency
app.dependency_overrides[get_db] = override_get_db


@pytest_asyncio.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session", autouse=True)
async def setup_database():
    """Create test database tables"""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await test_engine.dispose()


@pytest_asyncio.fixture
async def db_session():
    """Provide a database session for tests"""
    async with TestSessionLocal() as session:
        yield session


@pytest_asyncio.fixture
async def client():
    """Provide an HTTP client for API tests"""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest_asyncio.fixture
async def test_company(db_session: AsyncSession):
    """Create a test company"""
    company = Company(
        id=str(uuid.uuid4()),
        name="Test Company",
        code="test-co",
        description="Test company for integration tests",
        is_active=True,
        is_verified=True,
        subscription_plan="enterprise"
    )
    db_session.add(company)
    await db_session.commit()
    await db_session.refresh(company)
    return company


@pytest_asyncio.fixture
async def second_company(db_session: AsyncSession):
    """Create a second test company for multi-tenancy tests"""
    company = Company(
        id=str(uuid.uuid4()),
        name="Second Company",
        code="second-co",
        description="Second test company",
        is_active=True,
        is_verified=True,
        subscription_plan="enterprise"
    )
    db_session.add(company)
    await db_session.commit()
    await db_session.refresh(company)
    return company


@pytest_asyncio.fixture
async def test_user(db_session: AsyncSession, test_company):
    """Create a test user"""
    user = User(
        id=str(uuid.uuid4()),
        company_id=test_company.id,
        email="test@example.com",
        password_hash=hash_password("TestPassword123!"),
        full_name="Test User",
        phone="+1234567890",
        role="employee",
        is_active=True,
        email_verified=True
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest_asyncio.fixture
async def test_admin(db_session: AsyncSession, test_company):
    """Create a test admin user"""
    admin = User(
        id=str(uuid.uuid4()),
        company_id=test_company.id,
        email="admin@example.com",
        password_hash=hash_password("AdminPassword123!"),
        full_name="Test Admin",
        role="company_admin",
        is_active=True,
        email_verified=True,
        is_superuser=False
    )
    db_session.add(admin)
    await db_session.commit()
    await db_session.refresh(admin)
    return admin


@pytest_asyncio.fixture
async def second_company_user(db_session: AsyncSession, second_company):
    """Create a user in the second company for multi-tenancy tests"""
    user = User(
        id=str(uuid.uuid4()),
        company_id=second_company.id,
        email="second@example.com",
        password_hash=hash_password("SecondPassword123!"),
        full_name="Second Company User",
        role="employee",
        is_active=True,
        email_verified=True
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest_asyncio.fixture
async def auth_tokens(client: AsyncClient, test_user):
    """Get authentication tokens for test user"""
    response = await client.post("/api/v1/auth/login", data={
        "username": test_user.email,
        "password": "TestPassword123!"
    })
    assert response.status_code == 200
    return response.json()


@pytest_asyncio.fixture
async def auth_headers(auth_tokens):
    """Get authorization headers with access token"""
    return {"Authorization": f"Bearer {auth_tokens['access_token']}"}


@pytest_asyncio.fixture
async def admin_tokens(client: AsyncClient, test_admin):
    """Get authentication tokens for admin user"""
    response = await client.post("/api/v1/auth/login", data={
        "username": test_admin.email,
        "password": "AdminPassword123!"
    })
    assert response.status_code == 200
    return response.json()


@pytest_asyncio.fixture
async def admin_headers(admin_tokens):
    """Get authorization headers with admin access token"""
    return {"Authorization": f"Bearer {admin_tokens['access_token']}"}


@pytest_asyncio.fixture
async def second_company_tokens(client: AsyncClient, second_company_user):
    """Get authentication tokens for second company user"""
    response = await client.post("/api/v1/auth/login", data={
        "username": second_company_user.email,
        "password": "SecondPassword123!"
    })
    assert response.status_code == 200
    return response.json()


@pytest_asyncio.fixture
async def second_company_headers(second_company_tokens):
    """Get authorization headers for second company user"""
    return {"Authorization": f"Bearer {second_company_tokens['access_token']}"}
