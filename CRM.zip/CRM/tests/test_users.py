"""
Integration tests for User Management
- Create user
- Update user
- Delete user
- List users with pagination
- User permissions
"""
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import uuid

from app.modules.users.models import User, Role, Permission, user_roles, role_permissions
from app.core.security import hash_password


class TestCreateUser:
    """Test user creation flow"""

    @pytest.mark.asyncio
    async def test_create_user_success(self, client: AsyncClient, admin_headers: dict, test_company):
        """Test creating a new user with valid data"""
        response = await client.post(
            "/api/v1/users/",
            headers=admin_headers,
            json={
                "email": "newuser@example.com",
                "password": "SecurePassword123!",
                "full_name": "New Test User",
                "phone": "+1234567890",
                "role": "employee"
            }
        )
        
        assert response.status_code in [200, 201]
        data = response.json()
        assert data["email"] == "newuser@example.com"
        assert data["full_name"] == "New Test User"
        assert data["role"] == "employee"
        assert data["is_active"] == True

    @pytest.mark.asyncio
    async def test_create_user_duplicate_email(self, client: AsyncClient, admin_headers: dict, test_user: User):
        """Test creating user with duplicate email fails"""
        response = await client.post(
            "/api/v1/users/",
            headers=admin_headers,
            json={
                "email": test_user.email,  # Duplicate email
                "password": "SecurePassword123!",
                "full_name": "Another User",
                "role": "employee"
            }
        )
        
        assert response.status_code == 400

    @pytest.mark.asyncio
    async def test_create_user_invalid_email(self, client: AsyncClient, admin_headers: dict):
        """Test creating user with invalid email fails"""
        response = await client.post(
            "/api/v1/users/",
            headers=admin_headers,
            json={
                "email": "not-an-email",
                "password": "SecurePassword123!",
                "full_name": "Test User",
                "role": "employee"
            }
        )
        
        assert response.status_code in [400, 422]

    @pytest.mark.asyncio
    async def test_create_user_weak_password(self, client: AsyncClient, admin_headers: dict):
        """Test creating user with weak password fails"""
        response = await client.post(
            "/api/v1/users/",
            headers=admin_headers,
            json={
                "email": "weakpass@example.com",
                "password": "123",  # Weak password
                "full_name": "Test User",
                "role": "employee"
            }
        )
        
        assert response.status_code in [400, 422]

    @pytest.mark.asyncio
    async def test_create_user_missing_required_fields(self, client: AsyncClient, admin_headers: dict):
        """Test creating user without required fields fails"""
        response = await client.post(
            "/api/v1/users/",
            headers=admin_headers,
            json={
                "email": "test@example.com"
                # Missing password and full_name
            }
        )
        
        assert response.status_code in [400, 422]

    @pytest.mark.asyncio
    async def test_create_user_without_auth(self, client: AsyncClient):
        """Test creating user without authentication fails"""
        response = await client.post(
            "/api/v1/users/",
            json={
                "email": "test@example.com",
                "password": "SecurePassword123!",
                "full_name": "Test User",
                "role": "employee"
            }
        )
        
        assert response.status_code == 401


class TestUpdateUser:
    """Test user update flow"""

    @pytest.mark.asyncio
    async def test_update_user_success(self, client: AsyncClient, admin_headers: dict, test_user: User):
        """Test updating user with valid data"""
        response = await client.patch(
            f"/api/v1/users/{test_user.id}",
            headers=admin_headers,
            json={
                "full_name": "Updated Name",
                "phone": "+9876543210"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["full_name"] == "Updated Name"
        assert data["phone"] == "+9876543210"

    @pytest.mark.asyncio
    async def test_update_user_not_found(self, client: AsyncClient, admin_headers: dict):
        """Test updating non-existent user fails"""
        fake_id = str(uuid.uuid4())
        response = await client.patch(
            f"/api/v1/users/{fake_id}",
            headers=admin_headers,
            json={
                "full_name": "Updated Name"
            }
        )
        
        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_update_user_invalid_data(self, client: AsyncClient, admin_headers: dict, test_user: User):
        """Test updating user with invalid data fails"""
        response = await client.patch(
            f"/api/v1/users/{test_user.id}",
            headers=admin_headers,
            json={
                "email": "not-an-email"
            }
        )
        
        assert response.status_code in [400, 422]


class TestDeleteUser:
    """Test user deletion flow"""

    @pytest.mark.asyncio
    async def test_delete_user_success(self, client: AsyncClient, admin_headers: dict, db_session: AsyncSession, test_company):
        """Test soft-deleting a user"""
        # Create a user to delete
        user_to_delete = User(
            id=str(uuid.uuid4()),
            company_id=test_company.id,
            email="delete.me@example.com",
            password_hash=hash_password("DeleteMe123!"),
            full_name="User To Delete",
            is_active=True
        )
        db_session.add(user_to_delete)
        await db_session.commit()
        
        response = await client.delete(
            f"/api/v1/users/{user_to_delete.id}",
            headers=admin_headers
        )
        
        assert response.status_code == 200
        
        # Verify user is soft deleted
        await db_session.refresh(user_to_delete)
        assert user_to_delete.deleted_at is not None

    @pytest.mark.asyncio
    async def test_delete_user_not_found(self, client: AsyncClient, admin_headers: dict):
        """Test deleting non-existent user fails"""
        fake_id = str(uuid.uuid4())
        response = await client.delete(
            f"/api/v1/users/{fake_id}",
            headers=admin_headers
        )
        
        assert response.status_code == 404


class TestListUsers:
    """Test user listing and pagination"""

    @pytest.mark.asyncio
    async def test_list_users_success(self, client: AsyncClient, admin_headers: dict):
        """Test listing users"""
        response = await client.get("/api/v1/users/", headers=admin_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        # Should have pagination structure
        assert "items" in data or "data" in data

    @pytest.mark.asyncio
    async def test_list_users_pagination(self, client: AsyncClient, admin_headers: dict):
        """Test user list pagination"""
        response = await client.get(
            "/api/v1/users/?page=1&page_size=10",
            headers=admin_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        
        # Check pagination fields
        if "items" in data:
            assert len(data["items"]) <= 10

    @pytest.mark.asyncio
    async def test_list_users_search(self, client: AsyncClient, admin_headers: dict, test_user: User):
        """Test searching users"""
        response = await client.get(
            f"/api/v1/users/?search={test_user.full_name[:5]}",
            headers=admin_headers
        )
        
        assert response.status_code == 200


class TestUserPermissions:
    """Test user permission checks"""

    @pytest.mark.asyncio
    async def test_regular_user_cannot_create_users(
        self,
        client: AsyncClient,
        auth_headers: dict
    ):
        """Test that regular users cannot create new users"""
        response = await client.post(
            "/api/v1/users/",
            headers=auth_headers,
            json={
                "email": "new@example.com",
                "password": "SecurePassword123!",
                "full_name": "New User",
                "role": "employee"
            }
        )
        
        # Should be forbidden
        assert response.status_code in [403, 401]

    @pytest.mark.asyncio
    async def test_user_can_view_own_profile(self, client: AsyncClient, auth_headers: dict, test_user: User):
        """Test user can view their own profile"""
        response = await client.get("/api/v1/users/me", headers=auth_headers)
        
        assert response.status_code == 200
        data = response.json()
        assert data["email"] == test_user.email

    @pytest.mark.asyncio
    async def test_admin_can_manage_all_users(
        self,
        client: AsyncClient,
        admin_headers: dict,
        test_user: User
    ):
        """Test admin can manage users in their company"""
        # Admin should be able to get user details
        response = await client.get(
            f"/api/v1/users/{test_user.id}",
            headers=admin_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == test_user.id
