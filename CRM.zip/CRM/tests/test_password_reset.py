"""
Integration tests for Password Reset flow
- Request password reset
- Validate reset token
- Reset password with token
"""
import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone, timedelta

from app.modules.users.models import User
from app.core.security import hash_password, verify_password


class TestPasswordResetFlow:
    """Test password reset flow integration"""

    @pytest.mark.asyncio
    async def test_request_password_reset_success(self, client: AsyncClient, test_user: User):
        """Test requesting password reset for existing user"""
        response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        
        # Should return 200 even if email doesn't exist (security)
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "reset_token" in data  # In test mode, token is returned

    @pytest.mark.asyncio
    async def test_request_password_reset_nonexistent_email(self, client: AsyncClient):
        """Test requesting password reset for non-existent email returns success (security)"""
        response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": "nonexistent@example.com"}
        )
        
        # Should return 200 to prevent email enumeration
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_reset_password_success(self, client: AsyncClient, db_session: AsyncSession, test_user: User):
        """Test resetting password with valid token"""
        # Request password reset
        forgot_response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        assert forgot_response.status_code == 200
        reset_token = forgot_response.json()["reset_token"]
        
        # Reset password
        new_password = "NewSecurePassword123!"
        reset_response = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": reset_token,
                "new_password": new_password,
                "confirm_password": new_password
            }
        )
        
        assert reset_response.status_code == 200
        
        # Verify can login with new password
        login_response = await client.post("/api/v1/auth/login", data={
            "username": test_user.email,
            "password": new_password
        })
        assert login_response.status_code == 200

    @pytest.mark.asyncio
    async def test_reset_password_invalid_token(self, client: AsyncClient):
        """Test resetting password with invalid token fails"""
        response = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": "invalid_token_here",
                "new_password": "NewPassword123!",
                "confirm_password": "NewPassword123!"
            }
        )
        
        assert response.status_code == 400

    @pytest.mark.asyncio
    async def test_reset_password_mismatched_passwords(self, client: AsyncClient, test_user: User):
        """Test resetting password with mismatched passwords fails"""
        # Request password reset
        forgot_response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        reset_token = forgot_response.json()["reset_token"]
        
        # Try to reset with mismatched passwords
        response = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": reset_token,
                "new_password": "NewPassword123!",
                "confirm_password": "DifferentPassword123!"
            }
        )
        
        assert response.status_code == 400

    @pytest.mark.asyncio
    async def test_reset_password_weak_password(self, client: AsyncClient, test_user: User):
        """Test resetting password with weak password fails"""
        # Request password reset
        forgot_response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        reset_token = forgot_response.json()["reset_token"]
        
        # Try to reset with weak password
        response = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": reset_token,
                "new_password": "weak",
                "confirm_password": "weak"
            }
        )
        
        assert response.status_code == 400

    @pytest.mark.asyncio
    async def test_reset_password_token_expired(self, client: AsyncClient, test_user: User):
        """Test resetting password with expired token fails"""
        # Request password reset
        forgot_response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        reset_token = forgot_response.json()["reset_token"]
        
        # Token expires after configured time (simulate by using expired token)
        # This test assumes token has short expiry for testing
        # In real scenario, we'd need to wait or mock time

    @pytest.mark.asyncio
    async def test_old_password_invalid_after_reset(self, client: AsyncClient, db_session: AsyncSession, test_user: User):
        """Test that old password no longer works after reset"""
        old_password = "TestPassword123!"
        
        # Request password reset
        forgot_response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        reset_token = forgot_response.json()["reset_token"]
        
        # Reset password
        new_password = "NewSecurePassword123!"
        await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": reset_token,
                "new_password": new_password,
                "confirm_password": new_password
            }
        )
        
        # Try to login with old password
        login_response = await client.post("/api/v1/auth/login", data={
            "username": test_user.email,
            "password": old_password
        })
        assert login_response.status_code == 401

    @pytest.mark.asyncio
    async def test_reset_password_requires_valid_email_format(self, client: AsyncClient):
        """Test that password reset request validates email format"""
        response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": "not-an-email"}
        )
        
        assert response.status_code in [400, 422]

    @pytest.mark.asyncio
    async def test_reset_token_single_use(self, client: AsyncClient, test_user: User):
        """Test that reset token can only be used once"""
        # Request password reset
        forgot_response = await client.post(
            "/api/v1/auth/forgot-password",
            json={"email": test_user.email}
        )
        reset_token = forgot_response.json()["reset_token"]
        
        # First reset
        new_password = "NewSecurePassword123!"
        response1 = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": reset_token,
                "new_password": new_password,
                "confirm_password": new_password
            }
        )
        assert response1.status_code == 200
        
        # Second attempt with same token should fail
        response2 = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": reset_token,
                "new_password": "AnotherPassword123!",
                "confirm_password": "AnotherPassword123!"
            }
        )
        assert response2.status_code == 400
